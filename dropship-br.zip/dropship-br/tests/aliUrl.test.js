import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  extrairProductId,
  ehLinkCurto,
  gerarSlug,
  slugUnico,
} from '../src/lib/aliUrl.js';

const ID = '1005004043442825';

// ---------------------------------------------------------------------
// extrairProductId
// ---------------------------------------------------------------------

test('extrai de link padrao', () => {
  const r = extrairProductId(`https://www.aliexpress.com/item/${ID}.html`);
  assert.equal(r.ok, true);
  assert.equal(r.productId, ID);
});

test('extrai ignorando parametros de rastreamento', () => {
  const r = extrairProductId(
    `https://pt.aliexpress.com/item/${ID}.html?spm=a2g0o.productlist.0.0&pdp_npi=4%40dis`
  );
  assert.equal(r.productId, ID);
});

test('funciona com dominios regionais e subdominios', () => {
  for (const url of [
    `https://m.aliexpress.com/item/${ID}.html`,
    `https://www.aliexpress.us/item/${ID}.html`,
    `https://aliexpress.ru/item/${ID}.html`,
    `https://pt.aliexpress.com/item/${ID}.html`,
    `https://www.aliexpress.com.br/item/${ID}.html`,
  ]) {
    assert.equal(extrairProductId(url).productId, ID, url);
  }
});

test('aceita o caminho /i/ alem de /item/', () => {
  assert.equal(extrairProductId(`https://www.aliexpress.com/i/${ID}.html`).productId, ID);
});

test('aceita link colado sem https://', () => {
  assert.equal(extrairProductId(`www.aliexpress.com/item/${ID}.html`).productId, ID);
});

test('aceita o id colado sozinho', () => {
  assert.equal(extrairProductId(ID).productId, ID);
  assert.equal(extrairProductId(`  ${ID}  `).productId, ID);
});

test('extrai id vindo de query string', () => {
  const r = extrairProductId(
    `https://www.aliexpress.com/p/order/detail.html?productId=${ID}`
  );
  assert.equal(r.productId, ID);
});

test('sinaliza link curto em vez de falhar em silencio', () => {
  const r = extrairProductId('https://a.aliexpress.com/_mLxAbCd');
  assert.equal(r.ok, false);
  assert.equal(r.linkCurto, true);
});

test('rejeita dominio de fora', () => {
  const r = extrairProductId('https://www.amazon.com.br/dp/B08XYZ');
  assert.equal(r.ok, false);
  assert.match(r.motivo, /Dominio/);
});

test('rejeita entrada vazia ou sem sentido', () => {
  assert.equal(extrairProductId('').ok, false);
  assert.equal(extrairProductId(null).ok, false);
  assert.equal(extrairProductId('sem link nenhum aqui').ok, false);
});

test('rejeita link da Ali sem id de produto', () => {
  assert.equal(extrairProductId('https://www.aliexpress.com/').ok, false);
});

test('ehLinkCurto reconhece os dois formatos', () => {
  assert.equal(ehLinkCurto('https://a.aliexpress.com/_mLxAbCd'), true);
  assert.equal(ehLinkCurto('https://s.click.aliexpress.com/e/_oABC'), true);
  assert.equal(ehLinkCurto(`https://www.aliexpress.com/item/${ID}.html`), false);
});

// ---------------------------------------------------------------------
// gerarSlug
// ---------------------------------------------------------------------

test('gera slug limpo a partir do titulo', () => {
  assert.equal(gerarSlug('Fone Bluetooth TWS i12'), 'fone-bluetooth-tws-i12');
});

test('remove acentos, emoji e pontuacao', () => {
  assert.equal(gerarSlug('Relógio 🔥 Inteligente, à prova d\'água!'), 'relogio-inteligente-a-prova-d-agua');
});

test('nao deixa hifen sobrando nas pontas', () => {
  assert.equal(gerarSlug('  --- Produto ---  '), 'produto');
  // O corte por tamanho nao pode terminar em hifen.
  const s = gerarSlug('a'.repeat(58) + ' bcd', { max: 60 });
  assert.ok(!s.endsWith('-'), s);
});

test('cai num slug padrao quando o titulo nao rende nada', () => {
  assert.equal(gerarSlug('🔥🔥🔥'), 'produto');
  assert.equal(gerarSlug(''), 'produto');
  assert.equal(gerarSlug(null), 'produto');
});

test('slug respeita o tamanho maximo', () => {
  assert.ok(gerarSlug('palavra '.repeat(40)).length <= 60);
});

test('slug gerado sempre passa na constraint do banco', () => {
  // O CHECK e: ^[a-z0-9]+(-[a-z0-9]+)*$
  const re = /^[a-z0-9]+(-[a-z0-9]+)*$/;
  for (const titulo of [
    'Fone Bluetooth TWS i12',
    'Relógio 🔥 Inteligente!',
    '   ---   ',
    '🔥🔥🔥',
    'Cabo USB-C 2m — 100W',
    'a'.repeat(200),
  ]) {
    assert.match(gerarSlug(titulo), re, `falhou para: ${titulo}`);
  }
});

// ---------------------------------------------------------------------
// slugUnico
// ---------------------------------------------------------------------

test('mantem o slug quando nao ha conflito', () => {
  assert.equal(slugUnico('fone-tws', ['outro']), 'fone-tws');
});

test('acrescenta sufixo ate achar vaga', () => {
  assert.equal(slugUnico('fone-tws', ['fone-tws']), 'fone-tws-2');
  assert.equal(slugUnico('fone-tws', ['fone-tws', 'fone-tws-2']), 'fone-tws-3');
});
