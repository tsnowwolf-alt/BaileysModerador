import { test } from 'node:test';
import assert from 'node:assert/strict';

/**
 * Estes testes existem por causa de uma falha concreta: o diagnóstico
 * exibiu nove ✓ e recomendou variáveis enquanto TODAS as chamadas eram
 * recusadas com InvalidAppKey. A causa foi tratar "erro desconhecido"
 * como sucesso.
 *
 * A regra que vale daqui em diante: na dúvida, NÃO é sucesso.
 */

// Reimplementação da regra sob teste, isolada do config/rede.
const BLOQUEADO = ['app', 'assinatura', 'token', 'permissao', 'metodo'];
const classificarAcesso = (tipo) =>
  BLOQUEADO.includes(tipo) ? false : tipo === 'outro' ? null : true;

test('erro de app, assinatura ou token nunca conta como acesso', () => {
  for (const tipo of ['app', 'assinatura', 'token']) {
    assert.equal(classificarAcesso(tipo), false, tipo);
  }
});

test('permissao e metodo inexistente tambem sao bloqueio', () => {
  assert.equal(classificarAcesso('permissao'), false);
  assert.equal(classificarAcesso('metodo'), false);
});

test('erro desconhecido fica indeterminado, nao aprovado', () => {
  // Era exatamente aqui que o InvalidAppKey virava ✓.
  assert.equal(classificarAcesso('outro'), null);
  assert.notEqual(classificarAcesso('outro'), true);
});

test('sucesso explicito conta como acesso', () => {
  assert.equal(classificarAcesso('ok'), true);
});

test('so `acesso === true` pode virar recomendacao', () => {
  const resultados = [
    { metodo: 'a', acesso: null },
    { metodo: 'b', acesso: false },
    { metodo: 'c', acesso: true },
  ];
  assert.equal(resultados.find((r) => r.acesso === true)?.metodo, 'c');
  // A versão com bug usava `find(r => r.acesso)`, que aceitaria
  // qualquer valor verdadeiro — e null/undefined passavam despercebidos
  // porque o campo simplesmente não era false.
  assert.equal(resultados.filter((r) => r.acesso === true).length, 1);
});

test('bloqueio global e detectado quando todos falham igual', () => {
  const NIVEL_APP = ['app', 'assinatura', 'token'];
  const todos = Array.from({ length: 9 }, () => ({ resultado: 'app' }));
  const tipos = new Set(todos.map((r) => r.resultado));
  assert.equal(tipos.size === 1 && NIVEL_APP.includes([...tipos][0]), true);
});

test('resultados variados NAO viram bloqueio global', () => {
  const NIVEL_APP = ['app', 'assinatura', 'token'];
  const todos = [{ resultado: 'app' }, { resultado: 'permissao' }, { resultado: 'outro' }];
  const tipos = new Set(todos.map((r) => r.resultado));
  assert.equal(tipos.size === 1 && NIVEL_APP.includes([...tipos][0]), false);
});

/* ---------------------------------------------------------------------
   Resposta REST da Alibaba

   `code: "0"` significa SUCESSO. Custou um token descartado: o teste
   era `if (json.code)`, e a string "0" é verdadeira em JavaScript.
   ------------------------------------------------------------------ */

const temErro = (json) => {
  const codigo = json.error_response?.code ?? json.code;
  return (
    json.error_response != null ||
    json.error != null ||
    (codigo != null && String(codigo) !== '0')
  );
};

test('code "0" e sucesso, nao erro', () => {
  assert.equal(temErro({ code: '0', access_token: 'abc' }), false);
  assert.equal(temErro({ code: 0, access_token: 'abc' }), false);
});

test('resposta sem code nenhum e sucesso', () => {
  assert.equal(temErro({ access_token: 'abc' }), false);
});

test('code diferente de zero e erro', () => {
  assert.equal(temErro({ code: '15', error_msg: 'algo' }), true);
  assert.equal(temErro({ code: 'IncompleteSignature' }), true);
});

test('error_response e sempre erro, mesmo com code zero', () => {
  assert.equal(temErro({ error_response: { code: '0', msg: 'x' } }), true);
});

/* ---------------------------------------------------------------------
   Erro de validação é sucesso na sondagem

   MissingParameter significa que a chamada atravessou app, assinatura,
   token e permissão — e só tropeçou nos parâmetros falsos que mandamos
   de propósito. Sem reconhecer isso, o diagnóstico reportou "nenhum
   método passou" para o placeorder, que funcionava.
   ------------------------------------------------------------------ */

test('erro de validacao conta como acesso liberado', () => {
  assert.equal(classificarAcesso('validacao'), true);
});

test('permissao insuficiente continua sendo bloqueio', () => {
  assert.equal(classificarAcesso('permissao'), false);
});

/* ---------------------------------------------------------------------
   Mensagem de erro legível

   A AliExpress devolve o motivo ora como string, ora como objeto
   aninhado. Passar o objeto para `new Error()` produzia
   "[object Object]" — escondendo o motivo da recusa justamente quando
   o cliente já pagou e alguém precisa decidir o que fazer.
   ------------------------------------------------------------------ */

const mensagemLegivel = (valor, profundidade = 0) => {
  if (valor == null) return null;
  if (typeof valor === 'string') return valor.trim() || null;
  if (typeof valor === 'number' || typeof valor === 'boolean') return String(valor);
  if (Array.isArray(valor)) {
    const partes = valor.map((v) => mensagemLegivel(v, profundidade + 1)).filter(Boolean);
    return partes.length ? partes.join(' | ') : null;
  }
  if (typeof valor === 'object') {
    for (const k of ['error_msg', 'msg', 'message', 'sub_msg', 'error_message', 'desc']) {
      const achado = mensagemLegivel(valor[k], profundidade + 1);
      if (achado) return achado;
    }
    if (profundidade < 3) return JSON.stringify(valor).slice(0, 400);
  }
  return null;
};

test('nunca produz [object Object]', () => {
  for (const entrada of [
    { error_msg: { msg: 'CPF invalido' } },
    { codigo: 1000 },
    [{ msg: 'a' }, { msg: 'b' }],
    { a: { b: { c: 'fundo' } } },
  ]) {
    const saida = mensagemLegivel(entrada);
    assert.ok(saida, 'devolveu vazio');
    assert.ok(!saida.includes('[object Object]'), `vazou: ${saida}`);
  }
});

test('prefere o campo nomeado ao JSON cru', () => {
  assert.equal(mensagemLegivel({ error_msg: { msg: 'motivo real' }, lixo: 1 }), 'motivo real');
});

test('junta varios erros de campo', () => {
  assert.equal(mensagemLegivel([{ msg: 'CEP' }, { msg: 'CPF' }]), 'CEP | CPF');
});

test('string e numero passam direto', () => {
  assert.equal(mensagemLegivel('erro simples'), 'erro simples');
  assert.equal(mensagemLegivel(1000), '1000');
  assert.equal(mensagemLegivel(''), null);
});

/* ---------------------------------------------------------------------
   Erros de negócio do placeorder

   O que decide a ação de quem lê o alerta é `retentavel`. Chutar
   "pode tentar de novo" num erro permanente faz a pessoa repetir a
   falha enquanto o prazo do cliente corre.
   ------------------------------------------------------------------ */

test('CPF que nao bate e erro permanente', async () => {
  const { interpretarErroNegocio } = await import('../src/aliexpress/errosNegocio.js');
  const i = interpretarErroNegocio('B_DROPSHIPPER_DELIVERY_ADDRESS_CPF_NOT_MATCH');
  assert.equal(i.retentavel, false);
  assert.match(i.texto, /CPF/);
  assert.ok(i.acao.length > 10);
});

test('codigo desconhecido nunca vira retentavel', async () => {
  const { interpretarErroNegocio } = await import('../src/aliexpress/errosNegocio.js');
  assert.equal(interpretarErroNegocio('B_CODIGO_QUE_NAO_EXISTE').retentavel, null);
  assert.equal(interpretarErroNegocio(null).retentavel, null);
});

test('todo erro catalogado diz o que fazer', async () => {
  const { ERROS_NEGOCIO } = await import('../src/aliexpress/errosNegocio.js');
  for (const [codigo, info] of Object.entries(ERROS_NEGOCIO)) {
    assert.ok(info.texto, `${codigo} sem texto`);
    assert.ok(info.acao, `${codigo} sem acao`);
    assert.equal(typeof info.retentavel, 'boolean', `${codigo} sem classificacao`);
  }
});

test('nome abreviado e recusado no checkout', () => {
  const ok = (v) =>
    v.trim().split(/\s+/).length >= 2 && !/\b[A-Za-z]\.?\s*$/.test(v.trim());
  assert.equal(ok('LUCAS P.'), false);
  assert.equal(ok('Maria Silva'), true);
  assert.equal(ok('Maria'), false);
});

/* ---------------------------------------------------------------------
   Estorno

   É a única operação do sistema que tira dinheiro da sua conta. As
   garantias: nunca duas vezes, e nunca sem pagamento registrado.
   ------------------------------------------------------------------ */

test('lock de estorno so libera uma vez', () => {
  // Espelha o UPDATE ... WHERE estornado_em IS NULL AND mp_payment_id IS NOT NULL
  const podeEstornar = (estornadoEm, mpPaymentId) =>
    estornadoEm == null && mpPaymentId != null;

  assert.equal(podeEstornar(null, 'mp-123'), true);
  assert.equal(podeEstornar(new Date(), 'mp-123'), false, 'estornou duas vezes');
  assert.equal(podeEstornar(null, null), false, 'estornou sem pagamento');
});

test('chave de idempotencia e derivada do pedido', () => {
  // Duas chamadas para o mesmo pedido produzem a mesma chave, e o
  // Mercado Pago reconhece a repeticao em vez de devolver de novo.
  const chave = (id) => `refund-pedido-${id}`;
  assert.equal(chave(17), chave(17));
  assert.notEqual(chave(17), chave(18));
});

test('codigo do erro e extraido do texto guardado', () => {
  const codigoDoErro = (t) => {
    const m = String(t ?? '').match(/\[([^\]]+)\]\s*$/);
    return m ? m[1] : null;
  };
  assert.equal(
    codigoDoErro('O CPF não corresponde ao nome. [B_DROPSHIPPER_DELIVERY_ADDRESS_CPF_NOT_MATCH]'),
    'B_DROPSHIPPER_DELIVERY_ADDRESS_CPF_NOT_MATCH'
  );
  assert.equal(codigoDoErro('erro sem codigo'), null);
  assert.equal(codigoDoErro(null), null);
});

test('correcao de dados e bloqueada apos existir pedido na Ali', () => {
  const podeCorrigir = (aliOrderId, estornadoEm) => !aliOrderId && !estornadoEm;
  assert.equal(podeCorrigir(null, null), true);
  assert.equal(podeCorrigir('8213602361010770', null), false);
  assert.equal(podeCorrigir(null, new Date()), false);
});

/* ---------------------------------------------------------------------
   Origem do envio

   A tese da loja é "já está no Brasil". Marcar TRUE sem evidência é
   pior que não verificar: vira promessa que a operação não cumpre.
   ------------------------------------------------------------------ */

test('so afirma origem BR quando TODAS as opcoes saem do Brasil', () => {
  const classificar = (paises) => ({
    origem_br: paises.length > 0 && paises.every((p) => p === 'BR'),
    parcial: !(paises.length > 0 && paises.every((p) => p === 'BR')) && paises.includes('BR'),
  });

  assert.deepEqual(classificar(['BR']), { origem_br: true, parcial: false });
  assert.deepEqual(classificar(['BR', 'BR']), { origem_br: true, parcial: false });
  // Uma opção chinesa no meio: o cliente pode cair nela.
  assert.deepEqual(classificar(['BR', 'CN']), { origem_br: false, parcial: true });
  assert.deepEqual(classificar(['CN']), { origem_br: false, parcial: false });
  // Sem informação nenhuma não vira TRUE por otimismo.
  assert.deepEqual(classificar([]), { origem_br: false, parcial: false });
});
