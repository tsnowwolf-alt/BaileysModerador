import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

/**
 * =====================================================================
 * Integridade dos imports
 * =====================================================================
 *
 * Este arquivo existe por causa de uma falha que passou por várias
 * versões: `src/services/pedidos.js` importava `traduzirErroPedido` de
 * `orders.js`, que nunca exportou esse nome. O processo morria no boot
 * com SyntaxError, e o Railway reportava apenas "healthcheck failure".
 *
 * Minha verificação era `node --check`, que valida a sintaxe de cada
 * arquivo isoladamente e NÃO confere se os imports resolvem. Um arquivo
 * sintaticamente perfeito que importa algo inexistente passa ileso.
 *
 * Aqui a checagem é estática — lê o código, não executa — então
 * funciona sem `npm install` e pega o erro antes do deploy.
 */

const RAIZ = new URL('..', import.meta.url).pathname;

async function arquivosJs(dir) {
  const saida = [];
  for (const item of await fs.readdir(dir, { withFileTypes: true })) {
    const completo = path.join(dir, item.name);
    if (item.isDirectory()) saida.push(...(await arquivosJs(completo)));
    else if (item.name.endsWith('.js')) saida.push(completo);
  }
  return saida;
}

/** Nomes exportados por um módulo, incluindo re-exports (`export { x } from`). */
function exportacoes(codigo) {
  const nomes = new Set();

  // export function nome / export const nome / export class nome
  for (const m of codigo.matchAll(/^export\s+(?:async\s+)?(?:function|class|const|let|var)\s+(\w+)/gm)) {
    nomes.add(m[1]);
  }
  // export { a, b as c } — cobre também `export { ... } from '...'`
  for (const m of codigo.matchAll(/^export\s*\{([^}]+)\}/gm)) {
    for (const parte of m[1].split(',')) {
      const nome = parte.trim().split(/\s+as\s+/).pop().trim();
      if (nome) nomes.add(nome);
    }
  }
  if (/^export\s+default/m.test(codigo)) nomes.add('default');

  return nomes;
}

/** Imports relativos, com os nomes pedidos. */
function importacoes(codigo) {
  const lista = [];
  const re = /import\s+([^'"]+?)\s+from\s+['"](\.[^'"]+)['"]/g;

  for (const m of codigo.matchAll(re)) {
    const clausula = m[1].trim();
    const alvo = m[2];
    const nomes = [];

    const chaves = clausula.match(/\{([^}]*)\}/);
    if (chaves) {
      for (const parte of chaves[1].split(',')) {
        const nome = parte.trim().split(/\s+as\s+/)[0].trim();
        if (nome) nomes.push(nome);
      }
    }
    // Import default (`import x from`) usa 'default'.
    const antesDaChave = clausula.split('{')[0].replace(/,\s*$/, '').trim();
    if (antesDaChave && !antesDaChave.startsWith('*')) nomes.push('default');

    lista.push({ alvo, nomes });
  }

  return lista;
}

test('todo import relativo aponta para um arquivo existente', async () => {
  const arquivos = [...(await arquivosJs(path.join(RAIZ, 'src'))), ...(await arquivosJs(path.join(RAIZ, 'scripts')))];
  const faltando = [];

  for (const arquivo of arquivos) {
    const codigo = await fs.readFile(arquivo, 'utf8');
    for (const { alvo } of importacoes(codigo)) {
      const caminho = path.resolve(path.dirname(arquivo), alvo);
      try {
        await fs.access(caminho);
      } catch {
        faltando.push(`${path.relative(RAIZ, arquivo)} → ${alvo}`);
      }
    }
  }

  assert.deepEqual(faltando, [], `Imports apontando para arquivo inexistente:\n${faltando.join('\n')}`);
});

test('todo nome importado existe no modulo de origem', async () => {
  const arquivos = [...(await arquivosJs(path.join(RAIZ, 'src'))), ...(await arquivosJs(path.join(RAIZ, 'scripts')))];
  const quebrados = [];

  for (const arquivo of arquivos) {
    const codigo = await fs.readFile(arquivo, 'utf8');

    for (const { alvo, nomes } of importacoes(codigo)) {
      // Módulos JSON sempre expõem `default`; não têm exports nomeados
      // para conferir.
      if (alvo.endsWith('.json')) continue;

      const caminho = path.resolve(path.dirname(arquivo), alvo);
      let destino;
      try {
        destino = await fs.readFile(caminho, 'utf8');
      } catch {
        continue; // já coberto pelo teste anterior
      }

      const disponiveis = exportacoes(destino);
      for (const nome of nomes) {
        if (!disponiveis.has(nome)) {
          quebrados.push(
            `${path.relative(RAIZ, arquivo)} importa "${nome}" de ${alvo}, que não exporta esse nome`
          );
        }
      }
    }
  }

  assert.deepEqual(
    quebrados,
    [],
    `Imports que derrubariam o processo no boot:\n${quebrados.join('\n')}`
  );
});

test('nenhum arquivo importa a si mesmo', async () => {
  const arquivos = await arquivosJs(path.join(RAIZ, 'src'));
  for (const arquivo of arquivos) {
    const codigo = await fs.readFile(arquivo, 'utf8');
    for (const { alvo } of importacoes(codigo)) {
      const caminho = path.resolve(path.dirname(arquivo), alvo);
      assert.notEqual(caminho, arquivo, `${path.relative(RAIZ, arquivo)} importa a si mesmo`);
    }
  }
});
