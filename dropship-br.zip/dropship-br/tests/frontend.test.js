import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  montarOpcoes,
  cpfValido,
  telefoneValido,
  cepValido,
  mascaras,
  reais,
} from '../public/js/loja.js';

/* ---------------------------------------------------------------------
   montarOpcoes

   Este bloco existe por causa de um bug real: o spread de `opcoes` vinha
   depois de `headers`, então qualquer chamador que passasse um header
   próprio (o painel passa x-admin-token) apagava o Content-Type. O corpo
   saía como texto puro, o express.json() ignorava, e o servidor recebia
   {} — reclamando que todos os campos faltavam mesmo preenchidos.
   ------------------------------------------------------------------ */

test('define Content-Type JSON por padrao', () => {
  const o = montarOpcoes({ method: 'POST', body: '{}' });
  assert.equal(o.headers['Content-Type'], 'application/json');
  assert.equal(o.method, 'POST');
});

test('header proprio NAO derruba o Content-Type', () => {
  const o = montarOpcoes({
    method: 'POST',
    body: '{}',
    headers: { 'x-admin-token': 'abc' },
  });
  assert.equal(o.headers['Content-Type'], 'application/json');
  assert.equal(o.headers['x-admin-token'], 'abc');
});

test('quem quiser pode sobrescrever o Content-Type de proposito', () => {
  const o = montarOpcoes({ headers: { 'Content-Type': 'text/plain' } });
  assert.equal(o.headers['Content-Type'], 'text/plain');
});

test('preserva as demais opcoes do fetch', () => {
  const o = montarOpcoes({ method: 'PATCH', body: 'x', cache: 'no-store' });
  assert.equal(o.method, 'PATCH');
  assert.equal(o.body, 'x');
  assert.equal(o.cache, 'no-store');
});

test('funciona sem argumento', () => {
  assert.equal(montarOpcoes().headers['Content-Type'], 'application/json');
});

/* ---------------------------------------------------------------------
   Validações — precisam bater com as do servidor
   ------------------------------------------------------------------ */

test('CPF do navegador concorda com o do servidor', () => {
  assert.equal(cpfValido('529.982.247-25'), true);
  assert.equal(cpfValido('52998224725'), true);
  assert.equal(cpfValido('111.111.111-11'), false);
  assert.equal(cpfValido('123.456.789-00'), false);
  assert.equal(cpfValido('529982247'), false);
  assert.equal(cpfValido(''), false);
});

test('telefone aceita fixo e celular, com ou sem formatacao', () => {
  assert.equal(telefoneValido('(11) 99999-8888'), true);
  assert.equal(telefoneValido('1133334444'), true);
  assert.equal(telefoneValido('999998888'), false);
});

test('CEP exige oito digitos', () => {
  assert.equal(cepValido('01310-100'), true);
  assert.equal(cepValido('0131010'), false);
});

/* ---------------------------------------------------------------------
   Máscaras
   ------------------------------------------------------------------ */

test('mascara de CPF formata progressivamente', () => {
  assert.equal(mascaras.cpf('529'), '529');
  assert.equal(mascaras.cpf('529982'), '529.982');
  assert.equal(mascaras.cpf('52998224725'), '529.982.247-25');
});

test('mascara de CPF descarta digito extra', () => {
  assert.equal(mascaras.cpf('529982247259999'), '529.982.247-25');
});

test('mascara de telefone distingue fixo de celular', () => {
  assert.equal(mascaras.telefone('1133334444'), '(11) 3333-4444');
  assert.equal(mascaras.telefone('11999998888'), '(11) 99999-8888');
});

test('mascara de CEP', () => {
  assert.equal(mascaras.cep('01310100'), '01310-100');
});

test('mascaras ignoram o que nao e digito', () => {
  assert.equal(mascaras.cpf('abc529xyz982'), '529.982');
  assert.equal(mascaras.cep('01310-100'), '01310-100');
});

/* ---------------------------------------------------------------------
   Formatação de dinheiro
   ------------------------------------------------------------------ */

test('formata centavos em reais', () => {
  // O separador do pt-BR pode vir como espaço normal ou não-quebrável.
  assert.match(reais(8990), /R\$\s?89,90/);
  assert.match(reais(0), /R\$\s?0,00/);
  assert.equal(reais(null), '—');
});

/* ---------------------------------------------------------------------
   Versão

   O aviso de "navegador com versão antiga" só funciona se a constante do
   JS acompanhar o package.json. Este teste é o que impede a checagem de
   virar mentira depois de um bump esquecido.
   ------------------------------------------------------------------ */

test('VERSAO_JS acompanha a versao do package.json', async () => {
  const { VERSAO_JS } = await import('../public/js/loja.js');
  const pkg = await import('../package.json', { with: { type: 'json' } });
  assert.equal(
    VERSAO_JS,
    pkg.default.version,
    'Ao subir a versao no package.json, suba tambem VERSAO_JS em public/js/loja.js'
  );
});

/* ---------------------------------------------------------------------
   Reconciliação — regra de idempotência

   A recuperação reprocessa eventos e pedidos. Se reprocessar pudesse
   duplicar compra, a rede de segurança viraria o problema. A garantia
   está no UPDATE condicional de repassarParaAliExpress: ele só avança
   a linha se ela ainda estiver em 'pago_no_site'.
   ------------------------------------------------------------------ */

test('lock so libera a partir de pago_no_site', () => {
  const podeRepassar = (status, jaTemOrderId) =>
    status === 'pago_no_site' && !jaTemOrderId;

  assert.equal(podeRepassar('pago_no_site', false), true);
  // Já processado: reprocessar não pode comprar de novo.
  assert.equal(podeRepassar('pago_no_site', true), false);
  assert.equal(podeRepassar('processando_ali', false), false);
  assert.equal(podeRepassar('aguardando_pagamento_ali', false), false);
  assert.equal(podeRepassar('processado_ali', true), false);
  assert.equal(podeRepassar('enviado', true), false);
});

test('so evento nao processado entra na recuperacao', () => {
  const precisaRecuperar = (processadoEm, minutosDesdeRecebido) =>
    processadoEm == null && minutosDesdeRecebido >= 2;

  assert.equal(precisaRecuperar(null, 5), true);
  assert.equal(precisaRecuperar(null, 1), false); // ainda pode estar rodando
  assert.equal(precisaRecuperar(new Date(), 60), false);
});

/* ---------------------------------------------------------------------
   Campo vazio: null x undefined

   O painel mandava `undefined` para campo vazio, e o servidor entende
   undefined como "não mexa". Resultado: o custo importado da AliExpress
   não podia ser apagado pela tela — e como o bloqueio de margem lê esse
   custo, a venda ficava travada sem explicação visível.
   ------------------------------------------------------------------ */

const paraCentavos = (txt) => {
  const limpo = String(txt ?? '').replace(/[^\d,.-]/g, '').replace(',', '.');
  const n = Number(limpo);
  return limpo === '' || !Number.isFinite(n) ? null : Math.round(n * 100);
};

test('campo vazio vira null, nao undefined', () => {
  assert.equal(paraCentavos(''), null);
  assert.notEqual(paraCentavos(''), undefined);
});

test('zero e um valor, nao ausencia', () => {
  assert.equal(paraCentavos('0'), 0);
  assert.equal(paraCentavos('0,00'), 0);
});

test('converte decimal brasileiro', () => {
  assert.equal(paraCentavos('35,00'), 3500);
  assert.equal(paraCentavos('R$ 89,90'), 8990);
});

test('null e apagado, undefined e preservado', () => {
  const aplicar = (dados) => {
    const campos = [];
    for (const c of ['preco_custo_centavos', 'titulo']) {
      if (dados[c] === undefined) continue;
      campos.push(c);
    }
    return campos;
  };
  assert.deepEqual(aplicar({ preco_custo_centavos: null }), ['preco_custo_centavos']);
  assert.deepEqual(aplicar({ preco_custo_centavos: undefined }), []);
  assert.deepEqual(aplicar({ preco_custo_centavos: 0 }), ['preco_custo_centavos']);
});

/* ---------------------------------------------------------------------
   Upsert de variação

   Toda coluna que entra no INSERT precisa aparecer no DO UPDATE SET,
   fora as que formam a chave de conflito. `preco_custo_centavos` estava
   de fora: a tela deixava editar, o UPDATE ignorava, e o bloqueio de
   margem seguia disparando por um valor impossível de alterar.
   ------------------------------------------------------------------ */

test('toda coluna do INSERT tambem e atualizada no conflito', async () => {
  const fs = await import('node:fs/promises');
  const src = await fs.readFile('src/services/produtos.js', 'utf8');

  const bloco = src.slice(
    src.indexOf('export async function adicionarVariacao'),
    src.indexOf('export async function validarParaAtivacao')
  );

  const colunas = bloco
    .match(/INSERT INTO produto_variacoes \(([^)]+)\)/)[1]
    .replace(/\n/g, ' ')
    .split(',')
    .map((c) => c.trim());

  const atualizadas = new Set([...bloco.matchAll(/(\w+)\s*=\s*EXCLUDED/g)].map((m) => m[1]));

  // produto_id e nome formam a chave do conflito: não se atualizam.
  const chave = new Set(['produto_id', 'nome']);
  const esquecidas = colunas.filter((c) => !chave.has(c) && !atualizadas.has(c));

  assert.deepEqual(
    esquecidas,
    [],
    `Colunas no INSERT que o UPDATE ignora: ${esquecidas.join(', ')}`
  );
});
