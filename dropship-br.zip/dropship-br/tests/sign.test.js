import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { buildBaseString, generateSign } from '../src/aliexpress/sign.js';
import { validarCPF, normalizarTelefone, normalizarCEP } from '../src/lib/brasil.js';

test('base string ordena as chaves em ASCII e ignora sign', () => {
  const base = buildBaseString({
    method: 'aliexpress.trade.buy.placeorder',
    app_key: '12345',
    timestamp: '1700000000000',
    sign: 'DEVE_SER_IGNORADO',
  });
  assert.equal(base, 'app_key12345methodaliexpress.trade.buy.placeordertimestamp1700000000000');
});

test('base string descarta valores vazios/nulos', () => {
  assert.equal(buildBaseString({ a: '1', b: '', c: null, d: undefined }), 'a1');
});

test('HMAC-SHA256 usa o secret como chave, sem envolver a base', () => {
  const params = { app_key: 'k', method: 'm', timestamp: '1' };
  const secret = 'segredo';
  const esperado = crypto
    .createHmac('sha256', secret)
    .update('app_keykmethodmtimestamp1', 'utf8')
    .digest('hex')
    .toUpperCase();
  assert.equal(generateSign(params, secret, 'sha256'), esperado);
});

test('MD5 legado envolve a base com o secret nas duas pontas', () => {
  const params = { a: '1', b: '2' };
  const secret = 'S3CR3T';
  const esperado = crypto
    .createHash('md5')
    .update(secret + 'a1b2' + secret, 'utf8')
    .digest('hex')
    .toUpperCase();
  assert.equal(generateSign(params, secret, 'md5'), esperado);
});

test('assinatura sai em hex maiusculo', () => {
  const sign = generateSign({ a: '1' }, 'x', 'sha256');
  assert.match(sign, /^[0-9A-F]{64}$/);
});

test('objeto aninhado e serializado de forma estavel', () => {
  const dto = { logistics_address: { country: 'BR', city: 'Sao Paulo' } };
  const base = buildBaseString({ p: JSON.stringify(dto) });
  assert.ok(base.includes('"country":"BR"'));
});

test('validarCPF aceita valido e rejeita invalido', () => {
  assert.equal(validarCPF('529.982.247-25'), true);
  assert.equal(validarCPF('111.111.111-11'), false);
  assert.equal(validarCPF('123.456.789-00'), false);
  assert.equal(validarCPF('529982247'), false);
});

test('normalizarTelefone remove +55 e valida tamanho', () => {
  assert.equal(normalizarTelefone('+55 (11) 99999-8888'), '11999998888');
  assert.equal(normalizarTelefone('(11) 3333-4444'), '1133334444');
  assert.equal(normalizarTelefone('123'), null);
});

test('normalizarCEP mantem somente digitos', () => {
  assert.equal(normalizarCEP('01310-100'), '01310100');
  assert.equal(normalizarCEP('123'), null);
});
