import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { validarAssinaturaMP, montarManifest } from '../src/lib/mpSignature.js';
import {
  classificarStatusAli,
  foiPago,
  linkPedidoAli,
  STATUS_ALI,
} from '../src/aliexpress/status.js';

const SEGREDO = 'segredo-do-webhook-mp';
const agora = () => Math.floor(Date.now() / 1000);

const assinar = (dados) =>
  crypto.createHmac('sha256', SEGREDO).update(montarManifest(dados), 'utf8').digest('hex');

// ---------------------------------------------------------------------
// Assinatura do webhook do Mercado Pago
// ---------------------------------------------------------------------

test('aceita assinatura valida', () => {
  const ts = agora();
  const v1 = assinar({ dataId: '123456', xRequestId: 'req-abc', ts });
  const r = validarAssinaturaMP(
    { xSignature: `ts=${ts},v1=${v1}`, xRequestId: 'req-abc', dataId: '123456' },
    SEGREDO
  );
  assert.equal(r.ok, true);
});

test('rejeita assinatura adulterada', () => {
  const ts = agora();
  const v1 = assinar({ dataId: '123456', xRequestId: 'req-abc', ts });
  const falsa = v1.slice(0, -1) + (v1.endsWith('a') ? 'b' : 'a');
  const r = validarAssinaturaMP(
    { xSignature: `ts=${ts},v1=${falsa}`, xRequestId: 'req-abc', dataId: '123456' },
    SEGREDO
  );
  assert.equal(r.ok, false);
});

test('rejeita webhook forjado com segredo errado', () => {
  const ts = agora();
  const v1 = crypto
    .createHmac('sha256', 'segredo-do-atacante')
    .update(montarManifest({ dataId: '1', xRequestId: 'r', ts }), 'utf8')
    .digest('hex');
  const r = validarAssinaturaMP(
    { xSignature: `ts=${ts},v1=${v1}`, xRequestId: 'r', dataId: '1' },
    SEGREDO
  );
  assert.equal(r.ok, false);
});

test('rejeita replay fora da janela de tempo', () => {
  const ts = agora() - 3600;
  const v1 = assinar({ dataId: '123456', xRequestId: 'req-abc', ts });
  const r = validarAssinaturaMP(
    { xSignature: `ts=${ts},v1=${v1}`, xRequestId: 'req-abc', dataId: '123456' },
    SEGREDO
  );
  assert.equal(r.ok, false);
  assert.match(r.motivo, /janela/);
});

test('data.id e normalizado para minusculas', () => {
  const ts = agora();
  const v1 = assinar({ dataId: 'ord01jq4s4ky8', xRequestId: 'req-1', ts });
  const r = validarAssinaturaMP(
    { xSignature: `ts=${ts},v1=${v1}`, xRequestId: 'req-1', dataId: 'ORD01JQ4S4KY8' },
    SEGREDO
  );
  assert.equal(r.ok, true);
});

test('campos ausentes saem do manifest em vez de virarem vazio', () => {
  assert.equal(montarManifest({ dataId: null, xRequestId: null, ts: 99 }), 'ts:99;');
  assert.equal(montarManifest({ dataId: 'a', xRequestId: null, ts: 99 }), 'id:a;ts:99;');

  const ts = agora();
  const v1 = assinar({ dataId: null, xRequestId: null, ts });
  const r = validarAssinaturaMP(
    { xSignature: `ts=${ts},v1=${v1}`, xRequestId: null, dataId: null },
    SEGREDO
  );
  assert.equal(r.ok, true);
});

test('rejeita header malformado, ausente ou sem segredo', () => {
  const ts = agora();
  assert.equal(validarAssinaturaMP({ xSignature: null }, SEGREDO).ok, false);
  assert.equal(validarAssinaturaMP({ xSignature: 'lixo' }, SEGREDO).ok, false);
  assert.equal(validarAssinaturaMP({ xSignature: `ts=${ts}` }, SEGREDO).ok, false);
  assert.equal(validarAssinaturaMP({ xSignature: `ts=${ts},v1=abc` }, null).ok, false);
});

// ---------------------------------------------------------------------
// Status da AliExpress — a distincao que evita o pedido fantasma
// ---------------------------------------------------------------------

test('PLACE_ORDER_SUCCESS NAO conta como pago', () => {
  assert.equal(classificarStatusAli('PLACE_ORDER_SUCCESS'), 'nao_pago');
  assert.equal(foiPago('PLACE_ORDER_SUCCESS'), false);
});

test('WAIT_SELLER_SEND_GOODS conta como pago', () => {
  assert.equal(classificarStatusAli('WAIT_SELLER_SEND_GOODS'), 'pago');
  assert.equal(foiPago('WAIT_SELLER_SEND_GOODS'), true);
});

test('cancelamento e reconhecido', () => {
  assert.equal(classificarStatusAli('IN_CANCEL'), 'cancelado');
  assert.equal(foiPago('IN_CANCEL'), false);
});

test('status desconhecido nunca vira pago por engano', () => {
  assert.equal(classificarStatusAli('ALGO_NOVO_DA_ALI'), 'desconhecido');
  assert.equal(classificarStatusAli(null), 'desconhecido');
  assert.equal(classificarStatusAli(''), 'desconhecido');
  assert.equal(foiPago('ALGO_NOVO_DA_ALI'), false);
});

test('nenhum status do mapa classifica nao_pago como pago', () => {
  for (const [cru, classe] of Object.entries(STATUS_ALI)) {
    if (classe === 'nao_pago') assert.equal(foiPago(cru), false, `${cru} vazou como pago`);
  }
});

test('classificacao ignora caixa', () => {
  assert.equal(classificarStatusAli('wait_seller_send_goods'), 'pago');
});

test('link do pedido aponta para a tela de detalhe', () => {
  assert.match(linkPedidoAli('30000123456789'), /orderId=30000123456789/);
});
