import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  nivelDevido,
  tomDoAlerta,
  formatarDuracao,
  parseEscala,
  ESCALA_PADRAO,
} from '../src/lib/escalonamento.js';

const ESCALA = [30, 120, 360];

// ---------------------------------------------------------------------
// nivelDevido
// ---------------------------------------------------------------------

test('nao alerta antes do primeiro marco', () => {
  assert.equal(nivelDevido(0, ESCALA), 0);
  assert.equal(nivelDevido(29, ESCALA), 0);
});

test('sobe um nivel a cada marco ultrapassado', () => {
  assert.equal(nivelDevido(30, ESCALA), 1);
  assert.equal(nivelDevido(119, ESCALA), 1);
  assert.equal(nivelDevido(120, ESCALA), 2);
  assert.equal(nivelDevido(359, ESCALA), 2);
  assert.equal(nivelDevido(360, ESCALA), 3);
});

test('nao passa do ultimo nivel por mais que demore', () => {
  assert.equal(nivelDevido(10_000, ESCALA), 3);
});

test('entrada invalida nao dispara alerta', () => {
  assert.equal(nivelDevido(NaN, ESCALA), 0);
  assert.equal(nivelDevido(-5, ESCALA), 0);
  assert.equal(nivelDevido(undefined, ESCALA), 0);
});

test('o nivel e monotonico — nunca desce ao longo do tempo', () => {
  let anterior = 0;
  for (let m = 0; m <= 500; m += 7) {
    const atual = nivelDevido(m, ESCALA);
    assert.ok(atual >= anterior, `nivel caiu de ${anterior} para ${atual} em ${m}min`);
    anterior = atual;
  }
});

// ---------------------------------------------------------------------
// tomDoAlerta
// ---------------------------------------------------------------------

test('o primeiro aviso e discreto e o ultimo e critico', () => {
  assert.equal(tomDoAlerta(1, 3).urgencia, 'NORMAL');
  assert.equal(tomDoAlerta(2, 3).urgencia, 'ATENCAO');
  assert.equal(tomDoAlerta(3, 3).urgencia, 'CRITICO');
});

test('o ultimo nivel e critico mesmo em escala curta ou longa', () => {
  assert.equal(tomDoAlerta(1, 1).urgencia, 'CRITICO');
  assert.equal(tomDoAlerta(5, 5).urgencia, 'CRITICO');
  assert.equal(tomDoAlerta(4, 5).urgencia, 'ATENCAO');
});

// ---------------------------------------------------------------------
// parseEscala
// ---------------------------------------------------------------------

test('interpreta a variavel de ambiente', () => {
  assert.deepEqual(parseEscala('30,120,360'), [30, 120, 360]);
  assert.deepEqual(parseEscala(' 15 , 60 '), [15, 60]);
});

test('ordena e remove duplicatas', () => {
  // Escala fora de ordem faria o nivel oscilar entre ciclos do cron.
  assert.deepEqual(parseEscala('360,30,120'), [30, 120, 360]);
  assert.deepEqual(parseEscala('30,30,60'), [30, 60]);
});

test('cai no padrao quando o valor e invalido ou vazio', () => {
  assert.deepEqual(parseEscala(''), ESCALA_PADRAO);
  assert.deepEqual(parseEscala(null), ESCALA_PADRAO);
  assert.deepEqual(parseEscala('abc,-5,0'), ESCALA_PADRAO);
});

test('descarta marcos invalidos mas mantem os validos', () => {
  assert.deepEqual(parseEscala('30,abc,120'), [30, 120]);
});

// ---------------------------------------------------------------------
// formatarDuracao
// ---------------------------------------------------------------------

test('formata duracao legivel no celular', () => {
  assert.equal(formatarDuracao(45), '45min');
  assert.equal(formatarDuracao(60), '1h');
  assert.equal(formatarDuracao(90), '1h 30min');
  assert.equal(formatarDuracao(360), '6h');
});
