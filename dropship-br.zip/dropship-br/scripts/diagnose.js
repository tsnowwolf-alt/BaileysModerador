import { rodarDiagnostico } from '../src/aliexpress/diagnostico.js';

/**
 * Diagnóstico pela linha de comando.
 *
 * A lógica vive em src/aliexpress/diagnostico.js e é a mesma que o
 * painel usa. Aqui só formatamos para o terminal — assim as duas
 * saídas não divergem com o tempo.
 *
 *   npm run diagnose
 */

const RESET = '\x1b[0m';
const cor = {
  ok: (s) => `\x1b[32m${s}${RESET}`,
  erro: (s) => `\x1b[31m${s}${RESET}`,
  aviso: (s) => `\x1b[33m${s}${RESET}`,
  fraco: (s) => `\x1b[90m${s}${RESET}`,
};

const TITULOS = {
  pedido_get: 'Consulta de pedido',
  place_order: 'Criação de pedido (nada é criado de verdade)',
  produto_get: 'Consulta de produto (usada pelo importador)',
};

const d = await rodarDiagnostico();

console.log('\n=== Diagnóstico AliExpress Open Platform ===\n');

console.log('1) Configuração');
console.log(`   Gateway:    ${d.configuracao.gateway}`);
console.log(`   Assinatura: ${d.configuracao.sign_method}`);
console.log(`   APP_KEY:    ${d.configuracao.app_key}`);
console.log(`   SECRET:     ${d.configuracao.secret_caracteres} caracteres`);
console.log(`   TOKEN:      ${d.configuracao.token_caracteres} caracteres`);
for (const a of d.configuracao.avisos) console.log(cor.erro(`   ✗ ${a}`));

console.log('\n2) Montagem da assinatura');
console.log(
  d.assinatura.ok
    ? cor.ok(`   ✓ sign gerado (${d.assinatura.tamanho} chars)`)
    : cor.erro(`   ✗ ${d.assinatura.erro}`)
);

let n = 3;
for (const [grupo, resultados] of Object.entries(d.grupos)) {
  console.log(`\n${n++}) ${TITULOS[grupo] ?? grupo}`);
  for (const r of resultados) {
    const marca = r.acesso ? cor.ok('✓') : cor.fraco('–');
    console.log(`   ${marca} ${r.metodo}`);
    console.log(`       ${r.detalhe}${r.code ? cor.fraco(` [${r.code}]`) : ''}`);
    if (r.faca) console.log(cor.aviso(`       → ${r.faca}`));
  }
}

console.log(`\n${'─'.repeat(58)}`);
console.log('Como ler:\n');
console.log('  ✓ erro de validação / "não encontrado"');
console.log('      = assinatura, token e permissão OK. Pode usar.');
console.log('  ✗ erro de assinatura ou token');
console.log('      = problema de configuração sua. Corrija antes de seguir.');
console.log('  – permissão negada / método inexistente');
console.log('      = escopo não liberado. Use outro método da lista.\n');

console.log('Sugestão de variáveis:');
for (const [chave, valor] of Object.entries(d.recomendacao)) {
  console.log(`  ${chave}=${valor ?? cor.erro('nenhum método passou')}`);
}
console.log();

process.exit(0);
