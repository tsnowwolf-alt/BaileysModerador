import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool, closePool } from '../src/db.js';
import logger from '../src/lib/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIR = path.join(__dirname, '..', 'db', 'migrations');

/**
 * Migrador minimo: aplica arquivos .sql em ordem alfabetica, uma vez so.
 * Sem dependencia externa, e seguro rodar a cada deploy.
 */
async function main() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS _migracoes (
      nome        TEXT PRIMARY KEY,
      aplicada_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  const arquivos = (await fs.readdir(DIR)).filter((f) => f.endsWith('.sql')).sort();
  const { rows } = await pool.query('SELECT nome FROM _migracoes');
  const aplicadas = new Set(rows.map((r) => r.nome));

  for (const arquivo of arquivos) {
    if (aplicadas.has(arquivo)) {
      logger.debug('Migracao ja aplicada', { arquivo });
      continue;
    }

    const sql = await fs.readFile(path.join(DIR, arquivo), 'utf8');
    logger.info('Aplicando migracao', { arquivo });

    // Arquivos marcados com "-- @no-transaction" tem os statements
    // executados um a um, sem transacao implicita. Necessario para
    // ALTER TYPE ... ADD VALUE, que nao aceita bloco transacional.
    const semTransacao = /^\s*--\s*@no-transaction/m.test(sql);

    const client = await pool.connect();
    try {
      if (semTransacao) {
        // Split ingenuo por ';'. Vale para statements simples como
        // ALTER TYPE; NAO use @no-transaction em arquivos com corpo de
        // funcao ($$ ... $$) ou literais contendo ponto e virgula.
        const statements = sql
          .split(';')
          // Tira as linhas de comentario de cada pedaco, preservando o
          // SQL que vem junto delas.
          .map((s) => s.replace(/^\s*--[^\n]*$/gm, '').trim())
          .filter(Boolean);

        for (const stmt of statements) {
          await client.query(stmt);
        }
      } else {
        await client.query(sql);
      }
      await client.query('INSERT INTO _migracoes (nome) VALUES ($1)', [arquivo]);
      logger.info('Migracao aplicada', { arquivo, semTransacao });
    } catch (err) {
      logger.error('Migracao falhou', { arquivo, erro: err.message });
      throw err;
    } finally {
      client.release();
    }
  }

  logger.info('Migracoes concluidas', { total: arquivos.length });
}

main()
  .then(async () => {
    await closePool();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error(err);
    await closePool();
    process.exit(1);
  });
