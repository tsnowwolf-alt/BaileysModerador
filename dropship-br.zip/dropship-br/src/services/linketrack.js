import config from '../config.js';
import logger from '../lib/logger.js';

/**
 * Integracao com a Linketrack (API brasileira nao-oficial dos Correios).
 * Endpoint: https://api.linketrack.com/track/json?user=..&token=..&codigo=..
 *
 * Duas ressalvas praticas:
 *  1. E um servico de terceiros sem SLA. Trate indisponibilidade como
 *     normal, nao como excecao.
 *  2. Fornecedor "nacional" da AliExpress muitas vezes NAO usa Correios —
 *     usa J&T, Loggi, Total Express, Sislogica. Nesses casos a Linketrack
 *     nao acha nada. Por isso ha o fallback abaixo.
 */

const CACHE_TTL_MS = 30 * 60 * 1000; // 30 min: Correios nao atualiza mais rapido que isso
const cache = new Map();

/** Codigo padrao Correios: 2 letras + 9 digitos + 2 letras (ex.: LB123456789BR) */
const RE_CORREIOS = /^[A-Z]{2}\d{9}[A-Z]{2}$/;

export const pareceCorreios = (codigo) => RE_CORREIOS.test(String(codigo).toUpperCase());

export async function rastrear(codigo, { ignorarCache = false } = {}) {
  const cod = String(codigo).trim().toUpperCase();

  if (!ignorarCache) {
    const hit = cache.get(cod);
    if (hit && Date.now() - hit.em < CACHE_TTL_MS) {
      return { ...hit.dados, cache: true };
    }
  }

  if (!config.LINKETRACK_USER || !config.LINKETRACK_TOKEN) {
    return {
      codigo: cod,
      servico: null,
      eventos: [],
      disponivel: false,
      motivo: 'LINKETRACK_USER/LINKETRACK_TOKEN nao configurados',
    };
  }

  if (!pareceCorreios(cod)) {
    return {
      codigo: cod,
      servico: null,
      eventos: [],
      disponivel: false,
      motivo:
        'Codigo fora do padrao Correios. Provavelmente transportadora privada (J&T, Loggi, Total Express).',
      sugestao: `https://www.linketrack.com/${cod}`,
    };
  }

  const url = new URL('https://api.linketrack.com/track/json');
  url.searchParams.set('user', config.LINKETRACK_USER);
  url.searchParams.set('token', config.LINKETRACK_TOKEN);
  url.searchParams.set('codigo', cod);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12_000);

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });

    if (!res.ok) {
      throw new Error(`Linketrack HTTP ${res.status}`);
    }

    const json = await res.json();

    const dados = {
      codigo: cod,
      servico: json.servico ?? null,
      quantidade: json.quantidade ?? json.eventos?.length ?? 0,
      eventos: (json.eventos ?? []).map((e) => ({
        data: e.data ?? null,
        hora: e.hora ?? null,
        local: e.local ?? null,
        status: e.status ?? null,
        subStatus: Array.isArray(e.subStatus) ? e.subStatus : e.subStatus ? [e.subStatus] : [],
      })),
      disponivel: true,
      consultadoEm: new Date().toISOString(),
    };

    dados.entregue = /entregue/i.test(dados.eventos[0]?.status ?? '');

    cache.set(cod, { em: Date.now(), dados });
    return dados;
  } catch (err) {
    logger.warn('Falha ao consultar Linketrack', { codigo: cod, erro: err.message });
    // Degradacao suave: o cliente ainda ve o codigo e o link externo.
    return {
      codigo: cod,
      servico: null,
      eventos: [],
      disponivel: false,
      motivo: 'Servico de rastreio temporariamente indisponivel',
      sugestao: `https://rastreamento.correios.com.br/app/index.php?objeto=${cod}`,
    };
  } finally {
    clearTimeout(timer);
  }
}

export default { rastrear, pareceCorreios };
