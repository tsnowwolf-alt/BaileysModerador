import { query } from '../db.js';
import logger from '../lib/logger.js';
import { alertar } from '../lib/alertas.js';
import { estornarPagamento } from './mercadopago.js';
import { interpretarErroNegocio } from '../aliexpress/errosNegocio.js';
import { validarCPF, somenteDigitos, normalizarCEP, normalizarTelefone, ufValida } from '../lib/brasil.js';

/**
 * =====================================================================
 * Pedidos com problema
 * =====================================================================
 *
 * São os registros em que o cliente pagou e não existe produto a
 * caminho. Três situações:
 *
 *   erro_ali       — o placeorder foi recusado
 *   cancelado_ali  — o pedido foi criado mas expirou sem pagamento
 *   pago_no_site   — pago e travado antes do repasse (raro, mas possível)
 *
 * Duas saídas, e a diferença entre elas está no código do erro:
 * quando o motivo é dado errado (CPF que não bate, endereço recusado),
 * corrigir e reprocessar recupera a venda. Quando é produto esgotado
 * ou fora do ar, não há o que corrigir — só estornar.
 */

const CAMPOS = `
  id, token_publico, referencia_externa, status_pedido,
  cliente_nome, cliente_cpf, cliente_telefone, cliente_email,
  endereco_rua, endereco_numero, endereco_complemento, endereco_bairro,
  endereco_cidade, endereco_estado, endereco_cep,
  produto_id, variacao_id, aliexpress_product_id, aliexpress_sku_attr,
  aliexpress_order_id, ali_order_status, quantidade,
  valor_total_centavos, mp_payment_id, mp_refund_id,
  estornado_em, valor_estornado_centavos, motivo_cancelamento,
  ultimo_erro, tentativas_ali, data_criacao, data_pagamento
`;

/**
 * Extrai o código do erro guardado em `ultimo_erro`.
 *
 * Formato atual: "texto legível [CODIGO_DA_ALI]".
 * Formato antigo: só o código cru, sem colchetes — registros gravados
 * antes de a tradução existir. Sem o segundo caso, pedidos anteriores
 * apareciam como "Falha não identificada" para sempre.
 */
function codigoDoErro(ultimoErro) {
  const texto = String(ultimoErro ?? '').trim();
  if (!texto) return null;

  const entreColchetes = texto.match(/\[([^\]]+)\]\s*$/);
  if (entreColchetes) return entreColchetes[1];

  // Códigos da Alibaba são MAIÚSCULAS com _ ou -, sem espaço.
  if (/^[A-Z][A-Z0-9_-]{5,}$/.test(texto)) return texto;

  return null;
}

export async function listarProblemas({ incluirResolvidos = false } = {}) {
  const { rows } = await query(
    `SELECT ${CAMPOS},
            (SELECT titulo FROM produtos WHERE id = p.produto_id) AS produto_titulo,
            (SELECT nome  FROM produto_variacoes WHERE id = p.variacao_id) AS variacao_nome
       FROM pedidos p
      WHERE status_pedido IN ('erro_ali', 'cancelado_ali')
         OR (status_pedido = 'pago_no_site'
             AND aliexpress_order_id IS NULL
             AND data_pagamento < NOW() - interval '20 minutes')
         ${incluirResolvidos ? "OR estornado_em IS NOT NULL" : ''}
      ORDER BY data_pagamento DESC NULLS LAST
      LIMIT 100`
  );

  return rows.map((p) => {
    const info = interpretarErroNegocio(codigoDoErro(p.ultimo_erro));
    return {
      ...p,
      diagnostico: {
        motivo: info.texto,
        detalhe: info.detalhe ?? null,
        acao: info.acao,
        // Reprocessar sem corrigir só repete a falha quando o erro é
        // permanente. É a informação que decide o próximo clique.
        vale_reprocessar: info.retentavel,
      },
      pode_estornar: Boolean(p.mp_payment_id) && !p.estornado_em,
      ja_estornado: Boolean(p.estornado_em),
    };
  });
}

/**
 * Corrige dados do cliente antes de reprocessar.
 *
 * Só permitido enquanto NÃO existe pedido na AliExpress: depois de
 * criado lá, mudar o endereço aqui daria a falsa impressão de que o
 * envio mudou junto.
 */
const CAMPOS_CORRIGIVEIS = [
  'cliente_nome',
  'cliente_cpf',
  'cliente_telefone',
  'endereco_rua',
  'endereco_numero',
  'endereco_complemento',
  'endereco_bairro',
  'endereco_cidade',
  'endereco_estado',
  'endereco_cep',
];

export async function corrigirDados(pedidoId, dados) {
  const { rows: atual } = await query(
    `SELECT aliexpress_order_id, estornado_em FROM pedidos WHERE id = $1`,
    [pedidoId]
  );
  if (!atual[0]) return { ok: false, motivo: 'Pedido não encontrado' };
  if (atual[0].aliexpress_order_id) {
    return {
      ok: false,
      motivo: 'Já existe pedido na AliExpress. Cancele lá antes de alterar os dados.',
    };
  }
  if (atual[0].estornado_em) {
    return { ok: false, motivo: 'Pedido já estornado.' };
  }

  const limpos = {};
  const erros = [];

  for (const campo of CAMPOS_CORRIGIVEIS) {
    if (dados[campo] === undefined) continue;
    let valor = String(dados[campo] ?? '').trim();

    if (campo === 'cliente_cpf') {
      valor = somenteDigitos(valor);
      if (!validarCPF(valor)) erros.push('CPF inválido');
    }
    if (campo === 'cliente_telefone') {
      valor = normalizarTelefone(valor);
      if (!valor) erros.push('Telefone inválido');
    }
    if (campo === 'endereco_cep') {
      valor = normalizarCEP(valor);
      if (!valor) erros.push('CEP inválido');
    }
    if (campo === 'endereco_estado') {
      valor = valor.toUpperCase();
      if (!ufValida(valor)) erros.push('UF inválida');
    }
    if (campo === 'cliente_nome' && valor.split(/\s+/).length < 2) {
      erros.push('Nome precisa ser completo');
    }

    limpos[campo] = valor;
  }

  if (erros.length) return { ok: false, motivo: erros.join('; ') };
  if (Object.keys(limpos).length === 0) return { ok: false, motivo: 'Nada para corrigir' };

  const sets = [];
  const valores = [pedidoId];
  for (const [campo, valor] of Object.entries(limpos)) {
    valores.push(valor);
    sets.push(`${campo} = $${valores.length}`);
  }

  const { rows } = await query(
    `UPDATE pedidos SET ${sets.join(', ')} WHERE id = $1 RETURNING ${CAMPOS}`,
    valores
  );

  logger.info('Dados do pedido corrigidos', { pedidoId, campos: Object.keys(limpos) });
  return { ok: true, pedido: rows[0] };
}

/**
 * Devolve o dinheiro ao cliente.
 *
 * O lock é o mesmo padrão do resto do sistema: um UPDATE condicional
 * marca o estorno como em andamento antes de chamar o Mercado Pago.
 * Dois cliques no botão não viram dois estornos.
 */
export async function estornar(pedidoId, motivo = 'Pedido não pôde ser processado') {
  const { rows, rowCount } = await query(
    `UPDATE pedidos
        SET motivo_cancelamento = $2
      WHERE id = $1
        AND estornado_em IS NULL
        AND mp_payment_id IS NOT NULL
      RETURNING ${CAMPOS}`,
    [pedidoId, motivo]
  );

  if (rowCount !== 1) {
    const { rows: atual } = await query(
      `SELECT estornado_em, mp_payment_id FROM pedidos WHERE id = $1`,
      [pedidoId]
    );
    if (!atual[0]) return { ok: false, motivo: 'Pedido não encontrado' };
    if (atual[0].estornado_em) return { ok: false, motivo: 'Já estornado' };
    return { ok: false, motivo: 'Este pedido não tem pagamento registrado' };
  }

  const pedido = rows[0];

  // Aviso, não bloqueio: se o pedido existe na Ali e foi pago por você,
  // estornar o cliente significa prejuízo. Quem decide é você.
  const temPedidoAli = Boolean(pedido.aliexpress_order_id);

  try {
    const refund = await estornarPagamento(pedido.mp_payment_id, {
      valorCentavos: pedido.valor_total_centavos,
      chave: `refund-pedido-${pedido.id}`,
    });

    const { rows: fin } = await query(
      `UPDATE pedidos
          SET mp_refund_id             = $2,
              estornado_em             = NOW(),
              valor_estornado_centavos = $3,
              status_pedido            = 'cancelado'
        WHERE id = $1
        RETURNING ${CAMPOS}`,
      [pedido.id, refund.id, refund.valorCentavos || pedido.valor_total_centavos]
    );

    logger.info('Pedido estornado', {
      pedidoId: pedido.id,
      refundId: refund.id,
      valor: refund.valorCentavos,
    });

    await alertar('💸 Estorno realizado', {
      pedido: `#${pedido.id}`,
      cliente: pedido.cliente_nome,
      valor: `R$ ${((refund.valorCentavos || pedido.valor_total_centavos) / 100).toFixed(2)}`,
      motivo,
      ...(temPedidoAli
        ? { atencao: `Existe pedido ${pedido.aliexpress_order_id} na Ali. Cancele lá também.` }
        : {}),
    });

    return { ok: true, pedido: fin[0], refund, temPedidoAli };
  } catch (err) {
    // Libera o registro para nova tentativa: o estorno não aconteceu.
    await query(
      `UPDATE pedidos SET motivo_cancelamento = NULL, ultimo_erro = $2 WHERE id = $1`,
      [pedido.id, `Falha no estorno: ${err.message}`.slice(0, 1000)]
    );

    logger.error('Falha ao estornar', { pedidoId: pedido.id, erro: err.message });
    return { ok: false, motivo: err.message };
  }
}

/** Números do topo da tela. */
export async function resumoProblemas() {
  const { rows } = await query(
    `SELECT
       COUNT(*) FILTER (WHERE status_pedido IN ('erro_ali','cancelado_ali')
                          AND estornado_em IS NULL)          AS abertos,
       COALESCE(SUM(valor_total_centavos) FILTER (
                 WHERE status_pedido IN ('erro_ali','cancelado_ali')
                   AND estornado_em IS NULL), 0)             AS valor_retido,
       COUNT(*) FILTER (WHERE estornado_em IS NOT NULL)      AS estornados
     FROM pedidos`
  );
  return rows[0];
}

export default { listarProblemas, corrigirDados, estornar, resumoProblemas };
