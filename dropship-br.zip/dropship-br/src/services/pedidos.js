import { query, withTransaction } from '../db.js';
import logger from '../lib/logger.js';
import { alertar } from '../lib/alertas.js';
import config from '../config.js';
import {
  criarPedidoAli,
  linkPedidoAli,
  LINK_PEDIDOS_PENDENTES,
} from '../aliexpress/orders.js';
import { interpretarErroNegocio } from '../aliexpress/errosNegocio.js';

const CAMPOS = `
  id, token_publico, referencia_externa, cliente_nome, cliente_cpf, cliente_telefone, cliente_email,
  endereco_rua, endereco_numero, endereco_complemento, endereco_bairro,
  endereco_cidade, endereco_estado, endereco_cep,
  produto_id, variacao_id,
  aliexpress_product_id, aliexpress_sku_id, aliexpress_sku_attr,
  quantidade, logistics_service,
  aliexpress_order_id, ali_order_status, tentativas_ali, ultimo_erro, nivel_alerta,
  valor_total_centavos, valor_ali_centavos, status_pedido,
  codigo_rastreio, transportadora,
  mp_payment_id, mp_status, mp_metodo, pix_qr_code, pix_expira_em,
  data_criacao, data_atualizacao, data_pagamento,
  data_pedido_ali, data_pagamento_ali, data_envio, alerta_pagamento_em
`;

export async function buscarPorId(id) {
  const { rows } = await query(`SELECT ${CAMPOS} FROM pedidos WHERE id = $1`, [id]);
  return rows[0] ?? null;
}

export async function buscarPorToken(token) {
  const { rows } = await query(
    `SELECT ${CAMPOS} FROM pedidos WHERE token_publico = $1`,
    [token]
  );
  return rows[0] ?? null;
}

export async function buscarPorReferencia(referencia) {
  const { rows } = await query(
    `SELECT ${CAMPOS} FROM pedidos WHERE referencia_externa = $1`,
    [referencia]
  );
  return rows[0] ?? null;
}

export async function criarPedido(dados) {
  const { rows } = await query(
    `INSERT INTO pedidos (
       referencia_externa, cliente_nome, cliente_cpf, cliente_telefone, cliente_email,
       endereco_rua, endereco_numero, endereco_complemento, endereco_bairro,
       endereco_cidade, endereco_estado, endereco_cep,
       aliexpress_product_id, aliexpress_sku_id, aliexpress_sku_attr,
       quantidade, logistics_service, valor_total_centavos,
       produto_id, variacao_id, status_pedido
     ) VALUES (
       $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
       'aguardando_pagamento'
     )
     ON CONFLICT (referencia_externa) DO NOTHING
     RETURNING ${CAMPOS}`,
    [
      dados.referencia_externa,
      dados.cliente_nome,
      dados.cliente_cpf,
      dados.cliente_telefone,
      dados.cliente_email ?? null,
      dados.endereco_rua,
      dados.endereco_numero,
      dados.endereco_complemento ?? null,
      dados.endereco_bairro,
      dados.endereco_cidade,
      dados.endereco_estado,
      dados.endereco_cep,
      dados.aliexpress_product_id,
      dados.aliexpress_sku_id ?? null,
      dados.aliexpress_sku_attr ?? null,
      dados.quantidade ?? 1,
      dados.logistics_service ?? null,
      dados.valor_total_centavos ?? null,
      dados.produto_id ?? null,
      dados.variacao_id ?? null,
    ]
  );

  // Conflito = pedido ja existia; devolve o existente em vez de duplicar.
  return rows[0] ?? (await buscarPorReferencia(dados.referencia_externa));
}

export async function salvarCobrancaPix(pedidoId, cobranca) {
  const { rows } = await query(
    `UPDATE pedidos
        SET mp_payment_id  = $2,
            mp_status      = $3,
            mp_metodo      = 'pix',
            pix_qr_code    = $4,
            pix_qr_base64  = $5,
            pix_expira_em  = $6
      WHERE id = $1
      RETURNING ${CAMPOS}`,
    [
      pedidoId,
      cobranca.paymentId,
      cobranca.status,
      cobranca.qrCode,
      cobranca.qrCodeBase64,
      cobranca.expiraEm,
    ]
  );
  return rows[0] ?? null;
}

/**
 * =====================================================================
 * O ponto mais delicado do sistema inteiro
 * =====================================================================
 *
 * Este UPDATE condicional e o que impede a compra em duplicidade.
 * Ele so avanca a linha se ela ainda estiver em 'pago_no_site'.
 * Se dois webhooks chegarem ao mesmo tempo, um ganha a corrida e o
 * outro recebe rowCount = 0 e desiste.
 *
 * Nunca troque isto por "SELECT status; if (status === 'pago_no_site')
 * then UPDATE" — a janela entre o SELECT e o UPDATE ja e suficiente
 * para comprar o mesmo produto duas vezes com dinheiro real.
 */
async function adquirirLock(pedidoId) {
  const { rows, rowCount } = await query(
    `UPDATE pedidos
        SET status_pedido = 'processando_ali',
            tentativas_ali = tentativas_ali + 1
      WHERE id = $1
        AND status_pedido = 'pago_no_site'
        AND aliexpress_order_id IS NULL
      RETURNING ${CAMPOS}`,
    [pedidoId]
  );
  return rowCount === 1 ? rows[0] : null;
}

export async function marcarComoPago(pedidoId, { valorCentavos, mpPaymentId, mpStatus, mpMetodo } = {}) {
  const { rows } = await query(
    `UPDATE pedidos
        SET status_pedido = 'pago_no_site',
            data_pagamento = COALESCE(data_pagamento, NOW()),
            valor_total_centavos = COALESCE($2, valor_total_centavos),
            mp_payment_id = COALESCE($3, mp_payment_id),
            mp_status = COALESCE($4, mp_status),
            mp_metodo = COALESCE($5, mp_metodo)
      WHERE id = $1
        AND status_pedido IN ('aguardando_pagamento', 'erro_ali')
      RETURNING ${CAMPOS}`,
    [pedidoId, valorCentavos ?? null, mpPaymentId ?? null, mpStatus ?? null, mpMetodo ?? null]
  );
  return rows[0] ?? null;
}

/**
 * Fluxo do repasse: lock -> chama AliExpress -> grava resultado.
 *
 * ATENCAO ao estado final: o pedido vai para 'aguardando_pagamento_ali',
 * NAO para 'processado_ali'. O placeorder cria o pedido sem pagar; quem
 * confirma que o dinheiro entrou e o cron, ao ver o status virar
 * WAIT_SELLER_SEND_GOODS. Tratar como pago aqui e o erro que produz
 * pedido fantasma: banco verde, cliente esperando, nada despachado.
 */
export async function repassarParaAliExpress(pedidoId) {
  const pedido = await adquirirLock(pedidoId);

  if (!pedido) {
    const atual = await buscarPorId(pedidoId);
    if (!atual) return { status: 'nao_encontrado' };
    if (atual.aliexpress_order_id) {
      return { status: 'ja_processado', pedido: atual };
    }
    return {
      status: 'ignorado',
      motivo: `status atual = ${atual.status_pedido}`,
      pedido: atual,
    };
  }

  try {
    const { orderId, raw, dryRun } = await criarPedidoAli(pedido);

    if (dryRun) {
      // Devolve ao estado anterior para nao travar o pedido em dry-run.
      await query(
        `UPDATE pedidos SET status_pedido = 'pago_no_site', aliexpress_response = $2
          WHERE id = $1`,
        [pedido.id, JSON.stringify(raw)]
      );
      return { status: 'dry_run', pedido };
    }

    const { rows } = await query(
      `UPDATE pedidos
          SET aliexpress_order_id = $2,
              aliexpress_response = $3,
              status_pedido       = 'aguardando_pagamento_ali',
              ali_order_status    = 'PLACE_ORDER_SUCCESS',
              data_pedido_ali     = NOW(),
              ultimo_erro         = NULL
        WHERE id = $1
        RETURNING ${CAMPOS}`,
      [pedido.id, orderId, JSON.stringify(raw)]
    );

    logger.info('Pedido criado na AliExpress (aguardando pagamento)', {
      pedidoId: pedido.id,
      orderId,
    });

    // Avisa na hora, silencioso. Se o auto-debito estiver ativo, o cron
    // confirma em minutos e voce nem olha. Se nao estiver, o link ja
    // esta a um toque. Os avisos com som vem depois, se ninguem pagar.
    await alertar(
      '💳 Pedido criado na AliExpress',
      {
        pedido: `#${pedido.id}`,
        ali_order_id: orderId,
        valor_cliente: pedido.valor_total_centavos
          ? `R$ ${(pedido.valor_total_centavos / 100).toFixed(2)}`
          : '-',
        prazo_estimado: `${config.ALI_PRAZO_PAGAMENTO_HORAS}h`,
      },
      {
        silencioso: true,
        botoes: [
          { texto: '💰 Pagar este pedido', url: linkPedidoAli(orderId) },
          { texto: '📋 Ver todos os pendentes', url: LINK_PEDIDOS_PENDENTES },
        ],
      }
    );

    return { status: 'ok', pedido: rows[0] };
  } catch (err) {
    logger.error('Falha ao repassar pedido a AliExpress', {
      pedidoId: pedido.id,
      erro: err.message,
      code: err.code,
      subCode: err.subCode,
    });

    // Traduz o código para o que fazer. A informação decisiva é se
    // reprocessar adianta: metade dos erros é permanente, e reprocessar
    // um deles só repete a falha enquanto o prazo do cliente corre.
    const codigo = err.code ?? err.subCode ?? err.message;
    const info = interpretarErroNegocio(codigo);

    await query(
      `UPDATE pedidos
          SET status_pedido = 'erro_ali',
              ultimo_erro   = $2
        WHERE id = $1`,
      // O código entre colchetes no fim é o que a tela de Problemas lê
      // depois para reconstruir o diagnóstico.
      [pedido.id, `${info.texto} [${err.code ?? err.subCode ?? '-'}]`.slice(0, 1000)]
    );

    await alertar(`🔴 Pedido #${pedido.id} recusado na AliExpress`, {
      motivo: info.texto,
      ...(info.detalhe ? { detalhe: info.detalhe } : {}),
      o_que_fazer: info.acao,
      reprocessar:
        info.retentavel === true
          ? 'Sim, vale tentar de novo'
          : info.retentavel === false
            ? 'NÃO adianta — o erro se repete'
            : 'Desconhecido — confira antes',
      cliente: pedido.cliente_nome,
      valor: pedido.valor_total_centavos
        ? `R$ ${(pedido.valor_total_centavos / 100).toFixed(2)}`
        : '-',
      codigo: err.code ?? err.subCode ?? '-',
    });

    return { status: 'erro', motivo: err.message, pedido };
  }
}

/** Confirma que o pagamento na Ali entrou (chamado pelo cron). */
export async function confirmarPagamentoAli(pedidoId, statusCru) {
  const { rows } = await query(
    `UPDATE pedidos
        SET status_pedido      = 'processado_ali',
            ali_order_status   = $2,
            data_pagamento_ali = COALESCE(data_pagamento_ali, NOW())
      WHERE id = $1
        AND status_pedido = 'aguardando_pagamento_ali'
      RETURNING ${CAMPOS}`,
    [pedidoId, statusCru]
  );
  return rows[0] ?? null;
}

/** Pedidos criados na Ali e ainda nao pagos. Alimenta o painel e os alertas. */
export async function listarAguardandoPagamentoAli() {
  const { rows } = await query(
    `SELECT id, aliexpress_order_id, ali_order_status, valor_total_centavos,
            data_pedido_ali, alerta_pagamento_em, nivel_alerta,
            EXTRACT(EPOCH FROM (NOW() - data_pedido_ali))/60 AS minutos_parado
       FROM pedidos
      WHERE status_pedido = 'aguardando_pagamento_ali'
      ORDER BY data_pedido_ali ASC`
  );
  return rows;
}

/**
 * Grava o nivel de escalonamento ja enviado.
 * A condicao `nivel_alerta < $2` evita que dois ciclos sobrepostos do
 * cron mandem o mesmo aviso duas vezes.
 */
export async function registrarAlertaPagamento(pedidoId, nivel) {
  const { rowCount } = await query(
    `UPDATE pedidos
        SET nivel_alerta = $2, alerta_pagamento_em = NOW()
      WHERE id = $1 AND nivel_alerta < $2`,
    [pedidoId, nivel]
  );
  return rowCount === 1;
}

/**
 * Libera pedidos travados em 'processando_ali' (ex.: deploy no meio da
 * chamada). Rode junto com o cron.
 */
export async function destravarPendentes(minutos = 15) {
  const { rowCount } = await query(
    `UPDATE pedidos
        SET status_pedido = 'erro_ali',
            ultimo_erro   = 'Timeout de processamento; liberado para retry'
      WHERE status_pedido = 'processando_ali'
        AND aliexpress_order_id IS NULL
        AND data_atualizacao < NOW() - ($1 || ' minutes')::interval`,
    [String(minutos)]
  );
  if (rowCount > 0) logger.warn('Pedidos destravados', { rowCount });
  return rowCount;
}

export async function registrarEventoWebhook(eventoId, origem, payload) {
  try {
    const { rowCount } = await query(
      `INSERT INTO webhook_eventos (evento_id, origem, payload)
       VALUES ($1, $2, $3)
       ON CONFLICT (evento_id) DO NOTHING`,
      [eventoId, origem, JSON.stringify(payload)]
    );
    return rowCount === 1; // false = evento repetido
  } catch (err) {
    logger.error('Erro ao registrar evento de webhook', { erro: err.message });
    throw err;
  }
}

export async function marcarEventoProcessado(eventoId, erro = null) {
  await query(
    `UPDATE webhook_eventos SET processado_em = NOW(), erro = $2 WHERE evento_id = $1`,
    [eventoId, erro]
  );
}

export { withTransaction };

export default {
  buscarPorId,
  buscarPorToken,
  buscarPorReferencia,
  criarPedido,
  salvarCobrancaPix,
  marcarComoPago,
  repassarParaAliExpress,
  confirmarPagamentoAli,
  listarAguardandoPagamentoAli,
  registrarAlertaPagamento,
  destravarPendentes,
  registrarEventoWebhook,
  marcarEventoProcessado,
};
