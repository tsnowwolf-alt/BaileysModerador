import { query, withTransaction } from '../db.js';
import { gerarSlug, slugUnico } from '../lib/aliUrl.js';

const CAMPOS_PRODUTO = `
  id, slug, titulo, descricao, imagens,
  aliexpress_product_id, aliexpress_url,
  estoque_br, origem_verificada_em,
  preco_venda_centavos, preco_custo_centavos, ativo,
  data_criacao, data_atualizacao
`;

const CAMPOS_VARIACAO = `
  id, produto_id, nome, aliexpress_sku_id, aliexpress_sku_attr,
  preco_venda_centavos, preco_custo_centavos, imagem, ativo, ordem
`;

/** Vitrine: so produtos ativos, com pelo menos uma variacao ativa. */
export async function listarPublico({ limite = 50, offset = 0 } = {}) {
  const { rows } = await query(
    `SELECT ${CAMPOS_PRODUTO}
       FROM produtos p
      WHERE ativo = TRUE
        AND EXISTS (
          SELECT 1 FROM produto_variacoes v
           WHERE v.produto_id = p.id AND v.ativo = TRUE
        )
      ORDER BY data_criacao DESC
      LIMIT $1 OFFSET $2`,
    [limite, offset]
  );
  return rows;
}

export async function buscarPorSlug(slug, { somenteAtivo = true } = {}) {
  const { rows } = await query(
    `SELECT ${CAMPOS_PRODUTO} FROM produtos
      WHERE slug = $1 ${somenteAtivo ? 'AND ativo = TRUE' : ''}`,
    [slug]
  );
  if (!rows[0]) return null;

  const variacoes = await listarVariacoes(rows[0].id, { somenteAtivo });
  return { ...rows[0], variacoes };
}

export async function buscarPorId(id) {
  const { rows } = await query(`SELECT ${CAMPOS_PRODUTO} FROM produtos WHERE id = $1`, [id]);
  if (!rows[0]) return null;
  return { ...rows[0], variacoes: await listarVariacoes(id, { somenteAtivo: false }) };
}

export async function listarVariacoes(produtoId, { somenteAtivo = true } = {}) {
  const { rows } = await query(
    `SELECT ${CAMPOS_VARIACAO} FROM produto_variacoes
      WHERE produto_id = $1 ${somenteAtivo ? 'AND ativo = TRUE' : ''}
      ORDER BY ordem ASC, id ASC`,
    [produtoId]
  );
  return rows;
}

/**
 * =====================================================================
 * A funcao que o checkout usa — e a razao de o preco sair daqui
 * =====================================================================
 *
 * Devolve a variacao junto com o preco EFETIVO, resolvendo a heranca
 * (variacao sobrescreve produto) e o custo.
 *
 * O checkout precisa consultar isto em vez de aceitar preco do cliente.
 * Confiar no valor que vem no corpo da requisicao significa que qualquer
 * pessoa pode pedir um produto de R$ 200 por R$ 0,01 — o Pix seria
 * gerado por um centavo e voce compraria o produto de verdade na Ali.
 */
export async function buscarVariacaoParaCompra(variacaoId) {
  const { rows } = await query(
    `SELECT v.id            AS variacao_id,
            v.nome          AS variacao_nome,
            v.aliexpress_sku_id,
            v.aliexpress_sku_attr,
            v.ativo         AS variacao_ativa,
            p.id            AS produto_id,
            p.titulo,
            p.slug,
            p.aliexpress_product_id,
            p.estoque_br,
            p.ativo         AS produto_ativo,
            COALESCE(v.preco_venda_centavos, p.preco_venda_centavos) AS preco_venda_centavos,
            COALESCE(v.preco_custo_centavos, p.preco_custo_centavos) AS preco_custo_centavos
       FROM produto_variacoes v
       JOIN produtos p ON p.id = v.produto_id
      WHERE v.id = $1`,
    [variacaoId]
  );

  const v = rows[0];
  if (!v) return { ok: false, motivo: 'Variacao nao encontrada' };
  if (!v.produto_ativo) return { ok: false, motivo: 'Produto indisponivel' };
  if (!v.variacao_ativa) return { ok: false, motivo: 'Opcao indisponivel' };
  if (!v.aliexpress_sku_attr && !v.aliexpress_sku_id) {
    // Deixar passar aqui produziria um pedido que falha no placeorder
    // depois do cliente ja ter pago.
    return { ok: false, motivo: 'Variacao sem SKU configurado' };
  }

  return { ok: true, variacao: v };
}

/** Cria produto e variacoes numa transacao so. */
export async function criarProduto(dados) {
  return withTransaction(async (client) => {
    const base = dados.slug ? gerarSlug(dados.slug) : gerarSlug(dados.titulo);
    const { rows: existentes } = await client.query(
      `SELECT slug FROM produtos WHERE slug LIKE $1`,
      [`${base}%`]
    );
    const slug = slugUnico(base, existentes.map((r) => r.slug));

    const { rows } = await client.query(
      `INSERT INTO produtos (
         slug, titulo, descricao, imagens,
         aliexpress_product_id, aliexpress_url,
         estoque_br, preco_venda_centavos, preco_custo_centavos, ativo
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING ${CAMPOS_PRODUTO}`,
      [
        slug,
        dados.titulo,
        dados.descricao ?? null,
        JSON.stringify(dados.imagens ?? []),
        dados.aliexpress_product_id,
        dados.aliexpress_url ?? null,
        dados.estoque_br ?? false,
        dados.preco_venda_centavos,
        dados.preco_custo_centavos ?? null,
        dados.ativo ?? false,
      ]
    );

    const produto = rows[0];
    const variacoes = [];

    for (const [i, v] of (dados.variacoes ?? []).entries()) {
      const { rows: vr } = await client.query(
        `INSERT INTO produto_variacoes (
           produto_id, nome, aliexpress_sku_id, aliexpress_sku_attr,
           preco_venda_centavos, preco_custo_centavos, imagem, ativo, ordem
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         RETURNING ${CAMPOS_VARIACAO}`,
        [
          produto.id,
          v.nome,
          v.aliexpress_sku_id ?? null,
          v.aliexpress_sku_attr ?? null,
          v.preco_venda_centavos ?? null,
          v.preco_custo_centavos ?? null,
          v.imagem ?? null,
          v.ativo ?? true,
          v.ordem ?? i,
        ]
      );
      variacoes.push(vr[0]);
    }

    return { ...produto, variacoes };
  });
}

const CAMPOS_EDITAVEIS = [
  'titulo',
  'descricao',
  'imagens',
  'estoque_br',
  'preco_venda_centavos',
  'preco_custo_centavos',
  'ativo',
  'aliexpress_url',
];

export async function atualizarProduto(id, dados) {
  const sets = [];
  const valores = [id];

  for (const campo of CAMPOS_EDITAVEIS) {
    // A distinção importa: `undefined` = campo não enviado, preserva o
    // que está no banco. `null` = enviado vazio de propósito, apaga.
    // Tratar os dois igual tornava impossível limpar um preço de custo
    // pela tela — o valor importado ficava preso para sempre.
    if (dados[campo] === undefined) continue;
    valores.push(campo === 'imagens' ? JSON.stringify(dados[campo]) : dados[campo]);
    sets.push(`${campo} = $${valores.length}`);
  }

  // Marca quando a origem foi conferida, para nao virar dado velho.
  if (dados.estoque_br !== undefined) sets.push('origem_verificada_em = NOW()');

  if (sets.length === 0) return buscarPorId(id);

  const { rows } = await query(
    `UPDATE produtos SET ${sets.join(', ')} WHERE id = $1 RETURNING ${CAMPOS_PRODUTO}`,
    valores
  );
  if (!rows[0]) return null;
  return { ...rows[0], variacoes: await listarVariacoes(id, { somenteAtivo: false }) };
}

export async function listarAdmin() {
  const { rows } = await query(
    `SELECT p.${CAMPOS_PRODUTO.trim().split(/,\s*/).join(', p.')},
            COUNT(v.id) FILTER (WHERE v.ativo) AS variacoes_ativas
       FROM produtos p
       LEFT JOIN produto_variacoes v ON v.produto_id = p.id
      GROUP BY p.id
      ORDER BY p.data_criacao DESC`
  );
  return rows;
}

export async function adicionarVariacao(produtoId, v) {
  const { rows } = await query(
    `INSERT INTO produto_variacoes (
       produto_id, nome, aliexpress_sku_id, aliexpress_sku_attr,
       preco_venda_centavos, preco_custo_centavos, imagem, ativo, ordem
     ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (produto_id, nome) DO UPDATE SET
       aliexpress_sku_id    = EXCLUDED.aliexpress_sku_id,
       aliexpress_sku_attr  = EXCLUDED.aliexpress_sku_attr,
       preco_venda_centavos = EXCLUDED.preco_venda_centavos,
       -- Faltava aqui. Sem esta linha, o custo importado da AliExpress
       -- ficava preso na variação para sempre: a tela deixava editar,
       -- o UPDATE ignorava, e o bloqueio de margem continuava
       -- disparando por um valor que ninguém conseguia mudar.
       preco_custo_centavos = EXCLUDED.preco_custo_centavos,
       imagem               = EXCLUDED.imagem,
       ordem                = EXCLUDED.ordem,
       ativo                = EXCLUDED.ativo
     RETURNING ${CAMPOS_VARIACAO}`,
    [
      produtoId,
      v.nome,
      v.aliexpress_sku_id ?? null,
      v.aliexpress_sku_attr ?? null,
      v.preco_venda_centavos ?? null,
      v.preco_custo_centavos ?? null,
      v.imagem ?? null,
      v.ativo ?? true,
      v.ordem ?? 0,
    ]
  );
  return rows[0];
}

/**
 * Antes de ativar, checa o que costuma faltar. Produto no ar sem SKU ou
 * com margem negativa e prejuizo silencioso.
 */
export async function validarParaAtivacao(id) {
  const produto = await buscarPorId(id);
  if (!produto) return { ok: false, problemas: ['Produto nao encontrado'] };

  const problemas = [];
  const ativas = produto.variacoes.filter((v) => v.ativo);

  if (ativas.length === 0) problemas.push('Nenhuma variacao ativa');
  if (ativas.some((v) => !v.aliexpress_sku_attr && !v.aliexpress_sku_id)) {
    problemas.push('Ha variacao ativa sem SKU — a compra falharia apos o pagamento');
  }
  if (!produto.imagens || produto.imagens.length === 0) problemas.push('Sem imagens');
  if (!produto.estoque_br) {
    problemas.push('Origem BR nao confirmada — pode despachar da China');
  }

  const custo = produto.preco_custo_centavos;
  if (custo != null && produto.preco_venda_centavos <= custo) {
    problemas.push('Preco de venda menor ou igual ao custo');
  }
  if (custo == null) problemas.push('Custo nao informado — margem desconhecida');

  return { ok: problemas.length === 0, problemas, produto };
}

export default {
  listarPublico,
  buscarPorSlug,
  buscarPorId,
  listarVariacoes,
  buscarVariacaoParaCompra,
  criarProduto,
  atualizarProduto,
  listarAdmin,
  adicionarVariacao,
  validarParaAtivacao,
};
