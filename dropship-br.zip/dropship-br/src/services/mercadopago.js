import config from '../config.js';
import { validarAssinaturaMP as validarAssinaturaPura } from '../lib/mpSignature.js';

/**
 * =====================================================================
 * Mercado Pago — cobranca do cliente final
 * =====================================================================
 *
 * Escolhi Pix como caminho principal por um motivo de caixa, nao de
 * preferencia: o Pix cai na hora. Cartao parcelado no Brasil liquida
 * em D+30, e a AliExpress cancela pedido nao pago muito antes disso.
 * Vender no cartao sem capital de giro proprio significa nao ter como
 * pagar o fornecedor a tempo.
 *
 * Se voce for aceitar cartao, tenha reserva para bancar o intervalo,
 * ou negocie antecipacao de recebiveis com o gateway.
 */

const API = 'https://api.mercadopago.com';

async function mpFetch(caminho, { method = 'GET', body, idempotencyKey } = {}) {
  if (!config.MP_ACCESS_TOKEN) {
    throw new Error('MP_ACCESS_TOKEN nao configurado');
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);

  try {
    const res = await fetch(`${API}${caminho}`, {
      method,
      headers: {
        Authorization: `Bearer ${config.MP_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
        ...(idempotencyKey ? { 'X-Idempotency-Key': idempotencyKey } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });

    const json = await res.json().catch(() => ({}));

    if (!res.ok) {
      const msg = json.message || json.error || `HTTP ${res.status}`;
      const err = new Error(`Mercado Pago: ${msg}`);
      err.status = res.status;
      err.detalhes = json.cause ?? json;
      throw err;
    }

    return json;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Cria uma cobranca Pix e devolve o copia-e-cola + QR em base64.
 *
 * @param {object} pedido linha da tabela `pedidos`
 * @param {number} valorCentavos
 */
export async function criarCobrancaPix(pedido, valorCentavos) {
  const pagamento = await mpFetch('/v1/payments', {
    method: 'POST',
    // A chave de idempotencia impede cobranca duplicada se a requisicao
    // for reenviada por timeout de rede.
    idempotencyKey: `pedido-${pedido.id}-pix`,
    body: {
      transaction_amount: Number((valorCentavos / 100).toFixed(2)),
      description: `Pedido #${pedido.id}`,
      payment_method_id: 'pix',
      external_reference: pedido.referencia_externa,
      notification_url: config.MP_NOTIFICATION_URL || undefined,
      date_of_expiration: new Date(Date.now() + 30 * 60_000).toISOString(),
      payer: {
        email: pedido.cliente_email || 'comprador@exemplo.com',
        first_name: pedido.cliente_nome.split(' ')[0],
        last_name: pedido.cliente_nome.split(' ').slice(1).join(' ') || '.',
        identification: { type: 'CPF', number: pedido.cliente_cpf },
      },
    },
  });

  const tx = pagamento.point_of_interaction?.transaction_data ?? {};

  return {
    paymentId: String(pagamento.id),
    status: pagamento.status,
    qrCode: tx.qr_code ?? null,
    qrCodeBase64: tx.qr_code_base64 ?? null,
    ticketUrl: tx.ticket_url ?? null,
    expiraEm: pagamento.date_of_expiration ?? null,
  };
}

/** Consulta a fonte da verdade: o webhook so avisa que algo mudou. */
export async function consultarPagamento(paymentId) {
  const p = await mpFetch(`/v1/payments/${paymentId}`);
  return {
    id: String(p.id),
    status: p.status,
    statusDetail: p.status_detail,
    externalReference: p.external_reference ?? null,
    valorCentavos: Math.round(Number(p.transaction_amount ?? 0) * 100),
    metodo: p.payment_method_id ?? null,
    aprovadoEm: p.date_approved ?? null,
  };
}

/**
 * Valida a assinatura do webhook. A logica pura mora em
 * lib/mpSignature.js; aqui so injetamos o segredo do ambiente.
 *
 * O segredo sai em: Suas integracoes > sua aplicacao > Webhooks >
 * Configurar notificacao > revelar chave secreta.
 */
export function validarAssinaturaMP(entrada) {
  return validarAssinaturaPura(entrada, config.MP_WEBHOOK_SECRET);
}

/**
 * =====================================================================
 * Estorno
 * =====================================================================
 *
 * Devolve o dinheiro ao cliente. Sem valor, estorna tudo.
 *
 * A chave de idempotencia e derivada do pedido: se a requisicao for
 * repetida por timeout de rede, o Mercado Pago reconhece e nao devolve
 * duas vezes. Estorno duplicado sai do seu bolso.
 */
const ERROS_ESTORNO = {
  "Collector hasn't enough available money":
    'Sem saldo disponível na conta Mercado Pago para estornar. ' +
    'O dinheiro pode já ter sido transferido para o banco, ou ainda estar em liberação. ' +
    'Deixe saldo na conta e tente de novo.',
  'Payment already refunded': 'Este pagamento já foi estornado.',
  'The payment is not in a valid state':
    'O pagamento não está num estado que permita estorno. Confira no painel do Mercado Pago.',
  'Refund period expired':
    'Passou o prazo de estorno pela API. Faça manualmente pelo painel do Mercado Pago.',
};

function traduzirErroEstorno(mensagem) {
  const texto = String(mensagem ?? '');
  for (const [trecho, traducao] of Object.entries(ERROS_ESTORNO)) {
    if (texto.includes(trecho)) return traducao;
  }
  return texto;
}

export async function estornarPagamento(paymentId, { valorCentavos, chave } = {}) {
  const corpo = valorCentavos ? { amount: Number((valorCentavos / 100).toFixed(2)) } : {};

  let r;
  try {
    r = await mpFetch(`/v1/payments/${paymentId}/refunds`, {
      method: 'POST',
      body: corpo,
      idempotencyKey: chave ?? `refund-${paymentId}`,
    });
  } catch (err) {
    // A mensagem crua vem em inglês e não diz o que fazer. Quem lê isso
    // está com dinheiro de cliente na mão e precisa de uma instrução.
    const traduzida = traduzirErroEstorno(err.message);
    const novo = new Error(traduzida);
    novo.status = err.status;
    novo.detalhes = err.detalhes;
    throw novo;
  }

  return {
    id: String(r.id ?? ''),
    status: r.status ?? null,
    valorCentavos: Math.round(Number(r.amount ?? 0) * 100),
    criadoEm: r.date_created ?? null,
  };
}

/**
 * Diagnostico da configuracao, sem criar cobranca nenhuma.
 *
 * Consulta os meios de pagamento habilitados na conta. Isso responde de
 * uma vez as tres perguntas que importam: o token e valido, o token e
 * de teste ou producao, e o Pix esta liberado. A causa mais comum de
 * "nao foi possivel gerar a cobranca" e a conta nao ter chave Pix
 * habilitada — e isso aparece aqui sem gastar um centavo.
 */
export async function diagnosticarMP() {
  const resultado = {
    token_configurado: Boolean(config.MP_ACCESS_TOKEN),
    ambiente: null,
    token_valido: false,
    pix_disponivel: false,
    webhook_secret_configurado: Boolean(config.MP_WEBHOOK_SECRET),
    notification_url: config.MP_NOTIFICATION_URL || null,
    meios: [],
    erro: null,
  };

  if (!resultado.token_configurado) {
    resultado.erro = 'MP_ACCESS_TOKEN nao configurado';
    return resultado;
  }

  try {
    // O prefixo do token NAO serve mais para saber o ambiente: as
    // credenciais de teste de varias contas vem como APP_USR-. Quem
    // responde de verdade e /users/me — usuarios de teste tem e-mail
    // no dominio testuser.com.
    const conta = await mpFetch('/users/me');
    resultado.token_valido = true;
    resultado.conta = {
      id: conta.id ?? null,
      nickname: conta.nickname ?? null,
      site: conta.site_id ?? null,
    };
    const email = String(conta.email ?? '');
    resultado.ambiente = /@testuser\.com$/i.test(email) ? 'teste' : 'producao';

    if (resultado.ambiente === 'teste') {
      resultado.aviso_pix =
        'Conta de teste: o Mercado Pago nao permite gerar Pix com credenciais de teste. Use as de producao.';
    }

    const meios = await mpFetch('/v1/payment_methods');
    resultado.meios = (Array.isArray(meios) ? meios : [])
      .filter((m) => m.status === 'active')
      .map((m) => m.id);
    resultado.pix_disponivel = resultado.meios.includes('pix');

    if (!resultado.pix_disponivel) {
      resultado.erro =
        'Pix nao aparece entre os meios ativos da conta. Cadastre uma chave Pix na conta Mercado Pago.';
    }
  } catch (err) {
    resultado.erro = err.message;
    resultado.detalhes = err.detalhes ?? null;
    resultado.http_status = err.status ?? null;
  }

  return resultado;
}

export const STATUS_APROVADO = new Set(['approved']);

export default {
  diagnosticarMP,
  estornarPagamento,
  criarCobrancaPix,
  consultarPagamento,
  validarAssinaturaMP,
  STATUS_APROVADO,
};
