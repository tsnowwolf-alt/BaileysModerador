import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import config from './config.js';
import logger from './lib/logger.js';
import { pool, closePool } from './db.js';
import { marcarEncerrando, aguardarConclusao, estaEncerrando } from './lib/emAndamento.js';
import pkg from '../package.json' with { type: 'json' };

import webhookRouter from './routes/webhook.js';
import rastreioRouter from './routes/rastreio.js';
import pedidosRouter from './routes/pedidos.js';
import adminRouter from './routes/admin.js';
import catalogoRouter from './routes/catalogo.js';

const app = express();

// Railway roda atras de proxy: sem isso, req.ip vira o IP do proxy e o
// rate limit passa a limitar o mundo inteiro como se fosse um cliente so.
app.set('trust proxy', 1);
app.disable('x-powered-by');

// Cabecalhos de seguranca basicos (sem dependencia extra).
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
  });
  next();
});

app.use((req, res, next) => {
  const inicio = Date.now();
  res.on('finish', () => {
    logger.info('http', {
      metodo: req.method,
      rota: req.originalUrl.split('?')[0],
      status: res.statusCode,
      ms: Date.now() - inicio,
    });
  });
  next();
});

app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    if (estaEncerrando()) {
      return res.status(503).json({ ok: false, motivo: 'encerrando' });
    }
    res.json({
      ok: true,
      // Versao do pacote: serve para conferir, de fora, qual codigo
      // esta realmente no ar depois de um deploy.
      versao: pkg.version,
      dry_run: config.ALI_DRY_RUN,
      ts: new Date().toISOString(),
    });
  } catch (err) {
    res.status(503).json({ ok: false, erro: 'banco indisponivel' });
  }
});

// IMPORTANTE: o router de webhook vem ANTES de qualquer express.json()
// global — ele precisa do corpo cru para validar a assinatura HMAC.
app.use('/webhook', webhookRouter);
app.use('/api/pedidos', pedidosRouter);
app.use('/api/rastreio', rastreioRouter);
app.use('/api/catalogo', catalogoRouter);
app.use('/api/admin', adminRouter);

// ---------------------------------------------------------------------
// Frontend estatico
//
// Servido DEPOIS das rotas de API: assim /api/* e /webhook/* sao
// resolvidos primeiro e nunca sao confundidos com arquivo. E o 404 de
// API continua devolvendo JSON, nao HTML.
// ---------------------------------------------------------------------
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(
  express.static(path.join(__dirname, '..', 'public'), {
    // 'no-cache' NAO significa "nao guarde" — significa "confirme antes
    // de usar o que guardou". Com o ETag que o express.static ja envia,
    // o navegador manda um pedido curto e recebe 304 quando nada mudou,
    // entao nao ha redownload; e quando o arquivo muda, ele pega a
    // versao nova na hora.
    //
    // A versao anterior usava max-age=3600 para CSS e JS, e isso criava
    // um modo de falha desagradavel: depois de um deploy, o navegador
    // rodava o HTML novo com o JavaScript velho por ate uma hora. Bug
    // ja corrigido continuava aparecendo, e nao havia como saber que a
    // causa era o cache.
    etag: true,
    setHeaders: (res) => {
      res.set('Cache-Control', 'no-cache');
    },
  })
);

// 404 de API responde JSON; qualquer outra coisa cai na loja.
app.use((req, res) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/webhook')) {
    return res.status(404).json({ erro: 'rota nao encontrada' });
  }
  res.status(404).sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  logger.error('Erro nao tratado', { erro: err.message, stack: err.stack });
  res.status(500).json({ erro: 'erro interno' });
});

const server = app.listen(config.PORT, '0.0.0.0', () => {
  logger.info('Servidor no ar', { porta: config.PORT, env: config.NODE_ENV });
});

// Railway envia SIGTERM no deploy. Encerrar direito evita cortar uma
// chamada ao AliExpress no meio e deixar pedido em estado ambiguo.
/**
 * Desligamento gracioso.
 *
 * O Railway manda SIGTERM a cada deploy. Sem isto, uma chamada ao
 * AliExpress em andamento seria cortada no meio e o pedido ficaria em
 * estado ambíguo. Paramos de aceitar conexões novas, esperamos o que
 * está rodando, e só então saímos.
 *
 * O teto de 10s existe porque o Railway não espera indefinidamente. O
 * que não couber é recuperado pela reconciliação no próximo ciclo do
 * cron — o desligamento encurta a janela, a reconciliação a fecha.
 */
for (const sinal of ['SIGTERM', 'SIGINT']) {
  process.on(sinal, async () => {
    logger.info('Encerrando', { sinal });
    marcarEncerrando();

    server.close(async () => {
      await aguardarConclusao(10_000);
      await closePool();
      logger.info('Encerrado com segurança');
      process.exit(0);
    });

    setTimeout(() => {
      logger.warn('Tempo de encerramento esgotado; saindo à força');
      process.exit(1);
    }, 20_000).unref();
  });
}

// O healthcheck passa a recusar durante o encerramento, para o Railway
// parar de mandar tráfego para esta réplica.
process.on('uncaughtException', (err) => {
  logger.error('uncaughtException', { erro: err.message, stack: err.stack });
});

process.on('unhandledRejection', (err) => {
  logger.error('unhandledRejection', { erro: String(err) });
});

export default app;
