import { query } from '../db.js';
import logger from '../lib/logger.js';
import { alertar } from '../lib/alertas.js';
import * as pedidosService from '../services/pedidos.js';
import { consultarPagamento, STATUS_APROVADO } from '../services/mercadopago.js';

/**
 * =====================================================================
 * Reconciliação
 * =====================================================================
 *
 * Três varreduras que consertam o que reinicialização, queda de rede ou
 * webhook perdido deixaram pelo caminho. Rodam a cada ciclo do cron.
 *
 * O princípio: NENHUM caminho crítico pode depender de o processo ficar
 * vivo até o fim. O banco guarda a intenção; a reconciliação garante
 * que ela se cumpra, mesmo que em outro processo, minutos depois.
 *
 * Cada varredura é idempotente — reprocessar não duplica nada, porque
 * o lock atômico em repassarParaAliExpress só deixa passar uma vez.
 */

/**
 * A) Webhooks recebidos e não processados.
 *
 * O webhook grava o evento, responde 200 e processa depois. Se o
 * processo morre nesse meio, o Mercado Pago não reenvia (já demos 200)
 * e o pedido some. Aqui é onde ele reaparece.
 */
async function webhooksOrfaos(minutos = 2) {
  const { rows } = await query(
    `SELECT evento_id, payload
       FROM webhook_eventos
      WHERE processado_em IS NULL
        AND origem = 'mercadopago'
        AND recebido_em < NOW() - ($1 || ' minutes')::interval
      ORDER BY recebido_em ASC
      LIMIT 20`,
    [String(minutos)]
  );

  let recuperados = 0;

  for (const evento of rows) {
    const paymentId = String(
      evento.payload?.data?.id ?? evento.payload?.id ?? ''
    ).trim();

    if (!paymentId) {
      await pedidosService.marcarEventoProcessado(evento.evento_id, 'sem payment id');
      continue;
    }

    try {
      if (await processarPagamento(paymentId, evento.evento_id)) recuperados += 1;
    } catch (err) {
      logger.error('Falha ao recuperar webhook órfão', {
        eventoId: evento.evento_id,
        erro: err.message,
      });
    }
  }

  if (recuperados > 0) {
    logger.warn('Webhooks recuperados pela reconciliação', { recuperados });
  }
  return recuperados;
}

/**
 * B) Pedidos pagos que nunca chegaram à AliExpress.
 *
 * Rede independente da tabela de webhooks: olha o estado real do
 * pedido. Pega qualquer caminho que tenha falhado, inclusive os que
 * nem passaram por webhook.
 */
async function pagosSemRepasse(minutos = 5) {
  const { rows } = await query(
    `SELECT id FROM pedidos
      WHERE status_pedido = 'pago_no_site'
        AND aliexpress_order_id IS NULL
        AND data_pagamento < NOW() - ($1 || ' minutes')::interval
      ORDER BY data_pagamento ASC
      LIMIT 20`,
    [String(minutos)]
  );

  let repassados = 0;

  for (const p of rows) {
    logger.warn('Pedido pago sem repasse; reprocessando', { pedidoId: p.id });
    const r = await pedidosService.repassarParaAliExpress(p.id);
    if (r.status === 'ok') repassados += 1;
  }

  return repassados;
}

/**
 * C) Pagamentos aprovados cujo webhook nunca chegou.
 *
 * A varredura mais ampla: em vez de esperar o aviso, perguntamos ao
 * Mercado Pago sobre cada cobrança pendente. Cobre webhook perdido,
 * URL mal configurada e indisponibilidade do nosso lado — casos em que
 * as varreduras A e B nunca ficariam sabendo do pagamento.
 */
async function cobrancasPendentes(minutos = 10, limite = 15) {
  const { rows } = await query(
    `SELECT id, mp_payment_id FROM pedidos
      WHERE status_pedido = 'aguardando_pagamento'
        AND mp_payment_id IS NOT NULL
        AND data_criacao > NOW() - interval '7 days'
        AND data_criacao < NOW() - ($1 || ' minutes')::interval
      ORDER BY data_criacao DESC
      LIMIT $2`,
    [String(minutos), limite]
  );

  let achados = 0;

  for (const p of rows) {
    try {
      const pagamento = await consultarPagamento(p.mp_payment_id);
      if (!STATUS_APROVADO.has(pagamento.status)) continue;

      logger.warn('Pagamento aprovado sem webhook; recuperando', {
        pedidoId: p.id,
        paymentId: p.mp_payment_id,
      });

      await pedidosService.marcarComoPago(p.id, {
        valorCentavos: pagamento.valorCentavos,
        mpStatus: pagamento.status,
        mpMetodo: pagamento.metodo,
      });
      await pedidosService.repassarParaAliExpress(p.id);
      achados += 1;
    } catch (err) {
      logger.error('Falha ao conferir cobrança pendente', {
        pedidoId: p.id,
        erro: err.message,
      });
    }
    await new Promise((r) => setTimeout(r, 250)); // respeita o limite do MP
  }

  if (achados > 0) {
    await alertar('Pagamentos recuperados sem webhook', {
      quantidade: achados,
      atencao: 'O webhook do Mercado Pago pode estar mal configurado.',
    });
  }
  return achados;
}

/** Lógica compartilhada entre o webhook e a recuperação. */
async function processarPagamento(paymentId, eventoId) {
  const pagamento = await consultarPagamento(paymentId);

  if (!STATUS_APROVADO.has(pagamento.status)) {
    await pedidosService.marcarEventoProcessado(eventoId);
    return false;
  }

  if (!pagamento.externalReference) {
    await pedidosService.marcarEventoProcessado(eventoId, 'sem external_reference');
    return false;
  }

  const pedido = await pedidosService.buscarPorReferencia(pagamento.externalReference);
  if (!pedido) {
    await pedidosService.marcarEventoProcessado(eventoId, 'pedido nao encontrado');
    return false;
  }

  if (pedido.valor_total_centavos && pagamento.valorCentavos < pedido.valor_total_centavos) {
    await pedidosService.marcarEventoProcessado(eventoId, 'valor divergente');
    return false;
  }

  await pedidosService.marcarComoPago(pedido.id, {
    valorCentavos: pagamento.valorCentavos,
    mpPaymentId: pagamento.id,
    mpStatus: pagamento.status,
    mpMetodo: pagamento.metodo,
  });

  const resultado = await pedidosService.repassarParaAliExpress(pedido.id);
  await pedidosService.marcarEventoProcessado(
    eventoId,
    resultado.status === 'erro' ? resultado.motivo : null
  );

  return true;
}

export async function reconciliar() {
  const inicio = Date.now();
  const conta = { webhooks: 0, repasses: 0, pagamentos: 0 };

  // Cada varredura é isolada: uma falhar não pode impedir as outras.
  try {
    conta.webhooks = await webhooksOrfaos();
  } catch (err) {
    logger.error('Varredura de webhooks falhou', { erro: err.message });
  }

  try {
    conta.repasses = await pagosSemRepasse();
  } catch (err) {
    logger.error('Varredura de repasses falhou', { erro: err.message });
  }

  try {
    conta.pagamentos = await cobrancasPendentes();
  } catch (err) {
    logger.error('Varredura de cobranças falhou', { erro: err.message });
  }

  const total = conta.webhooks + conta.repasses + conta.pagamentos;
  if (total > 0) {
    logger.warn('Reconciliação recuperou pedidos', { ...conta, ms: Date.now() - inicio });
  }

  return conta;
}

export { processarPagamento };
export default { reconciliar, processarPagamento };
