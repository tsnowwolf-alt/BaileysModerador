import config from '../config.js';
import logger from '../lib/logger.js';
import { query, closePool } from '../db.js';
import { alertar } from '../lib/alertas.js';
import {
  consultarPedidoAli,
  classificarStatusAli,
  linkPedidoAli,
  LINK_PEDIDOS_PENDENTES,
} from '../aliexpress/orders.js';
import { nivelDevido, tomDoAlerta, formatarDuracao } from '../lib/escalonamento.js';
import { horasParaExpirar, renovarToken, limparCache } from '../aliexpress/auth.js';
import { reconciliar } from './reconciliacao.js';
import * as pedidosService from '../services/pedidos.js';
import { rastrear } from '../services/linketrack.js';

/**
 * Cron unico do sistema. Roda tres frentes, nesta ordem de prioridade:
 *
 *  A) 'aguardando_pagamento_ali' -> o pagamento na Ali entrou?
 *  B) 'processado_ali'           -> o fornecedor postou?
 *  C) 'enviado'                  -> os Correios entregaram?
 *
 * A frente A e a nova, e a mais importante. Sem ela, um pedido criado
 * mas nao pago fica invisivel ate o cliente reclamar.
 *
 * FOR UPDATE SKIP LOCKED: se dois ciclos se sobrepuserem, cada um pega
 * pedidos diferentes em vez de brigar pela mesma linha.
 * Pausa entre chamadas: a Open Platform limita QPS e devolve
 * 'accesscontrol.limited-by-api-access-count' quando voce estoura.
 */

const PAUSA_MS = 350;
const pausa = (ms) => new Promise((r) => setTimeout(r, ms));

async function buscarLote(status, limite) {
  const { rows } = await query(
    `SELECT id, aliexpress_order_id, codigo_rastreio, data_pedido_ali,
            alerta_pagamento_em, nivel_alerta, valor_total_centavos,
            EXTRACT(EPOCH FROM (NOW() - data_pedido_ali))/60 AS minutos_parado
       FROM pedidos
      WHERE status_pedido = $1
        AND aliexpress_order_id IS NOT NULL
      ORDER BY data_atualizacao ASC
      LIMIT $2
      FOR UPDATE SKIP LOCKED`,
    [status, limite]
  );
  return rows;
}

/**
 * FRENTE A — o pedido existe na Ali, mas o dinheiro entrou?
 */
async function verificarPagamentoAli(pedido) {
  const info = await consultarPedidoAli(pedido.aliexpress_order_id);
  const classe = classificarStatusAli(info.status);

  await query(`UPDATE pedidos SET ali_order_status = $2 WHERE id = $1`, [
    pedido.id,
    info.status,
  ]);

  if (classe === 'cancelado') {
    await query(
      `UPDATE pedidos SET status_pedido = 'cancelado_ali',
              ultimo_erro = 'Pedido cancelado na AliExpress (provavel expiracao do prazo de pagamento)'
        WHERE id = $1`,
      [pedido.id]
    );
    await alertar('🔴 Pedido CANCELADO na AliExpress', {
      pedido: `#${pedido.id}`,
      ali_order_id: pedido.aliexpress_order_id,
      parado_ha: formatarDuracao(Number(pedido.minutos_parado ?? 0)),
      acao: 'O cliente pagou e nao ha pedido. Refaca a compra ou estorne.',
    });
    return 'cancelado';
  }

  // Pagamento confirmado: segue o fluxo normal.
  if (['pago', 'enviado', 'finalizado'].includes(classe)) {
    await pedidosService.confirmarPagamentoAli(pedido.id, info.status);
    logger.info('Pagamento confirmado na AliExpress', {
      pedidoId: pedido.id,
      status: info.status,
    });
    return 'pago';
  }

  // ---- Continua nao pago: escalonamento ----
  // Um aviso so, disparado uma vez, e facil de perder. O nivel sobe a
  // cada marco ultrapassado e o tom acompanha.
  const escala = config.ALI_ALERTA_ESCALONAMENTO;
  const minutos = Number(pedido.minutos_parado ?? 0);
  const devido = nivelDevido(minutos, escala);
  const enviado = Number(pedido.nivel_alerta ?? 0);

  if (devido > enviado) {
    const tom = tomDoAlerta(devido, escala.length);
    const prazoMin = config.ALI_PRAZO_PAGAMENTO_HORAS * 60;
    const restam = Math.max(0, prazoMin - minutos);

    await alertar(
      `${tom.prefixo} ${tom.titulo}`,
      {
        pedido: `#${pedido.id}`,
        ali_order_id: pedido.aliexpress_order_id,
        parado_ha: formatarDuracao(minutos),
        tempo_restante: restam > 0 ? `~${formatarDuracao(restam)}` : 'PRAZO ESTOURADO',
        valor_cliente: pedido.valor_total_centavos
          ? `R$ ${(pedido.valor_total_centavos / 100).toFixed(2)}`
          : '-',
        status_ali: info.status ?? 'desconhecido',
        aviso:
          devido >= escala.length
            ? 'Se expirar, o cliente pagou e nao ha pedido. Pague ou estorne agora.'
            : `Aviso ${devido} de ${escala.length}.`,
      },
      {
        // Primeiro aviso sem som; a partir do segundo, notifica de fato.
        silencioso: devido === 1,
        botoes: [
          { texto: '💰 Pagar este pedido', url: linkPedidoAli(pedido.aliexpress_order_id) },
          { texto: '📋 Ver todos os pendentes', url: LINK_PEDIDOS_PENDENTES },
        ],
      }
    );

    await pedidosService.registrarAlertaPagamento(pedido.id, devido);
    return 'alertado';
  }

  await query(`UPDATE pedidos SET data_atualizacao = NOW() WHERE id = $1`, [pedido.id]);
  return 'aguardando';
}

/** FRENTE B — o fornecedor postou? */
async function verificarPostagem(pedido) {
  const info = await consultarPedidoAli(pedido.aliexpress_order_id);

  if (!info.trackingNumber) {
    await query(
      `UPDATE pedidos SET data_atualizacao = NOW(), ali_order_status = $2 WHERE id = $1`,
      [pedido.id, info.status]
    );
    return false;
  }

  await query(
    `UPDATE pedidos
        SET codigo_rastreio  = $2,
            transportadora   = COALESCE($3, transportadora),
            ali_order_status = $4,
            status_pedido    = 'enviado',
            data_envio       = COALESCE(data_envio, NOW())
      WHERE id = $1
        AND status_pedido = 'processado_ali'`,
    [pedido.id, info.trackingNumber, info.transportadora, info.status]
  );

  logger.info('Pedido marcado como enviado', {
    pedidoId: pedido.id,
    rastreio: info.trackingNumber,
  });
  return true;
}

/** FRENTE C — entregue? */
async function verificarEntrega(pedido) {
  if (!pedido.codigo_rastreio) return false;

  const r = await rastrear(pedido.codigo_rastreio, { ignorarCache: true });
  if (!r.disponivel || !r.entregue) return false;

  await query(
    `UPDATE pedidos SET status_pedido = 'entregue' WHERE id = $1 AND status_pedido = 'enviado'`,
    [pedido.id]
  );
  logger.info('Pedido entregue', { pedidoId: pedido.id });
  return true;
}

/**
 * Renova o token da AliExpress antes de expirar.
 *
 * A janela de 72h existe para dar margem: se a renovação falhar hoje,
 * ainda restam dois ciclos diários para tentar de novo antes de o
 * sistema parar de repassar pedidos. Sem isso, a falha só apareceria
 * quando um cliente já tivesse pago.
 */
async function renovarTokenSePreciso() {
  try {
    const horas = await horasParaExpirar();
    if (horas == null || horas > 72) return;

    logger.warn('Token da AliExpress perto de expirar; renovando', {
      horas: Math.round(horas),
    });
    await renovarToken();
    limparCache();
  } catch (err) {
    logger.error('Falha ao renovar o token da AliExpress', { erro: err.message });
    await alertar('Token da AliExpress vai expirar', {
      erro: err.message,
      acao: 'Abra o painel, aba Sistema, e autorize de novo.',
    });
  }
}

export async function rodar() {
  const inicio = Date.now();
  const limite = config.TRACKING_JOB_BATCH_SIZE;
  const contagem = { pagos: 0, alertados: 0, cancelados: 0, postados: 0, entregues: 0, erros: 0 };

  await renovarTokenSePreciso();
  await pedidosService.destravarPendentes(15);

  // Antes de qualquer outra coisa: recuperar o que ficou para trás.
  // Pedido pago sem repasse é o problema mais caro do sistema.
  const recuperados = await reconciliar();

  for (const pedido of await buscarLote('aguardando_pagamento_ali', limite)) {
    try {
      const r = await verificarPagamentoAli(pedido);
      if (r === 'pago') contagem.pagos++;
      if (r === 'alertado') contagem.alertados++;
      if (r === 'cancelado') contagem.cancelados++;
    } catch (err) {
      contagem.erros++;
      logger.error('Erro ao verificar pagamento na Ali', {
        pedidoId: pedido.id,
        erro: err.message,
      });
    }
    await pausa(PAUSA_MS);
  }

  for (const pedido of await buscarLote('processado_ali', limite)) {
    try {
      if (await verificarPostagem(pedido)) contagem.postados++;
    } catch (err) {
      contagem.erros++;
      logger.error('Erro ao consultar pedido na AliExpress', {
        pedidoId: pedido.id,
        erro: err.message,
      });
    }
    await pausa(PAUSA_MS);
  }

  for (const pedido of await buscarLote('enviado', limite)) {
    try {
      if (await verificarEntrega(pedido)) contagem.entregues++;
    } catch (err) {
      contagem.erros++;
      logger.error('Erro ao consultar rastreio', { pedidoId: pedido.id, erro: err.message });
    }
    await pausa(PAUSA_MS);
  }

  logger.info('Ciclo concluido', {
    ...contagem,
    recuperados,
    ms: Date.now() - inicio,
  });
  return { ...contagem, recuperados };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const intervalo = config.TRACKING_JOB_INTERVAL_MINUTES;

  if (intervalo > 0) {
    logger.info('Worker iniciado', { intervaloMin: intervalo });
    const loop = async () => {
      try {
        await rodar();
      } catch (err) {
        logger.error('Ciclo falhou', { erro: err.message });
      }
    };
    await loop();
    setInterval(loop, intervalo * 60_000);
  } else {
    try {
      await rodar();
      await closePool();
      process.exit(0);
    } catch (err) {
      logger.error('Job falhou', { erro: err.message });
      await closePool();
      process.exit(1);
    }
  }
}

export default { rodar };
