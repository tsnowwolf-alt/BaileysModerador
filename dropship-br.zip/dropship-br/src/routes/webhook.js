import express from 'express';
import config from '../config.js';
import logger from '../lib/logger.js';
import * as pedidosService from '../services/pedidos.js';
import { validarAssinaturaMP } from '../services/mercadopago.js';
import { emSegundoPlano } from '../lib/emAndamento.js';
import { processarPagamento } from '../jobs/reconciliacao.js';

const router = express.Router();

/**
 * =====================================================================
 * SEGURANCA — leia antes de mexer
 * =====================================================================
 *
 * Esta rota dispara uma COMPRA COM DINHEIRO REAL. Sem validacao de
 * assinatura, qualquer pessoa que descubra a URL pode fazer um POST e
 * te obrigar a comprar produtos no AliExpress.
 *
 * Duas defesas independentes aqui:
 *   1. assinatura x-signature do Mercado Pago (HMAC-SHA256 do manifest)
 *   2. reconsulta do pagamento na API do MP antes de agir
 *
 * A defesa 2 e a que realmente importa: mesmo que alguem forje um
 * webhook dizendo "aprovado", nos perguntamos ao Mercado Pago e ele
 * responde a verdade. O corpo do webhook nunca e fonte de verdade —
 * ele so avisa que ALGO mudou naquele pagamento.
 */

// Corpo cru: o MP assina o manifest, mas manter raw evita surpresa
// se voce trocar de gateway depois.
const rawBody = express.raw({ type: '*/*', limit: '256kb' });

router.post('/mercadopago', rawBody, async (req, res) => {
  const dataId = req.query['data.id'] ?? req.query.id ?? null;

  const verificacao = validarAssinaturaMP({
    xSignature: req.get('x-signature'),
    xRequestId: req.get('x-request-id'),
    dataId,
  });

  if (!verificacao.ok) {
    logger.warn('Webhook do Mercado Pago rejeitado', {
      motivo: verificacao.motivo,
      ip: req.ip,
    });
    return res.status(401).json({ erro: 'assinatura invalida' });
  }

  let evento = {};
  try {
    evento = JSON.parse(req.body.toString('utf8') || '{}');
  } catch {
    evento = {};
  }

  const paymentId = String(dataId ?? evento.data?.id ?? '');
  const tipo = evento.type ?? evento.topic ?? 'payment';

  if (!paymentId) {
    return res.status(400).json({ erro: 'data.id ausente' });
  }

  // O MP so notifica pagamentos aqui; outros topicos sao ignorados.
  if (!String(tipo).includes('payment')) {
    return res.status(200).json({ recebido: true, ignorado: tipo });
  }

  // Idempotencia. Responder 200 em duplicata e importante: erro faz o
  // MP reenviar indefinidamente.
  const eventoId = `mp-${paymentId}-${evento.action ?? 'update'}-${req.get('x-request-id') ?? ''}`;
  const novo = await pedidosService.registrarEventoWebhook(eventoId, 'mercadopago', evento);
  if (!novo) {
    logger.info('Webhook duplicado, ignorado', { eventoId });
    return res.status(200).json({ recebido: true, duplicado: true });
  }

  // ACK imediato: o MP dá timeout em poucos segundos e a chamada ao
  // AliExpress pode passar disso. Processar depois do ACK evita retries
  // desnecessarios (e portanto risco de compra duplicada).
  res.status(200).json({ recebido: true });

  // Contabilizado para o desligamento esperar. E se mesmo assim o
  // processo morrer aqui, a reconciliação no cron recupera: o evento
  // fica gravado com processado_em NULL.
  emSegundoPlano(`webhook ${eventoId}`, () => processar(paymentId, eventoId));
});

/**
 * Uma única implementação, usada pelo webhook e pela reconciliação.
 * Duas cópias divergiriam com o tempo, e a que roda menos — a de
 * recuperação — seria justamente a menos testada.
 */
async function processar(paymentId, eventoId) {
  try {
    await processarPagamento(paymentId, eventoId);
    logger.info('Webhook processado', { eventoId, paymentId });
  } catch (err) {
    logger.error('Erro no processamento assincrono do webhook', {
      eventoId,
      erro: err.message,
    });
    // NÃO marcamos como processado: assim a reconciliação tenta de novo.
  }
}

/**
 * Retry manual — util quando um pedido caiu em 'erro_ali'.
 */
router.post('/reprocessar/:pedidoId', express.json(), async (req, res) => {
  if (req.get('x-admin-token') !== config.ADMIN_TOKEN) {
    return res.status(401).json({ erro: 'nao autorizado' });
  }

  const id = Number(req.params.pedidoId);
  if (!Number.isInteger(id)) return res.status(400).json({ erro: 'pedidoId invalido' });

  const pedido = await pedidosService.buscarPorId(id);
  if (!pedido) return res.status(404).json({ erro: 'pedido nao encontrado' });

  if (pedido.status_pedido === 'erro_ali') {
    await pedidosService.marcarComoPago(id);
  }

  const resultado = await pedidosService.repassarParaAliExpress(id);
  res.json(resultado);
});

export default router;
