import express from 'express';
import rateLimit from 'express-rate-limit';
import * as produtosService from '../services/produtos.js';

const router = express.Router();

const limite = rateLimit({ windowMs: 60_000, limit: 60 });

/**
 * Formata para o frontend: preco em centavos (para calculo) e em reais
 * ja formatado (para exibicao). Assim a vitrine nao precisa repetir a
 * logica de formatacao e arredondamento em cada tela.
 */
const emReais = (centavos) =>
  centavos == null
    ? null
    : (centavos / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

function formatarProduto(p, { comVariacoes = false } = {}) {
  const saida = {
    id: p.id,
    slug: p.slug,
    titulo: p.titulo,
    imagens: p.imagens ?? [],
    preco_centavos: p.preco_venda_centavos,
    preco: emReais(p.preco_venda_centavos),
    estoque_br: p.estoque_br,
  };

  if (p.descricao) saida.descricao = p.descricao;

  if (comVariacoes) {
    saida.variacoes = (p.variacoes ?? []).map((v) => ({
      id: v.id,
      nome: v.nome,
      imagem: v.imagem,
      preco_centavos: v.preco_venda_centavos ?? p.preco_venda_centavos,
      preco: emReais(v.preco_venda_centavos ?? p.preco_venda_centavos),
    }));
  }

  // Custo e margem NUNCA saem daqui. Sao dados internos: quem consome
  // esta rota e o navegador do cliente.
  return saida;
}

/** GET /api/catalogo — vitrine */
router.get('/', limite, async (req, res) => {
  const limiteItens = Math.min(Number(req.query.limite) || 50, 100);
  const offset = Math.max(Number(req.query.offset) || 0, 0);

  const produtos = await produtosService.listarPublico({ limite: limiteItens, offset });
  res.json({
    total: produtos.length,
    produtos: produtos.map((p) => formatarProduto(p)),
  });
});

/**
 * GET /api/catalogo/variacao/:id — resumo de uma variacao
 *
 * Declarado ANTES de /:slug de proposito: o Express casa na ordem, e
 * '/variacao' seria capturado como se fosse um slug.
 *
 * Serve ao checkout, que so tem o id da variacao na URL e precisa
 * mostrar o que esta sendo comprado sem varrer o catalogo inteiro.
 */
router.get('/variacao/:id', limite, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ erro: 'Variacao invalida' });
  }

  const consulta = await produtosService.buscarVariacaoParaCompra(id);
  if (!consulta.ok) return res.status(404).json({ erro: consulta.motivo });

  const v = consulta.variacao;
  res.json({
    variacao_id: v.variacao_id,
    variacao: v.variacao_nome,
    produto: v.titulo,
    slug: v.slug,
    estoque_br: v.estoque_br,
    preco_centavos: v.preco_venda_centavos,
    preco: emReais(v.preco_venda_centavos),
  });
});

/** GET /api/catalogo/:slug — pagina do produto */
router.get('/:slug', limite, async (req, res) => {
  const produto = await produtosService.buscarPorSlug(req.params.slug);
  if (!produto) return res.status(404).json({ erro: 'Produto nao encontrado' });
  res.json(formatarProduto(produto, { comVariacoes: true }));
});

export default router;
