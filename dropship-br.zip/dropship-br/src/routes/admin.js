import express from 'express';
import crypto from 'node:crypto';
import rateLimit from 'express-rate-limit';
import config from '../config.js';
import logger from '../lib/logger.js';
import * as pedidosService from '../services/pedidos.js';
import { linkPedidoAli, LINK_PEDIDOS_PENDENTES } from '../aliexpress/orders.js';
import { nivelDevido, formatarDuracao } from '../lib/escalonamento.js';
import { rodar } from '../jobs/syncOrders.js';
import { z } from 'zod';
import * as produtosService from '../services/produtos.js';
import { importarPorLink } from '../aliexpress/produtos.js';

const router = express.Router();

/**
 * =====================================================================
 * Autenticacao do painel
 * =====================================================================
 *
 * O ADMIN_TOKEN e uma senha que vai num header a cada requisicao. Duas
 * defesas em cima disso:
 *
 * 1. Limite de tentativas ERRADAS por IP. Sem isso da para varrer o
 *    token por forca bruta; e quanto mais memoravel a senha, mais
 *    rapido a varredura acha. `skipSuccessfulRequests` faz o uso normal
 *    do painel nao gastar cota — so erro conta.
 *
 * 2. Comparacao em tempo constante. O `!==` do JavaScript para no
 *    primeiro caractere diferente, e essa diferenca de tempo vaza o
 *    prefixo correto. Passamos os dois por SHA-256 antes: alem de
 *    esconder o tempo, garante buffers do mesmo tamanho, que e o que
 *    timingSafeEqual exige.
 */
const limiteLogin = rateLimit({
  windowMs: 15 * 60_000,
  limit: 10,
  skipSuccessfulRequests: true,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { erro: 'Muitas tentativas. Aguarde 15 minutos.' },
});

const digerir = (valor) =>
  crypto.createHash('sha256').update(String(valor ?? ''), 'utf8').digest();

function tokenConfere(recebido) {
  return crypto.timingSafeEqual(digerir(recebido), digerir(config.ADMIN_TOKEN));
}

router.use(limiteLogin, (req, res, next) => {
  if (!tokenConfere(req.get('x-admin-token'))) {
    logger.warn('Tentativa de acesso ao painel recusada', { ip: req.ip });
    return res.status(401).json({ erro: 'nao autorizado' });
  }
  next();
});

/**
 * GET /api/admin/pagamentos-pendentes
 *
 * A tela que voce vai abrir todo dia. Lista o que ja foi criado na
 * AliExpress mas ainda nao foi pago, com link direto para cada pedido.
 */
router.get('/pagamentos-pendentes', async (req, res) => {
  const pendentes = await pedidosService.listarAguardandoPagamentoAli();
  const prazoMin = config.ALI_PRAZO_PAGAMENTO_HORAS * 60;

  res.json({
    total: pendentes.length,
    pagina_de_pedidos: LINK_PEDIDOS_PENDENTES,
    pedidos: pendentes.map((p) => {
      const minutos = Math.round(Number(p.minutos_parado ?? 0));
      const restam = Math.max(0, prazoMin - minutos);
      return {
        pedido_id: p.id,
        ali_order_id: p.aliexpress_order_id,
        ali_status: p.ali_order_status,
        parado_ha: formatarDuracao(minutos),
        parado_ha_min: minutos,
        // Quanto resta do prazo estimado antes do cancelamento automatico.
        restam_min: restam,
        restam: restam > 0 ? formatarDuracao(restam) : 'PRAZO ESTOURADO',
        // Quantos avisos ja saíram e quantos deveriam ter saido. Se
        // divergirem, algum canal de alerta esta falhando.
        alertas_enviados: Number(p.nivel_alerta ?? 0),
        alertas_devidos: nivelDevido(minutos, config.ALI_ALERTA_ESCALONAMENTO),
        urgente: minutos > prazoMin * 0.7,
        valor_cliente: p.valor_total_centavos
          ? (p.valor_total_centavos / 100).toFixed(2)
          : null,
        pagar: linkPedidoAli(p.aliexpress_order_id),
      };
    }),
  });
});

/**
 * POST /api/admin/alerta-teste
 * Manda uma mensagem pelos canais configurados. Sem isto, a unica
 * forma de saber se o Telegram funciona era esperar um pedido travar —
 * exatamente o momento em que voce nao quer descobrir que nao funciona.
 */
router.post('/alerta-teste', async (req, res) => {
  const { alertar } = await import('../lib/alertas.js');
  const enviado = await alertar(
    '✅ Teste de alerta',
    { origem: 'painel', quando: new Date().toLocaleString('pt-BR') },
    { botoes: [{ texto: '📋 Abrir o painel', url: `${req.protocol}://${req.get('host')}/admin.html` }] }
  );

  res.json({
    enviado,
    canais: {
      telegram: Boolean(config.TELEGRAM_BOT_TOKEN && config.TELEGRAM_CHAT_ID),
      webhook: Boolean(config.ALERT_WEBHOOK_URL),
    },
    dica: enviado
      ? 'Confira o Telegram. Se não chegou, o chat_id pode estar errado.'
      : 'Nenhum canal configurado. Preencha TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID no Railway.',
  });
});

/** POST /api/admin/sync — força um ciclo do cron sem esperar o agendamento. */
router.post('/sync', async (req, res) => {
  const resultado = await rodar();
  res.json(resultado);
});

// =====================================================================
// CATALOGO
// =====================================================================

const json = express.json({ limit: '256kb' });

const schemaVariacao = z.object({
  nome: z.string().min(1).max(120),
  aliexpress_sku_id: z.string().optional(),
  aliexpress_sku_attr: z.string().optional(),
  preco_venda_centavos: z.number().int().positive().nullable().optional(),
  // nullable: null significa "apagar", diferente de ausente.
  preco_custo_centavos: z.number().int().nonnegative().nullable().optional(),
  imagem: z.string().url().optional(),
  ativo: z.boolean().optional(),
  ordem: z.number().int().optional(),
});

const schemaProduto = z.object({
  titulo: z.string().min(3).max(200),
  descricao: z.string().max(5000).optional(),
  imagens: z.array(z.string().url()).max(10).default([]),
  aliexpress_product_id: z.string().min(6),
  aliexpress_url: z.string().url().optional(),
  estoque_br: z.boolean().default(false),
  preco_venda_centavos: z.number().int().positive(),
  preco_custo_centavos: z.number().int().nonnegative().nullable().optional(),
  ativo: z.boolean().default(false),
  variacoes: z.array(schemaVariacao).min(1, 'Cadastre ao menos uma variacao'),
});

/**
 * POST /api/admin/produtos/importar  { url }
 *
 * Cola o link da AliExpress e devolve um rascunho. Nao salva nada —
 * voce revisa, ajusta preco e so entao cria. Se a API nao responder,
 * vem um rascunho vazio com o product_id preenchido, e o cadastro
 * segue manual em vez de travar.
 */
router.post('/produtos/importar', json, async (req, res) => {
  const url = String(req.body?.url ?? '').trim();
  if (!url) return res.status(422).json({ erro: 'Informe o link ou o id do produto' });

  try {
    const resultado = await importarPorLink(url);
    res.json(resultado);
  } catch (err) {
    res.status(err.status ?? 502).json({ erro: err.message });
  }
});

/** POST /api/admin/produtos — cria produto + variacoes */
router.post('/produtos', json, async (req, res) => {
  const parsed = schemaProduto.safeParse(req.body);
  if (!parsed.success) {
    return res.status(422).json({
      erro: 'Dados invalidos',
      detalhes: parsed.error.issues.map((i) => ({
        campo: i.path.join('.'),
        mensagem: i.message,
      })),
    });
  }

  const produto = await produtosService.criarProduto(parsed.data);
  const checagem = await produtosService.validarParaAtivacao(produto.id);

  res.status(201).json({
    produto,
    // Mostra o que falta antes de por no ar, mesmo que ja tenha sido
    // criado como ativo.
    pendencias: checagem.problemas,
  });
});

/** GET /api/admin/produtos — inclui inativos e a margem */
router.get('/produtos', async (req, res) => {
  const produtos = await produtosService.listarAdmin();
  res.json({
    total: produtos.length,
    produtos: produtos.map((p) => ({
      ...p,
      margem_centavos:
        p.preco_custo_centavos != null
          ? p.preco_venda_centavos - p.preco_custo_centavos
          : null,
    })),
  });
});

/** GET /api/admin/produtos/:id */
router.get('/produtos/:id', async (req, res) => {
  const produto = await produtosService.buscarPorId(Number(req.params.id));
  if (!produto) return res.status(404).json({ erro: 'nao encontrado' });
  const checagem = await produtosService.validarParaAtivacao(produto.id);
  res.json({ produto, pendencias: checagem.problemas });
});

/** PATCH /api/admin/produtos/:id — edicao parcial */
router.patch('/produtos/:id', json, async (req, res) => {
  const produto = await produtosService.atualizarProduto(Number(req.params.id), req.body ?? {});
  if (!produto) return res.status(404).json({ erro: 'nao encontrado' });
  res.json({ produto });
});

/**
 * POST /api/admin/produtos/:id/ativar
 *
 * Passa pelo checklist antes de por no ar. Produto ativo sem SKU
 * significa cliente pagando e a compra falhando depois.
 * Use { forcar: true } para publicar assumindo as pendencias.
 */
router.post('/produtos/:id/ativar', json, async (req, res) => {
  const id = Number(req.params.id);
  const checagem = await produtosService.validarParaAtivacao(id);

  if (!checagem.produto) return res.status(404).json({ erro: 'nao encontrado' });

  if (!checagem.ok && req.body?.forcar !== true) {
    return res.status(409).json({
      erro: 'Produto nao esta pronto para venda',
      pendencias: checagem.problemas,
      dica: 'Envie { "forcar": true } para publicar mesmo assim.',
    });
  }

  const produto = await produtosService.atualizarProduto(id, { ativo: true });
  res.json({ produto, pendencias: checagem.problemas });
});

/**
 * POST /api/admin/produtos/:id/verificar-origem
 *
 * Consulta a API de frete e confirma de qual pais o produto despacha.
 * Marca `estoque_br` conforme o resultado — a tese da loja deixa de ser
 * uma caixinha marcada na confianca.
 */
router.post('/produtos/:id/verificar-origem', json, async (req, res) => {
  const id = Number(req.params.id);
  const produto = await produtosService.buscarPorId(id);
  if (!produto) return res.status(404).json({ erro: 'Produto nao encontrado' });

  const { consultarFrete } = await import('../aliexpress/frete.js');
  const variacao = produto.variacoes?.[0];

  const r = await consultarFrete(produto.aliexpress_product_id, {
    skuAttr: variacao?.aliexpress_sku_attr ?? undefined,
  });

  if (!r.ok) return res.status(502).json({ erro: r.motivo, code: r.code ?? null });

  // Só marcamos TRUE com evidência de que TODAS as opções saem do
  // Brasil. Origem parcial vira FALSE: uma opção chinesa no meio
  // significa que o cliente pode cair nela.
  await produtosService.atualizarProduto(id, { estoque_br: r.origem_br });

  res.json({
    origem_br: r.origem_br,
    origem_parcial: r.origem_parcial,
    paises: r.paises,
    prazo: Number.isFinite(r.prazo_min) ? `${r.prazo_min}-${r.prazo_max} dias` : null,
    opcoes: r.opcoes.slice(0, 6),
  });
});

/** POST /api/admin/produtos/:id/variacoes */
router.post('/produtos/:id/variacoes', json, async (req, res) => {
  const parsed = schemaVariacao.safeParse(req.body);
  if (!parsed.success) {
    return res.status(422).json({
      erro: 'Dados invalidos',
      detalhes: parsed.error.issues.map((i) => ({
        campo: i.path.join('.'),
        mensagem: i.message,
      })),
    });
  }
  const variacao = await produtosService.adicionarVariacao(Number(req.params.id), parsed.data);
  res.status(201).json({ variacao });
});

// =====================================================================
// DIAGNOSTICO
// =====================================================================

/**
 * GET /api/admin/diagnostico/mercadopago
 * Confere a configuracao sem criar cobranca.
 */
router.get('/diagnostico/mercadopago', async (req, res) => {
  const { diagnosticarMP } = await import('../services/mercadopago.js');
  res.json(await diagnosticarMP());
});

/**
 * GET /api/admin/diagnostico/aliexpress
 *
 * Sonda os metodos da Open Platform com parametros invalidos de
 * proposito: queremos o codigo do erro, nao o efeito. Nenhum pedido e
 * criado. Pode levar ate um minuto — sao varias chamadas com pausa
 * entre elas para nao estourar o limite de QPS.
 */
router.get('/diagnostico/aliexpress', async (req, res) => {
  const { rodarDiagnostico } = await import('../aliexpress/diagnostico.js');
  try {
    res.json(await rodarDiagnostico());
  } catch (err) {
    res.status(502).json({ erro: err.message });
  }
});

// =====================================================================
// AUTORIZACAO DA ALIEXPRESS
// =====================================================================

/** GET /api/admin/aliexpress/auth — estado do token + link de autorizacao */
router.get('/aliexpress/auth', async (req, res) => {
  const { urlAutorizacao, lerCredenciais, horasParaExpirar } = await import(
    '../aliexpress/auth.js'
  );
  const cred = await lerCredenciais().catch(() => null);
  const horas = await horasParaExpirar().catch(() => null);

  // A Callback URL precisa ser IDENTICA a cadastrada no console do app,
  // senao a plataforma recusa o redirecionamento.
  const callback = `${req.protocol}://${req.get('host')}/`;

  res.json({
    tem_token: Boolean(cred?.access_token),
    conta: cred?.conta ?? null,
    expira_em: cred?.expira_em ?? null,
    horas_restantes: horas != null ? Math.round(horas) : null,
    atualizado_em: cred?.atualizado_em ?? null,
    callback,
    url: urlAutorizacao(callback),
  });
});

/** POST /api/admin/aliexpress/auth  { code } — troca o code por token */
router.post('/aliexpress/auth', json, async (req, res) => {
  const code = String(req.body?.code ?? '').trim();
  if (!code) return res.status(422).json({ erro: 'Informe o code' });

  const { trocarCodePorToken, limparCache } = await import('../aliexpress/auth.js');
  try {
    const d = await trocarCodePorToken(code);
    limparCache();
    res.json({ ok: true, conta: d.conta, expira_em: d.expira_em });
  } catch (err) {
    res.status(502).json({ erro: err.message });
  }
});

/** POST /api/admin/aliexpress/renovar */
router.post('/aliexpress/renovar', async (req, res) => {
  const { renovarToken, limparCache } = await import('../aliexpress/auth.js');
  try {
    const d = await renovarToken();
    limparCache();
    res.json({ ok: true, expira_em: d.expira_em });
  } catch (err) {
    res.status(502).json({ erro: err.message });
  }
});

// =====================================================================
// PEDIDOS COM PROBLEMA
// =====================================================================

/** GET /api/admin/problemas — pedidos pagos sem produto a caminho */
router.get('/problemas', async (req, res) => {
  const { listarProblemas, resumoProblemas } = await import('../services/problemas.js');
  const [pedidos, resumo] = await Promise.all([listarProblemas(), resumoProblemas()]);
  res.json({ resumo, total: pedidos.length, pedidos });
});

/**
 * PATCH /api/admin/problemas/:id — corrige dados do cliente
 * Serve para o caso mais comum: CPF que nao bate com o nome.
 */
router.patch('/problemas/:id', json, async (req, res) => {
  const { corrigirDados } = await import('../services/problemas.js');
  const r = await corrigirDados(Number(req.params.id), req.body ?? {});
  if (!r.ok) return res.status(409).json({ erro: r.motivo });
  res.json({ pedido: r.pedido });
});

/** POST /api/admin/problemas/:id/reprocessar */
router.post('/problemas/:id/reprocessar', json, async (req, res) => {
  const id = Number(req.params.id);
  const pedido = await pedidosService.buscarPorId(id);
  if (!pedido) return res.status(404).json({ erro: 'Pedido nao encontrado' });
  if (pedido.estornado_em) {
    return res.status(409).json({ erro: 'Pedido ja estornado; nao ha o que reprocessar' });
  }

  // O lock so libera a partir de 'pago_no_site'.
  if (pedido.status_pedido === 'erro_ali' || pedido.status_pedido === 'cancelado_ali') {
    await pedidosService.marcarComoPago(id);
  }

  const resultado = await pedidosService.repassarParaAliExpress(id);
  res.json(resultado);
});

/**
 * POST /api/admin/problemas/:id/estornar  { motivo }
 * Devolve o dinheiro ao cliente pelo Mercado Pago.
 */
router.post('/problemas/:id/estornar', json, async (req, res) => {
  const { estornar } = await import('../services/problemas.js');
  const r = await estornar(
    Number(req.params.id),
    String(req.body?.motivo ?? 'Pedido nao pode ser processado').slice(0, 200)
  );
  if (!r.ok) return res.status(409).json({ erro: r.motivo });
  res.json({
    ok: true,
    valor_estornado: r.pedido.valor_estornado_centavos,
    atencao: r.temPedidoAli
      ? `Existe pedido ${r.pedido.aliexpress_order_id} na AliExpress. Cancele la tambem.`
      : null,
  });
});

// =====================================================================
// PEDIDOS
// =====================================================================

/** GET /api/admin/pedidos/:id */
router.get('/pedidos/:id', async (req, res) => {
  const pedido = await pedidosService.buscarPorId(Number(req.params.id));
  if (!pedido) return res.status(404).json({ erro: 'nao encontrado' });
  res.json({
    ...pedido,
    link_ali: pedido.aliexpress_order_id
      ? linkPedidoAli(pedido.aliexpress_order_id)
      : null,
  });
});

export default router;
