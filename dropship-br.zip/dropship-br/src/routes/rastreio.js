import express from 'express';
import rateLimit from 'express-rate-limit';
import * as pedidosService from '../services/pedidos.js';
import { rastrear } from '../services/linketrack.js';

const router = express.Router();

// Rota publica: limite por IP.
const limite = rateLimit({
  windowMs: 60_000,
  limit: 60,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { erro: 'Muitas consultas. Tente de novo em instantes.' },
});

/**
 * Tradução de estados internos para linguagem de cliente.
 *
 * Repare que varios estados internos caem no mesmo texto. E de
 * proposito: o cliente nao precisa (nem deve) saber que o pedido esta
 * preso em 'erro_ali' ou que voce ainda nao pagou o fornecedor. Ele
 * precisa saber se o pedido esta andando.
 */
const MAPA_STATUS = {
  aguardando_pagamento: { texto: 'Aguardando pagamento', etapa: 1 },
  pago_no_site: { texto: 'Pagamento confirmado', etapa: 2 },
  processando_ali: { texto: 'Preparando seu pedido', etapa: 2 },
  aguardando_pagamento_ali: { texto: 'Preparando seu pedido', etapa: 2 },
  processado_ali: { texto: 'Pedido confirmado com o fornecedor', etapa: 3 },
  erro_ali: { texto: 'Preparando seu pedido', etapa: 2 },
  cancelado_ali: { texto: 'Preparando seu pedido', etapa: 2 },
  enviado: { texto: 'A caminho', etapa: 4 },
  entregue: { texto: 'Entregue', etapa: 5 },
  cancelado: { texto: 'Cancelado', etapa: 0 },
};

const RE_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * GET /api/rastreio/:token
 * Acompanhamento do pedido pelo token publico.
 */
router.get('/:token', limite, async (req, res) => {
  const token = String(req.params.token);
  if (!RE_UUID.test(token)) {
    return res.status(400).json({ erro: 'Codigo de pedido invalido' });
  }

  const pedido = await pedidosService.buscarPorToken(token);
  if (!pedido) return res.status(404).json({ erro: 'Pedido nao encontrado' });

  const mapeado = MAPA_STATUS[pedido.status_pedido] ?? {
    texto: 'Preparando seu pedido',
    etapa: 2,
  };

  const base = {
    token: pedido.token_publico,
    status: mapeado.texto,
    etapa: mapeado.etapa,
    etapas_total: 5,
    valor_centavos: pedido.valor_total_centavos,
    quantidade: pedido.quantidade,
    codigo_rastreio: pedido.codigo_rastreio,
    transportadora: pedido.transportadora,
    data_criacao: pedido.data_criacao,
    data_envio: pedido.data_envio,
    cliente: mascararNome(pedido.cliente_nome),
    entrega: `${pedido.endereco_cidade} - ${pedido.endereco_estado}`,
  };

  // Enquanto nao pagou, devolve o Pix junto: o cliente pode ter fechado
  // a aba e voltado pelo link. Sem isso ele ficaria sem como pagar.
  if (pedido.status_pedido === 'aguardando_pagamento' && pedido.pix_qr_code) {
    base.pix = {
      qr_code: pedido.pix_qr_code,
      expira_em: pedido.pix_expira_em,
    };
  }

  if (!pedido.codigo_rastreio) {
    return res.json({
      ...base,
      rastreio: { disponivel: false, motivo: 'Ainda sem codigo de rastreio' },
    });
  }

  const rastreio = await rastrear(pedido.codigo_rastreio, {
    ignorarCache: req.query.refresh === '1',
  });

  res.json({ ...base, rastreio });
});

function mascararNome(nome = '') {
  return nome
    .split(' ')
    .map((p, i) => (i === 0 ? p : p[0] ? `${p[0]}.` : ''))
    .join(' ');
}

export default router;
