import express from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import config from '../config.js';
import logger from '../lib/logger.js';
import * as pedidosService from '../services/pedidos.js';
import * as produtosService from '../services/produtos.js';
import { criarCobrancaPix } from '../services/mercadopago.js';
import {
  validarCPF,
  somenteDigitos,
  normalizarCEP,
  normalizarTelefone,
  ufValida,
} from '../lib/brasil.js';

const router = express.Router();

const limite = rateLimit({ windowMs: 60_000, limit: 20 });

/**
 * =====================================================================
 * MUDANCA IMPORTANTE: o preco nao vem mais do cliente
 * =====================================================================
 *
 * A versao anterior aceitava `valor_total_centavos` e
 * `aliexpress_product_id` no corpo da requisicao. Isso significava que
 * qualquer pessoa com o endpoint podia pedir um produto de R$ 200 por
 * R$ 0,01: o Pix sairia por um centavo e o sistema compraria o produto
 * de verdade na AliExpress com o seu dinheiro.
 *
 * Agora o cliente manda apenas `variacao_id` e `quantidade`. Preco,
 * product_id e sku_attr saem do banco. Nada que venha do navegador
 * influencia quanto e cobrado.
 */
const schemaPedido = z.object({
  referencia_externa: z.string().min(4).max(120).optional(),

  // ----- O que esta sendo comprado -----
  variacao_id: z.number().int().positive(),
  quantidade: z.number().int().positive().max(10).default(1),

  // ----- Quem esta comprando -----
  cliente_nome: z.string().min(3).max(120),
  cliente_cpf: z.string().transform(somenteDigitos).refine(validarCPF, 'CPF invalido'),
  cliente_telefone: z
    .string()
    .transform(normalizarTelefone)
    .refine((v) => v !== null, 'Telefone invalido (use DDD + numero)'),
  cliente_email: z.string().email().optional(),

  // ----- Para onde vai -----
  endereco_rua: z.string().min(3).max(120),
  endereco_numero: z.string().min(1).max(20),
  endereco_complemento: z.string().max(60).optional(),
  endereco_bairro: z.string().min(2).max(80),
  endereco_cidade: z.string().min(2).max(80),
  endereco_estado: z
    .string()
    .length(2)
    .transform((v) => v.toUpperCase())
    .refine(ufValida, 'UF invalida'),
  endereco_cep: z
    .string()
    .transform(normalizarCEP)
    .refine((v) => v !== null, 'CEP invalido'),
});

/**
 * POST /api/pedidos
 * Cria o pedido e ja devolve o Pix pronto.
 */
router.post('/', limite, express.json({ limit: '64kb' }), async (req, res) => {
  const parsed = schemaPedido.safeParse(req.body);
  if (!parsed.success) {
    return res.status(422).json({
      erro: 'Dados invalidos',
      detalhes: parsed.error.issues.map((i) => ({
        campo: i.path.join('.'),
        mensagem: i.message,
      })),
    });
  }

  const dados = parsed.data;

  // ----- Preco e SKU vem do banco, nunca do cliente -----
  const consulta = await produtosService.buscarVariacaoParaCompra(dados.variacao_id);
  if (!consulta.ok) {
    return res.status(409).json({ erro: consulta.motivo });
  }
  const v = consulta.variacao;

  const valorTotal = v.preco_venda_centavos * dados.quantidade;

  // Margem negativa e prejuizo silencioso: cada venda custa dinheiro.
  // Barrar aqui e melhor do que descobrir na conciliacao do mes.
  if (v.preco_custo_centavos != null && v.preco_venda_centavos <= v.preco_custo_centavos) {
    logger.error('Venda bloqueada por margem invertida', {
      variacaoId: v.variacao_id,
      venda: v.preco_venda_centavos,
      custo: v.preco_custo_centavos,
    });
    return res.status(409).json({ erro: 'Produto temporariamente indisponivel' });
  }

  const referencia =
    dados.referencia_externa ?? `PED-${Date.now()}-${v.variacao_id}`;

  const pedido = await pedidosService.criarPedido({
    ...dados,
    referencia_externa: referencia,
    produto_id: v.produto_id,
    variacao_id: v.variacao_id,
    aliexpress_product_id: v.aliexpress_product_id,
    aliexpress_sku_id: v.aliexpress_sku_id,
    aliexpress_sku_attr: v.aliexpress_sku_attr,
    valor_total_centavos: valorTotal,
  });

  if (pedido.status_pedido !== 'aguardando_pagamento') {
    return res.status(200).json({
      pedido_id: pedido.id,
      token: pedido.token_publico,
      status: pedido.status_pedido,
      aviso: 'Pedido ja existe e nao esta aguardando pagamento.',
    });
  }

  // Pix ja gerado e ainda valido: devolve o mesmo em vez de duplicar.
  if (pedido.pix_qr_code && pedido.pix_expira_em > new Date()) {
    return res.status(200).json({
      pedido_id: pedido.id,
      token: pedido.token_publico,
      status: pedido.status_pedido,
      valor_centavos: pedido.valor_total_centavos,
      pix: { qr_code: pedido.pix_qr_code, expira_em: pedido.pix_expira_em },
    });
  }

  if (!config.MP_ACCESS_TOKEN) {
    return res.status(201).json({
      pedido_id: pedido.id,
      token: pedido.token_publico,
      status: pedido.status_pedido,
      valor_centavos: valorTotal,
      aviso: 'MP_ACCESS_TOKEN nao configurado; pedido criado sem cobranca.',
    });
  }

  try {
    const cobranca = await criarCobrancaPix(pedido, valorTotal);
    const atualizado = await pedidosService.salvarCobrancaPix(pedido.id, cobranca);

    res.status(201).json({
      pedido_id: pedido.id,
      token: pedido.token_publico,
      referencia_externa: pedido.referencia_externa,
      status: atualizado.status_pedido,
      produto: v.titulo,
      variacao: v.variacao_nome,
      quantidade: dados.quantidade,
      valor_centavos: valorTotal,
      pix: {
        qr_code: cobranca.qrCode,
        qr_code_base64: cobranca.qrCodeBase64,
        ticket_url: cobranca.ticketUrl,
        expira_em: cobranca.expiraEm,
      },
    });
  } catch (err) {
    // O Mercado Pago devolve o codigo real do problema dentro de `cause`.
    // Registrar so err.message esconde exatamente a informacao que
    // resolve — foi o que aconteceu na primeira vez que isto falhou.
    logger.error('Falha ao gerar Pix', {
      pedidoId: pedido.id,
      erro: err.message,
      status: err.status ?? null,
      detalhes: err.detalhes ?? null,
    });
    res.status(502).json({
      pedido_id: pedido.id,
      erro: 'Nao foi possivel gerar a cobranca. Tente novamente.',
    });
  }
});

export default router;
