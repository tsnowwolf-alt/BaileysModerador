import config from '../config.js';
import logger from '../lib/logger.js';
import { callAliExpress, extrairResposta, AliExpressError, mensagemLegivel } from './client.js';
import { UF_PARA_PROVINCIA, formatarCEP, semAcento } from '../lib/brasil.js';

// A classificacao de status vive em modulo proprio, sem config nem I/O,
// para poder ser testada isoladamente. Reexportamos por conveniencia.
export {
  STATUS_ALI,
  classificarStatusAli,
  foiPago,
  linkPedidoAli,
  LINK_PEDIDOS_PENDENTES,
} from './status.js';

/**
 * =====================================================================
 * Mapeamento do endereco brasileiro -> logistics_address da AliExpress
 * =====================================================================
 *
 * O modelo de endereco deles e anglo-saxao e nao tem "bairro" nem
 * "numero" separados. A convencao que funciona na pratica:
 *
 *   address   -> "Rua Exemplo, 123"
 *   address2  -> "Bairro - Complemento"
 *   province  -> nome da UF por extenso ("Sao Paulo", nao "SP")
 *   zip       -> "00000-000"
 *   cpf       -> 11 digitos, sem pontuacao
 *
 * O CPF e obrigatorio para o Brasil (alfandega/NF-e). Se o seu app
 * retornar erro no campo `cpf`, o fallback historico — usado inclusive
 * pelo DSers — e concatenar o CPF no fim do address2. Controle isso
 * pelo parametro `cpfNoAddress2`.
 */
export function montarEnderecoAli(pedido, { cpfNoAddress2 = false } = {}) {
  const provincia = UF_PARA_PROVINCIA[pedido.endereco_estado?.toUpperCase()];
  if (!provincia) {
    throw new Error(`UF invalida no pedido ${pedido.id}: ${pedido.endereco_estado}`);
  }

  const partes2 = [pedido.endereco_bairro, pedido.endereco_complemento].filter(Boolean);
  if (cpfNoAddress2) partes2.push(`CPF: ${pedido.cliente_cpf}`);

  return {
    contact_person: semAcento(pedido.cliente_nome).slice(0, 50),
    full_name: semAcento(pedido.cliente_nome).slice(0, 50),
    address: semAcento(`${pedido.endereco_rua}, ${pedido.endereco_numero}`).slice(0, 120),
    address2: semAcento(partes2.join(' - ')).slice(0, 120),
    city: semAcento(pedido.endereco_cidade).slice(0, 50),
    province: provincia,
    country: 'BR',
    zip: formatarCEP(pedido.endereco_cep),
    mobile_no: pedido.cliente_telefone,
    phone_country: '+55',
    cpf: pedido.cliente_cpf,
    locale: 'pt_BR',
  };
}

/**
 * Monta o buy_param_list / product_items a partir do pedido.
 *
 * ATENCAO a um detalhe que custa horas de debug: a API espera `sku_attr`
 * (a string de atributos, ex. "14:350853#Preto;5:361386"), nao apenas o
 * sku_id numerico. Guarde os dois no banco ao importar o produto —
 * pegue via aliexpress.ds.product.get / .productdetail.get.
 */
export function montarItens(pedido) {
  const item = {
    product_id: Number(pedido.aliexpress_product_id),
    product_count: pedido.quantidade ?? 1,
    order_memo: `Pedido interno #${pedido.id}`,
  };

  if (pedido.aliexpress_sku_attr) item.sku_attr = pedido.aliexpress_sku_attr;
  else if (pedido.aliexpress_sku_id) item.sku_attr = String(pedido.aliexpress_sku_id);

  if (pedido.logistics_service) item.logistics_service_name = pedido.logistics_service;

  return [item];
}

/**
 * Cria o pedido na AliExpress.
 *
 * IMPORTANTE: este endpoint CRIA o pedido em estado "aguardando pagamento".
 * Ele nao paga sozinho. O pagamento sai do meio de pagamento vinculado a
 * sua conta AliExpress conforme as regras do seu programa (DS/Trade).
 * Confirme com o seu gerente de conta se o auto-debito esta ativo — senao
 * o pedido expira em algumas horas sem que ninguem perceba.
 *
 * @param {object} pedido linha da tabela `pedidos`
 * @returns {Promise<{ orderId: string|null, raw: any }>}
 */
export async function criarPedidoAli(pedido, opts = {}) {
  const dto = {
    logistics_address: montarEnderecoAli(pedido, opts),
    product_items: montarItens(pedido),
  };

  // O nome do parametro de negocio varia conforme o metodo liberado:
  //   aliexpress.trade.buy.placeorder -> param_place_order_request4_open_api_d_t_o
  //   aliexpress.ds.order.create      -> param_place_order_request4_open_api_d_t_o
  // Confirme no console do SEU app antes de tirar o dry-run.
  const businessParams = {
    param_place_order_request4_open_api_d_t_o: dto,
  };

  logger.info('Enviando pedido a AliExpress', {
    pedidoId: pedido.id,
    productId: pedido.aliexpress_product_id,
    method: config.ALI_METHOD_PLACE_ORDER,
  });

  const json = await callAliExpress(config.ALI_METHOD_PLACE_ORDER, businessParams);

  if (json.__dry_run) {
    return { orderId: null, raw: { ...json, dto }, dryRun: true };
  }

  const resposta = extrairResposta(json, config.ALI_METHOD_PLACE_ORDER);
  const result = resposta?.result ?? resposta;

  const sucesso = result?.is_success === true || result?.is_success === 'true';
  if (!sucesso) {
    // A recusa pode vir em varios formatos, inclusive objeto aninhado.
    // Sem tratamento, virava "[object Object]" no alerta.
    const motivo =
      mensagemLegivel(result?.error_msg) ??
      mensagemLegivel(result?.error_code) ??
      mensagemLegivel(result) ??
      'placeorder retornou is_success=false';

    throw new AliExpressError(motivo, {
      code: result?.error_code ?? result?.code,
      raw: json,
    });
  }

  const orderId =
    result?.order_list?.number?.[0] ??
    result?.order_list?.[0] ??
    result?.order_id ??
    null;

  if (!orderId) {
    throw new AliExpressError('placeorder deu sucesso mas nao retornou order_id', {
      raw: json,
    });
  }

  return { orderId: String(orderId), raw: json };
}

/**
 * Consulta o pedido na AliExpress e extrai status + rastreio.
 * @param {string} aliOrderId
 */
export async function consultarPedidoAli(aliOrderId) {
  const json = await callAliExpress(
    config.ALI_METHOD_ORDER_GET,
    { order_id: String(aliOrderId), single_order_query: { order_id: String(aliOrderId) } },
    { dryRun: false } // consulta e read-only: sempre pode rodar de verdade
  );

  const resposta = extrairResposta(json, config.ALI_METHOD_ORDER_GET);
  const result = resposta?.result ?? resposta;

  return {
    status: result?.order_status ?? result?.status ?? null,
    logisticsStatus: result?.logistics_status ?? null,
    trackingNumber: extrairRastreio(result),
    transportadora: extrairTransportadora(result),
    raw: json,
  };
}

/**
 * O campo de rastreio muda de nome conforme a versao/estrutura da resposta.
 * Varremos os caminhos conhecidos em vez de assumir um so.
 */
function extrairRastreio(result) {
  if (!result) return null;
  const candidatos = [
    result.logistics_no,
    result.tracking_number,
    result.logistics_info_list?.logistics_info?.[0]?.logistics_no,
    result.child_order_list?.aeop_child_order_info?.[0]?.logistics_no,
    result.order_logistics?.[0]?.logistics_no,
  ];
  const achado = candidatos.find((v) => typeof v === 'string' && v.trim().length >= 8);
  return achado ? achado.trim().toUpperCase() : null;
}

function extrairTransportadora(result) {
  if (!result) return null;
  return (
    result.logistics_service_name ??
    result.logistics_info_list?.logistics_info?.[0]?.logistics_service ??
    null
  );
}

export default { criarPedidoAli, consultarPedidoAli, montarEnderecoAli, montarItens };
