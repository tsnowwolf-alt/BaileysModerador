import config from '../config.js';
import logger from '../lib/logger.js';
import { generateRestSign } from './sign.js';
import { query } from '../db.js';

/**
 * =====================================================================
 * Autorização da AliExpress (OAuth2, modo "code por token")
 * =====================================================================
 *
 * Três passos:
 *   1. Você abre a URL de autorização e entra com a conta AliExpress
 *   2. A plataforma devolve um `code` na Callback URL do app
 *   3. Trocamos o code por access_token — e o code EXPIRA EM 30 MINUTOS
 *
 * O token dura 30 dias e o refresh_token 60. Por isso guardamos os dois
 * no banco: o cron renova antes de expirar, em vez de o sistema parar
 * de repassar pedidos todo mês sem aviso.
 */

const BASE_REST = 'https://api-sg.aliexpress.com/rest';
const BASE_OAUTH = 'https://api-sg.aliexpress.com/oauth/authorize';

/** Passo 1: para onde o navegador deve ir. */
export function urlAutorizacao(callbackUrl) {
  const u = new URL(BASE_OAUTH);
  u.searchParams.set('response_type', 'code');
  // force_auth garante a tela de login mesmo com sessão ativa — evita
  // autorizar com a conta errada sem perceber.
  u.searchParams.set('force_auth', 'true');
  u.searchParams.set('redirect_uri', callbackUrl);
  u.searchParams.set('client_id', config.ALI_APP_KEY);
  return u.toString();
}

async function chamarRest(apiPath, params) {
  const payload = {
    app_key: config.ALI_APP_KEY,
    timestamp: String(Date.now()),
    sign_method: config.ALI_SIGN_METHOD,
    ...params,
  };
  payload.sign = generateRestSign(apiPath, payload, config.ALI_APP_SECRET, config.ALI_SIGN_METHOD);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20_000);

  try {
    const res = await fetch(`${BASE_REST}${apiPath}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' },
      body: new URLSearchParams(payload).toString(),
      signal: controller.signal,
    });

    const texto = await res.text();
    let json;
    try {
      json = JSON.parse(texto);
    } catch {
      throw new Error(`Resposta não-JSON de ${apiPath}: ${texto.slice(0, 200)}`);
    }

    /**
     * Erros vêm no corpo, com HTTP 200 — não dá para confiar no status.
     *
     * MAS: nas APIs REST da Alibaba, `code: "0"` significa SUCESSO.
     * A versão anterior testava `if (json.code)`, e a string "0" é
     * verdadeira em JavaScript — então toda resposta bem-sucedida era
     * tratada como falha e o token era descartado. O sintoma era um
     * "erro [0]" que não dizia nada.
     */
    const codigo = json.error_response?.code ?? json.code;
    const temErro =
      json.error_response != null ||
      json.error != null ||
      (codigo != null && String(codigo) !== '0');

    if (temErro) {
      const e = json.error_response ?? json;
      const msg = e.error_msg ?? e.message ?? e.error_description ?? e.error;
      throw new Error(
        // Sem mensagem nomeada, mandamos o corpo cru. Erro sem texto é
        // pior que erro feio: não dá para agir.
        `${msg ?? JSON.stringify(json).slice(0, 300)} [${codigo ?? '-'}]`
      );
    }

    return json;
  } finally {
    clearTimeout(timer);
  }
}

const emSegundos = (v) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return null;
  // A plataforma às vezes devolve em segundos, às vezes em ms.
  return new Date(Date.now() + (n > 10_000_000 ? n : n * 1000));
};

/** Passo 3: troca o code pelo token e guarda no banco. */
export async function trocarCodePorToken(code) {
  const bruto = await chamarRest('/auth/token/create', { code });

  // Dependendo da versão, o corpo vem direto ou dentro de um envelope.
  const r = bruto.access_token ? bruto : (bruto.data ?? bruto.result ?? bruto);

  const dados = {
    access_token: r.access_token,
    refresh_token: r.refresh_token ?? null,
    expira_em: emSegundos(r.expires_in),
    refresh_expira_em: emSegundos(r.refresh_token_valid_time ?? r.refresh_expires_in),
    conta: r.user_nick ?? r.account ?? r.seller_id ?? null,
  };

  if (!dados.access_token) {
    throw new Error(
      `A plataforma respondeu sem access_token: ${JSON.stringify(bruto).slice(0, 300)}`
    );
  }

  await salvarCredenciais(dados);
  logger.info('Token da AliExpress obtido', {
    conta: dados.conta,
    expira_em: dados.expira_em,
  });

  return dados;
}

/** Renova antes de expirar, usando o refresh_token. */
export async function renovarToken() {
  const atual = await lerCredenciais();
  if (!atual?.refresh_token) {
    throw new Error('Sem refresh_token guardado; é preciso autorizar de novo');
  }

  const bruto = await chamarRest('/auth/token/refresh', { refresh_token: atual.refresh_token });
  const r = bruto.access_token ? bruto : (bruto.data ?? bruto.result ?? bruto);

  const dados = {
    access_token: r.access_token,
    // Algumas respostas não trazem refresh novo: mantém o anterior.
    refresh_token: r.refresh_token ?? atual.refresh_token,
    expira_em: emSegundos(r.expires_in),
    refresh_expira_em:
      emSegundos(r.refresh_token_valid_time ?? r.refresh_expires_in) ?? atual.refresh_expira_em,
    conta: atual.conta,
  };

  await salvarCredenciais(dados);
  logger.info('Token da AliExpress renovado', { expira_em: dados.expira_em });
  return dados;
}

export async function salvarCredenciais(d) {
  await query(
    `INSERT INTO ali_credenciais
       (id, access_token, refresh_token, expira_em, refresh_expira_em, conta, atualizado_em)
     VALUES (1, $1, $2, $3, $4, $5, NOW())
     ON CONFLICT (id) DO UPDATE SET
       access_token      = EXCLUDED.access_token,
       refresh_token     = EXCLUDED.refresh_token,
       expira_em         = EXCLUDED.expira_em,
       refresh_expira_em = EXCLUDED.refresh_expira_em,
       conta             = EXCLUDED.conta,
       atualizado_em     = NOW()`,
    [d.access_token, d.refresh_token, d.expira_em, d.refresh_expira_em, d.conta]
  );
}

export async function lerCredenciais() {
  const { rows } = await query(`SELECT * FROM ali_credenciais WHERE id = 1`);
  return rows[0] ?? null;
}

/**
 * Token efetivo: banco primeiro, variável de ambiente como reserva.
 *
 * Guardamos em memória por um minuto para não consultar o banco a cada
 * chamada da API — o cron faz dezenas por ciclo.
 */
let cache = { valor: null, em: 0 };

export async function tokenAtual() {
  if (cache.valor && Date.now() - cache.em < 60_000) return cache.valor;

  try {
    const cred = await lerCredenciais();
    if (cred?.access_token) {
      cache = { valor: cred.access_token, em: Date.now() };
      return cred.access_token;
    }
  } catch (err) {
    logger.warn('Não consegui ler credenciais do banco; usando a variável de ambiente', {
      erro: err.message,
    });
  }

  return config.ALI_ACCESS_TOKEN;
}

export const limparCache = () => {
  cache = { valor: null, em: 0 };
};

/** Quanto falta para expirar, em horas. Null = sem token guardado. */
export async function horasParaExpirar() {
  const cred = await lerCredenciais();
  if (!cred?.expira_em) return null;
  return (new Date(cred.expira_em).getTime() - Date.now()) / 3_600_000;
}

export default {
  urlAutorizacao,
  trocarCodePorToken,
  renovarToken,
  tokenAtual,
  lerCredenciais,
  horasParaExpirar,
  limparCache,
};
