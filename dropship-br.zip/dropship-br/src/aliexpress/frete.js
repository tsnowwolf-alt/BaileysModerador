import config from '../config.js';
import logger from '../lib/logger.js';
import { callAliExpress, extrairResposta } from './client.js';

/**
 * =====================================================================
 * Origem do envio
 * =====================================================================
 *
 * A tese da loja é "já está no Brasil". Até agora isso era uma caixinha
 * marcada por confiança no painel — e um produto anunciado como
 * nacional que despacha da China vira 30 dias de espera, cliente
 * irritado e chargeback. Chargeback custa mais que a venda.
 *
 * A API de frete responde de onde o item sai. Consultamos para um CEP
 * brasileiro e olhamos o país de origem das opções devolvidas.
 *
 * O nome do método varia conforme o programa liberado, então ele é
 * configurável e o diagnóstico descobre qual a sua conta aceita.
 */

/** CEP usado na consulta. Qualquer endereço válido serve; o que
 *  importa é de ONDE sai, não para onde vai. */
const CEP_REFERENCIA = '01310100';

export async function consultarFrete(productId, { skuAttr, cep = CEP_REFERENCIA } = {}) {
  if (!config.ALI_METHOD_FREIGHT) {
    return { ok: false, motivo: 'ALI_METHOD_FREIGHT não configurado' };
  }

  const dto = {
    product_id: String(productId),
    country_code: 'BR',
    // Alguns métodos exigem o CEP; outros ignoram.
    send_goods_country_code: 'BR',
    product_num: 1,
    price_currency: 'BRL',
    locale: 'pt_BR',
    ...(skuAttr ? { sku_id: skuAttr } : {}),
    ...(cep ? { zip: cep } : {}),
  };

  try {
    const json = await callAliExpress(
      config.ALI_METHOD_FREIGHT,
      {
        // O nome do parâmetro de negócio muda entre versões; mandamos
        // os dois formatos conhecidos e a plataforma usa o que entende.
        queryDeliveryReq: JSON.stringify(dto),
        param_aeop_freight_calculate_for_buyer_d_t_o: JSON.stringify(dto),
      },
      { tentativas: 1, dryRun: false, timeoutMs: 12_000 }
    );

    const resposta = extrairResposta(json, config.ALI_METHOD_FREIGHT);
    const opcoes = extrairOpcoes(resposta);

    if (!opcoes.length) {
      return { ok: false, motivo: 'A API não retornou opções de frete', raw: json };
    }

    const paises = [...new Set(opcoes.map((o) => o.origem).filter(Boolean))];
    // Só afirmamos origem BR com evidência. Sem informação de país,
    // devolvemos "desconhecido" em vez de assumir o melhor caso.
    const soBrasil = paises.length > 0 && paises.every((p) => p === 'BR');
    const temBrasil = paises.includes('BR');

    return {
      ok: true,
      origem_br: soBrasil,
      origem_parcial: !soBrasil && temBrasil,
      paises,
      opcoes,
      prazo_min: Math.min(...opcoes.map((o) => o.prazo_min ?? 99).filter(Number.isFinite)),
      prazo_max: Math.max(...opcoes.map((o) => o.prazo_max ?? 0).filter(Number.isFinite)),
    };
  } catch (err) {
    logger.warn('Consulta de frete falhou', { productId, erro: err.message });
    return { ok: false, motivo: err.message, code: err.code ?? err.subCode ?? null };
  }
}

/**
 * As opções vêm em estruturas diferentes conforme o método. Varremos
 * os caminhos conhecidos em vez de assumir um só.
 */
function extrairOpcoes(r) {
  if (!r) return [];

  const candidatos =
    r.result?.aeop_freight_calculate_result_for_buyer_d_t_o_list?.aeop_freight_calculate_result_for_buyer_dto ??
    r.result?.delivery_options?.delivery_option_d_t_o ??
    r.result?.delivery_option_list ??
    r.aeop_freight_calculate_result_for_buyer_d_t_o_list ??
    r.delivery_options ??
    r.result ??
    [];

  const lista = Array.isArray(candidatos) ? candidatos : [candidatos];

  return lista
    .filter((o) => o && typeof o === 'object')
    .map((o) => ({
      servico: o.service_name ?? o.delivery_provider_name ?? o.company ?? null,
      origem:
        o.send_goods_country_code ??
        o.ship_from_country ??
        o.shipping_from ??
        o.send_goods_country ??
        null,
      prazo_min: Number(o.min_delivery_days ?? o.delivery_date_min ?? o.estimated_delivery_time) || null,
      prazo_max: Number(o.max_delivery_days ?? o.delivery_date_max) || null,
      preco: o.freight?.amount ?? o.shipping_fee_cent ?? o.freight_amount?.value ?? null,
    }))
    .filter((o) => o.servico || o.origem);
}

export default { consultarFrete };
