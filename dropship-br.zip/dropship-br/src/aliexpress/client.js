import config from '../config.js';
import logger from '../lib/logger.js';
import { buildSignedPayload } from './sign.js';
import { tokenAtual } from './auth.js';

/**
 * Cliente do gateway da AliExpress Open Platform.
 *
 * O gateway responde HTTP 200 mesmo em erro de negocio — o erro vem no
 * corpo, em `error_response` ou em `*_response.result.is_success=false`.
 * Por isso nao da para confiar no status code.
 */

/**
 * Extrai texto legível de um erro da Alibaba.
 *
 * A resposta às vezes traz `error_msg` como string, às vezes como
 * objeto com detalhes por campo. Passar o objeto direto para
 * `new Error()` produzia a mensagem "[object Object]" — que esconde
 * exatamente o motivo da recusa, no momento em que o cliente já pagou.
 */
export function mensagemLegivel(valor, profundidade = 0) {
  if (valor == null) return null;
  if (typeof valor === 'string') return valor.trim() || null;
  if (typeof valor === 'number' || typeof valor === 'boolean') return String(valor);

  if (Array.isArray(valor)) {
    const partes = valor.map((v) => mensagemLegivel(v, profundidade + 1)).filter(Boolean);
    return partes.length ? partes.join(' | ') : null;
  }

  if (typeof valor === 'object') {
    // Campos que costumam carregar o texto do erro, em ordem de preferência.
    for (const chave of ['error_msg', 'msg', 'message', 'sub_msg', 'error_message', 'desc']) {
      const achado = mensagemLegivel(valor[chave], profundidade + 1);
      if (achado) return achado;
    }
    if (profundidade < 3) {
      // Nada nomeado: devolve o JSON, que é feio mas acionável.
      try {
        return JSON.stringify(valor).slice(0, 400);
      } catch {
        return null;
      }
    }
  }
  return null;
}

export class AliExpressError extends Error {
  constructor(message, { code, subCode, requestId, raw, retryable = false } = {}) {
    super(message);
    this.name = 'AliExpressError';
    this.code = code;
    this.subCode = subCode;
    this.requestId = requestId;
    this.raw = raw;
    this.retryable = retryable;
  }
}

// Erros transitorios: vale tentar de novo.
const CODIGOS_RETENTAVEIS = new Set([
  'ServiceUnavailable',
  'RemoteServiceError',
  'isv.system-busy',
  'isp.top-remote-connection-timeout',
  'isp.top-remote-service-unavailable',
  'accesscontrol.limited-by-api-access-count',
]);

/**
 * Chama um metodo da API.
 * @param {string} method            ex.: 'aliexpress.trade.buy.placeorder'
 * @param {Record<string, any>} businessParams
 * @param {{ timeoutMs?: number, tentativas?: number, dryRun?: boolean }} [opts]
 */
export async function callAliExpress(method, businessParams, opts = {}) {
  const { timeoutMs = 20_000, tentativas = 3, dryRun = config.ALI_DRY_RUN } = opts;

  // O token sai do banco (renovado pelo cron), com a variável de
  // ambiente como reserva. Em memória por 1 min para o cron não
  // consultar o banco a cada chamada.
  const payload = buildSignedPayload({
    businessParams,
    method,
    appKey: config.ALI_APP_KEY,
    appSecret: config.ALI_APP_SECRET,
    accessToken: await tokenAtual(),
    signMethod: config.ALI_SIGN_METHOD,
  });

  if (dryRun) {
    logger.warn('DRY RUN — requisicao montada mas nao enviada', {
      method,
      gateway: config.ALI_GATEWAY,
      params: businessParams,
    });
    return {
      __dry_run: true,
      method,
      payloadKeys: Object.keys(payload),
    };
  }

  let ultimoErro;

  for (let tentativa = 1; tentativa <= tentativas; tentativa++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const res = await fetch(config.ALI_GATEWAY, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
          Accept: 'application/json',
        },
        body: new URLSearchParams(payload).toString(),
        signal: controller.signal,
      });

      const texto = await res.text();
      let json;
      try {
        json = JSON.parse(texto);
      } catch {
        throw new AliExpressError('Resposta nao-JSON do gateway', {
          raw: texto.slice(0, 500),
          retryable: res.status >= 500,
        });
      }

      // Erro de plataforma (assinatura, permissao, rate limit...)
      if (json.error_response) {
        const e = json.error_response;
        const code = e.code || e.sub_code;
        throw new AliExpressError(mensagemLegivel(e) ?? 'Erro na AliExpress', {
          code: e.code,
          subCode: e.sub_code,
          requestId: e.request_id,
          raw: json,
          retryable: CODIGOS_RETENTAVEIS.has(String(code)),
        });
      }

      logger.info('Chamada AliExpress OK', { method, tentativa });
      return json;
    } catch (err) {
      ultimoErro = err;
      const retentavel =
        err.name === 'AbortError' ||
        err instanceof TypeError || // falha de rede
        (err instanceof AliExpressError && err.retryable);

      if (!retentavel || tentativa === tentativas) break;

      const espera = Math.min(1000 * 2 ** (tentativa - 1), 8000);
      logger.warn('Falha transitoria; tentando de novo', {
        method,
        tentativa,
        espera,
        erro: err.message,
      });
      await new Promise((r) => setTimeout(r, espera));
    } finally {
      clearTimeout(timer);
    }
  }

  throw ultimoErro;
}

/**
 * O gateway devolve a carga util dentro de uma chave derivada do nome do
 * metodo (ex.: aliexpress_trade_buy_placeorder_response). Este helper
 * acha essa chave sem depender do nome exato.
 */
export function extrairResposta(json, method) {
  if (!json || typeof json !== 'object') return null;
  const esperado = method.replace(/\./g, '_') + '_response';
  if (json[esperado]) return json[esperado];
  const chave = Object.keys(json).find((k) => k.endsWith('_response'));
  return chave ? json[chave] : json;
}

export default { callAliExpress, extrairResposta, AliExpressError };
