/**
 * =====================================================================
 * Status de pedido da AliExpress — modulo puro, sem config nem I/O
 * =====================================================================
 *
 * ESTE E O PONTO QUE EVITA O PEDIDO FANTASMA.
 *
 * O placeorder devolve sucesso e um order_id mesmo sem ninguem ter
 * pago nada. Nesse momento o pedido fica em PLACE_ORDER_SUCCESS —
 * criado, visivel para o vendedor, e completamente parado. Vendedor
 * nenhum despacha pedido nao pago, e depois do prazo ele cancela
 * sozinho, sem aviso nenhum.
 *
 * So quando o status vira WAIT_SELLER_SEND_GOODS o dinheiro entrou de
 * fato e o fornecedor comeca a separar.
 *
 * Regra de ouro do mapa abaixo: status que voce nao conhece NUNCA vira
 * 'pago'. Na duvida, 'desconhecido' — o pedido continua sendo vigiado
 * pelo cron em vez de ser dado como resolvido por engano.
 */

export const STATUS_ALI = {
  // Criado, dinheiro NAO entrou
  PLACE_ORDER_SUCCESS: 'nao_pago',
  PAYMENT_PROCESSING: 'nao_pago',

  // Pago, fornecedor ainda nao despachou
  WAIT_SELLER_SEND_GOODS: 'pago',
  WAIT_SELLER_EXAMINE_MONEY: 'pago',

  // Despachado
  SELLER_PART_SEND_GOODS: 'enviado',
  WAIT_BUYER_ACCEPT_GOODS: 'enviado',

  // Encerrado
  FUND_PROCESSING: 'finalizado',
  FINISH: 'finalizado',

  // Morreu
  IN_CANCEL: 'cancelado',
  ORDER_CANCEL: 'cancelado',

  // Precisa de gente olhando
  IN_ISSUE: 'disputa',
  IN_FROZEN: 'disputa',
  RISK_CONTROL: 'disputa',
};

/**
 * @param {string|null|undefined} statusCru
 * @returns {'nao_pago'|'pago'|'enviado'|'finalizado'|'cancelado'|'disputa'|'desconhecido'}
 */
export function classificarStatusAli(statusCru) {
  if (!statusCru) return 'desconhecido';
  return STATUS_ALI[String(statusCru).toUpperCase()] ?? 'desconhecido';
}

/** O dinheiro ja saiu da sua conta? */
export const foiPago = (statusCru) =>
  ['pago', 'enviado', 'finalizado'].includes(classificarStatusAli(statusCru));

/** Link direto para a tela do pedido no site da AliExpress (para pagar). */
export const linkPedidoAli = (orderId) =>
  `https://www.aliexpress.com/p/order/detail.html?orderId=${orderId}`;

/** Lista de pedidos aguardando pagamento na conta. */
export const LINK_PEDIDOS_PENDENTES = 'https://www.aliexpress.com/p/order/index.html';

export default { STATUS_ALI, classificarStatusAli, foiPago, linkPedidoAli };
