import config from '../config.js';
import logger from '../lib/logger.js';
import { callAliExpress } from './client.js';
import { buildSignedPayload } from './sign.js';

/**
 * =====================================================================
 * Diagnóstico da conta AliExpress
 * =====================================================================
 *
 * Sem gerente de conta, a forma de descobrir o que o seu app pode fazer
 * é provocar a API e ler o código de erro. Cada erro diz uma coisa
 * diferente, e a diferença entre eles é o que você precisa saber.
 *
 * A distinção central: erro de ASSINATURA é problema de configuração
 * sua; erro de PERMISSÃO é escopo não liberado; e "não encontrado" é a
 * melhor notícia possível — significa que a chamada passou por
 * assinatura, token e permissão, e o único problema foi o ID falso que
 * mandamos de propósito.
 *
 * Este módulo devolve dados estruturados. Quem apresenta é o painel
 * (na tela) ou o scripts/diagnose.js (no terminal) — os dois consomem
 * a mesma fonte, para não divergirem com o tempo.
 */

const DIAGNOSTICOS = {
  IncompleteSignature: {
    tipo: 'assinatura',
    diz: 'Assinatura rejeitada.',
    faca: 'Verifique ALI_SIGN_METHOD (sha256 x md5) e se o APP_SECRET está correto e sem espaço.',
  },
  InvalidSignature: {
    tipo: 'assinatura',
    diz: 'Assinatura inválida.',
    faca: 'Método de assinatura ou secret errado.',
  },
  'invalid-signature': {
    tipo: 'assinatura',
    diz: 'Assinatura inválida.',
    faca: 'Confira ALI_SIGN_METHOD.',
  },
  InvalidTimestamp: {
    tipo: 'assinatura',
    diz: 'Timestamp fora da janela aceita.',
    faca: 'Relógio do servidor dessincronizado, ou formato de timestamp errado para este gateway.',
  },
  /**
   * Erros de VALIDAÇÃO são o melhor resultado possível numa sondagem.
   * Quer dizer que a chamada passou por app, assinatura, token e
   * permissão, e só tropeçou nos parâmetros falsos que mandamos de
   * propósito. Sem isto no mapa, o placeorder aparecia como "?" e a
   * recomendação dizia "nenhum método passou" — para um método que
   * funciona.
   */
  MissingParameter: {
    tipo: 'validacao',
    diz: 'Chamada aceita; faltaram parametros (esperado nesta sondagem).',
    faca: null,
  },
  InvalidParameter: {
    tipo: 'validacao',
    diz: 'Chamada aceita; parametros invalidos (esperado nesta sondagem).',
    faca: null,
  },
  'isv.parameter-error': {
    tipo: 'validacao',
    diz: 'Chamada aceita; parametro invalido (esperado nesta sondagem).',
    faca: null,
  },
  InsufficientPermission: {
    tipo: 'permissao',
    diz: 'O app nao tem permissao para este metodo.',
    faca: 'Use outro metodo da lista, ou peca o escopo no console.',
  },
  IllegalAccessToken: {
    tipo: 'token',
    diz: 'Token ausente, invalido ou expirado.',
    faca: 'Autorize pelo painel (aba Sistema). O app ja e reconhecido — falta so o token.',
  },
  InvalidApiPath: {
    tipo: 'metodo',
    diz: 'Este metodo nao existe neste gateway.',
    faca: 'Use um dos outros candidatos da lista.',
  },
  'Invalid session': {
    tipo: 'token',
    diz: 'ALI_ACCESS_TOKEN inválido ou expirado.',
    faca: 'Gere um novo token no console do app. Eles expiram.',
  },
  InvalidSessionKey: {
    tipo: 'token',
    diz: 'Token inválido ou expirado.',
    faca: 'Gere um novo access token no console.',
  },
  'Insufficient isv permissions': {
    tipo: 'permissao',
    diz: 'O app NÃO tem permissão para este método.',
    faca: 'Peça o escopo no console, ou use o método equivalente do programa que você tem.',
  },
  'isv.permission-deny': {
    tipo: 'permissao',
    diz: 'Permissão negada para este método.',
    faca: 'Escopo não liberado para o seu app.',
  },
  'Invalid method': {
    tipo: 'metodo',
    diz: 'O método não existe com esse nome.',
    faca: 'Confira a grafia exata na lista de APIs do console.',
  },
  InvalidAppKey: {
    tipo: 'app',
    diz: 'A plataforma nao reconhece este APP_KEY.',
    faca: 'Confira se a chave veio do console da AliExpress Open Platform (api-sg), sem espacos, e se o app esta ativo.',
  },
  'Invalid app key': {
    tipo: 'app',
    diz: 'APP_KEY invalida.',
    faca: 'Chave errada, com espaco, ou de outra plataforma.',
  },
  AppKeyDisabled: {
    tipo: 'app',
    diz: 'O app existe mas esta desativado.',
    faca: 'Verifique o status do app no console.',
  },
  'App is not on-line': {
    tipo: 'app',
    diz: 'O app ainda nao esta publicado/online.',
    faca: 'Conclua a publicacao do app no console.',
  },
  'accesscontrol.limited-by-api-access-count': {
    tipo: 'limite',
    diz: 'Limite de chamadas atingido.',
    faca: 'Espere alguns minutos e tente de novo.',
  },
};

/** Nomes variam conforme o programa liberado para a conta. */
export const CANDIDATOS = {
  pedido_get: [
    'aliexpress.trade.order.get',
    'aliexpress.ds.trade.order.get',
    'aliexpress.trade.ds.order.get',
    'aliexpress.solution.order.get',
  ],
  place_order: ['aliexpress.trade.buy.placeorder', 'aliexpress.ds.order.create'],
  frete: [
    'aliexpress.ds.freight.query',
    'aliexpress.logistics.buyer.freight.calculate',
    'aliexpress.freight.calculate',
  ],
  produto_get: [
    'aliexpress.ds.product.get',
    'aliexpress.postproduct.redefining.findaeproductbyidfordropshipper',
    'aliexpress.solution.product.info.get',
  ],
};

/** Parâmetros propositalmente inválidos: queremos o erro, não o efeito. */
const PARAMETROS = {
  pedido_get: { order_id: '1' },
  place_order: { param_place_order_request4_open_api_d_t_o: JSON.stringify({}) },
  frete: {
    queryDeliveryReq: JSON.stringify({ productId: '1', country_code: 'BR' }),
  },
  produto_get: {
    product_id: '1005004043442825',
    ship_to_country: 'BR',
    target_currency: 'BRL',
    target_language: 'pt',
  },
};

function interpretar(err) {
  const chaves = [err.code, err.subCode, err.message].filter(Boolean).map(String);
  for (const chave of chaves) {
    for (const [padrao, info] of Object.entries(DIAGNOSTICOS)) {
      if (chave.toLowerCase().includes(padrao.toLowerCase())) return info;
    }
  }
  return null;
}

async function testarMetodo(metodo, params) {
  try {
    await callAliExpress(metodo, params, {
      tentativas: 1,
      dryRun: false, // sondagem precisa sair de verdade
      timeoutMs: 8000,
    });
    return { metodo, resultado: 'ok', detalhe: 'Respondeu com sucesso.', acesso: true };
  } catch (err) {
    const info = interpretar(err);
    const tipo = info?.tipo ?? 'outro';

    // `acesso` tem TRÊS estados, e a distinção importa:
    //   true  = a chamada passou por app, assinatura, token e permissão
    //   false = foi barrada em algum desses
    //   null  = indeterminado
    //
    // Antes eu tratava erro desconhecido como sucesso, e o resultado
    // foi um diagnóstico que exibia nove ✓ enquanto TODAS as chamadas
    // eram recusadas na autenticação. Ferramenta de diagnóstico que
    // erra para o lado otimista é pior que não ter ferramenta.
    const BLOQUEADO = ['app', 'assinatura', 'token', 'permissao', 'metodo'];
    const acesso = BLOQUEADO.includes(tipo) ? false : tipo === 'outro' ? null : true;
    // 'ok' e 'validacao' caem no `true` acima: os dois significam que a
    // requisicao chegou inteira ao metodo.

    return {
      metodo,
      resultado: tipo,
      acesso,
      detalhe: info?.diz ?? err.message,
      faca: info?.faca ?? null,
      code: err.code ?? err.subCode ?? null,
    };
  }
}

const pausa = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Roda o diagnóstico completo.
 * @returns {Promise<object>} resultado estruturado
 */
export async function rodarDiagnostico() {
  const avisos = [];

  if (config.ALI_GATEWAY.includes('taobao.com')) {
    avisos.push('Gateway errado. Use https://api-sg.aliexpress.com/sync');
  }
  if (/\s/.test(config.ALI_APP_SECRET)) {
    avisos.push('APP_SECRET contém espaço em branco — causa comum de assinatura inválida.');
  }
  if (/\s/.test(config.ALI_APP_KEY)) {
    avisos.push('APP_KEY contém espaço em branco. Copiar do painel costuma trazer quebra de linha junto.');
  }
  if (!/^\d+$/.test(config.ALI_APP_KEY.trim())) {
    avisos.push(
      'APP_KEY não é só dígitos. As chaves da AliExpress Open Platform são numéricas — ' +
        'confira se você não copiou o App Secret, o App Name ou uma chave da plataforma antiga.'
    );
  }

  // A assinatura é montada localmente: se falhar aqui, nem adianta ir à rede.
  let assinatura;
  try {
    const exemplo = buildSignedPayload({
      businessParams: { teste: '1' },
      method: 'aliexpress.trade.order.get',
      appKey: config.ALI_APP_KEY,
      appSecret: config.ALI_APP_SECRET,
      accessToken: config.ALI_ACCESS_TOKEN,
      signMethod: config.ALI_SIGN_METHOD,
    });
    assinatura = { ok: true, tamanho: exemplo.sign.length };
  } catch (err) {
    assinatura = { ok: false, erro: err.message };
  }

  const grupos = {};
  for (const [grupo, metodos] of Object.entries(CANDIDATOS)) {
    grupos[grupo] = [];
    for (const metodo of metodos) {
      grupos[grupo].push(await testarMetodo(metodo, PARAMETROS[grupo]));
      await pausa(300); // respeita o limite de QPS da plataforma
    }
  }

  /**
   * Bloqueio global.
   *
   * Se TODOS os métodos falharam pelo mesmo motivo de autenticação, não
   * foi permissão de método que reprovou — a requisição nem chegou lá.
   * Nesse caso não existe recomendação possível, e dizer o contrário
   * mandaria você configurar variáveis com base em teste nenhum.
   */
  const todos = Object.values(grupos).flat();
  const tipos = new Set(todos.map((r) => r.resultado));
  const NIVEL_APP = ['app', 'assinatura', 'token'];

  let bloqueio = null;
  const soDeToken = todos.filter((r) => r.resultado === 'token').length >= todos.length - 1;

  if ((tipos.size === 1 && NIVEL_APP.includes([...tipos][0])) || soDeToken) {
    const exemplo = todos.find((r) => NIVEL_APP.includes(r.resultado)) ?? todos[0];
    bloqueio = {
      tipo: exemplo.resultado,
      code: exemplo.code,
      diz: exemplo.detalhe,
      faca: exemplo.faca,
      explicacao:
        'Todas as chamadas foram barradas antes da checagem de permissao. ' +
        'Nenhum metodo foi testado de fato — resolva isto primeiro.',
    };
  }

  // Sem bloqueio, sugere para cada variável o primeiro método aprovado.
  const recomendacao = bloqueio
    ? {
        ALI_METHOD_ORDER_GET: null,
        ALI_METHOD_PLACE_ORDER: null,
        ALI_METHOD_PRODUCT_GET: null,
        ALI_METHOD_FREIGHT: null,
      }
    : {
        ALI_METHOD_ORDER_GET: grupos.pedido_get.find((r) => r.acesso === true)?.metodo ?? null,
        ALI_METHOD_PLACE_ORDER: grupos.place_order.find((r) => r.acesso === true)?.metodo ?? null,
            ALI_METHOD_PRODUCT_GET: grupos.produto_get.find((r) => r.acesso === true)?.metodo ?? null,
        ALI_METHOD_FREIGHT: grupos.frete.find((r) => r.acesso === true)?.metodo ?? null,
      };

  // Estado do token entra no relatorio: quando tudo falha por token,
  // a primeira pergunta e "existe token?" — e a resposta deve estar
  // na mesma tela, nao em outra aba.
  let credencial = { tem: false, origem: null, expira_em: null };
  try {
    const { lerCredenciais } = await import('./auth.js');
    const cred = await lerCredenciais();
    if (cred?.access_token) {
      credencial = { tem: true, origem: 'banco', expira_em: cred.expira_em };
    } else if (config.ALI_ACCESS_TOKEN) {
      credencial = { tem: true, origem: 'variavel de ambiente', expira_em: null };
    }
  } catch {
    if (config.ALI_ACCESS_TOKEN) {
      credencial = { tem: true, origem: 'variavel de ambiente', expira_em: null };
    }
  }

  const resultado = {
    credencial,
    configuracao: {
      gateway: config.ALI_GATEWAY,
      sign_method: config.ALI_SIGN_METHOD,
      app_key: `${config.ALI_APP_KEY.slice(0, 4)}...${config.ALI_APP_KEY.slice(-2)}`,
      secret_caracteres: config.ALI_APP_SECRET.length,
      token_caracteres: config.ALI_ACCESS_TOKEN.length,
      dry_run: config.ALI_DRY_RUN,
      avisos,
    },
    assinatura,
    bloqueio,
    grupos,
    recomendacao,
    atual: {
      ALI_METHOD_ORDER_GET: config.ALI_METHOD_ORDER_GET,
      ALI_METHOD_PLACE_ORDER: config.ALI_METHOD_PLACE_ORDER,
      ALI_METHOD_PRODUCT_GET: config.ALI_METHOD_PRODUCT_GET,
      ALI_METHOD_FREIGHT: config.ALI_METHOD_FREIGHT,
    },
  };

  logger.info('Diagnostico AliExpress concluido', { recomendacao });
  return resultado;
}

export default { rodarDiagnostico, CANDIDATOS };
