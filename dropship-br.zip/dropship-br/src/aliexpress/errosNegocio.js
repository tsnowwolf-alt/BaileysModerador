/**
 * =====================================================================
 * Erros de negócio do placeorder
 * =====================================================================
 *
 * A AliExpress devolve códigos como
 * B_DROPSHIPPER_DELIVERY_ADDRESS_CPF_NOT_MATCH. O código é preciso,
 * mas não diz o que fazer — e quem lê o alerta às 3 da manhã precisa
 * decidir entre corrigir dado, reprocessar ou estornar.
 *
 * A distinção que mais importa é `retentavel`:
 *   false → reprocessar vai falhar igual. Ou corrige o dado, ou estorna.
 *   true  → o problema é transitório; vale tentar de novo.
 *
 * Sem isso, o instinto é sempre clicar em reprocessar — e ver o mesmo
 * erro dez vezes enquanto o prazo do cliente corre.
 */

export const ERROS_NEGOCIO = {
  B_DROPSHIPPER_DELIVERY_ADDRESS_CPF_NOT_MATCH: {
    texto: 'O CPF não corresponde ao nome do destinatário.',
    detalhe:
      'A AliExpress cruza CPF e nome na Receita Federal. O nome precisa ser o do titular do CPF.',
    acao: 'Confirme com o cliente o nome completo exato do titular do CPF e refaça o pedido.',
    retentavel: false,
  },
  B_DROPSHIPPER_DELIVERY_ADDRESS_NOT_MATCH: {
    texto: 'O endereço foi recusado na validação.',
    detalhe: 'CEP, cidade ou estado inconsistentes entre si.',
    acao: 'Confira o CEP no site dos Correios e corrija o cadastro do pedido.',
    retentavel: false,
  },
  B_INVENTORY_HOLD_ERROR: {
    texto: 'Sem estoque para esta variação.',
    detalhe: 'O fornecedor pode ter esgotado a cor/tamanho escolhido.',
    acao: 'Verifique o produto na Ali. Se acabou, tire do ar e estorne o cliente.',
    retentavel: false,
  },
  B_ITEM_OFF_SHELF: {
    texto: 'O produto saiu do ar na AliExpress.',
    detalhe: 'O anúncio foi removido pelo fornecedor.',
    acao: 'Tire o produto da sua loja e estorne o cliente.',
    retentavel: false,
  },
  B_SKU_NOT_EXIST: {
    texto: 'O SKU não existe mais.',
    detalhe: 'O sku_attr cadastrado não corresponde a nenhuma variação atual.',
    acao: 'Reimporte o produto pelo link para atualizar os SKUs.',
    retentavel: false,
  },
  B_LOGISTICS_NOT_SUPPORT: {
    texto: 'O fornecedor não entrega neste endereço.',
    detalhe: 'Pode ser região não atendida pela transportadora dele.',
    acao: 'Estorne o cliente e avise que não há entrega para a região.',
    retentavel: false,
  },
  'PROMOTION-QUANTITY-LIMIT': {
    texto: 'A promoção deste produto esgotou para a sua conta.',
    detalhe:
      'Preços de "novo usuário" e ofertas de boas-vindas valem por quantidade limitada. ' +
      'O custo importado era o preço promocional, não o preço real.',
    acao:
      'Confira o preço cheio na Ali, atualize o custo do produto e revise seu preço de venda. ' +
      'Pedidos pendentes não pagos também seguram cota da promoção.',
    retentavel: false,
  },
  'PROMOTION-LIMIT': {
    texto: 'Limite de promoção atingido.',
    detalhe: 'A oferta tem teto por conta ou por período.',
    acao: 'Use o preço cheio como custo e refaça o pedido.',
    retentavel: false,
  },
  B_PRICE_CHANGED: {
    texto: 'O preço mudou desde a importação.',
    detalhe: 'Sua margem pode estar diferente do que você calculou.',
    acao: 'Reimporte o produto e revise o preço de venda.',
    retentavel: true,
  },
  B_ORDER_LIMIT: {
    texto: 'Limite de pedidos atingido na conta.',
    detalhe: 'A AliExpress limita volume por período.',
    acao: 'Aguarde e reprocesse mais tarde.',
    retentavel: true,
  },
};

/**
 * @param {string|null} codigo
 * @returns {{ texto: string, detalhe?: string, acao: string, retentavel: boolean|null }}
 */
export function interpretarErroNegocio(codigo) {
  if (!codigo) {
    return {
      texto: 'Falha não identificada.',
      acao: 'Veja o retorno cru no log antes de reprocessar.',
      retentavel: null,
    };
  }

  const chave = String(codigo).toUpperCase();
  if (ERROS_NEGOCIO[chave]) return ERROS_NEGOCIO[chave];

  // Códigos desconhecidos: não afirmamos que vale reprocessar. Chutar
  // "pode tentar de novo" faria alguém repetir uma falha permanente.
  const dicas = [];
  if (chave.includes('CPF')) dicas.push('Envolve o CPF do destinatário.');
  if (chave.includes('ADDRESS')) dicas.push('Envolve o endereço de entrega.');
  if (chave.includes('INVENTORY') || chave.includes('STOCK')) dicas.push('Envolve estoque.');
  if (chave.includes('SKU')) dicas.push('Envolve a variação escolhida.');

  return {
    texto: `Recusado pela AliExpress: ${codigo}`,
    detalhe: dicas.join(' ') || undefined,
    acao: 'Código não catalogado. Confira o retorno cru antes de reprocessar.',
    retentavel: null,
  };
}

export default { interpretarErroNegocio, ERROS_NEGOCIO };
