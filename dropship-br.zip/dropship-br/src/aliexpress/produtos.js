import config from '../config.js';
import logger from '../lib/logger.js';
import { callAliExpress, extrairResposta } from './client.js';
import { extrairProductId, ehLinkCurto } from '../lib/aliUrl.js';

/**
 * =====================================================================
 * Importacao de produto a partir do link
 * =====================================================================
 *
 * Esta funcao NUNCA falha de vez. Se a API nao responder, se o metodo
 * nao estiver liberado no seu app ou se o formato da resposta mudar,
 * ela devolve um rascunho vazio com o product_id preenchido e voce
 * completa a mao no painel.
 *
 * Isso e proposital: a estrutura de resposta desses endpoints varia
 * conforme o programa (DS x Trade) e muda entre versoes. Um importador
 * que quebra a cada mudanca deixaria voce sem conseguir cadastrar
 * produto nenhum.
 */

/**
 * =====================================================================
 * Links curtos (a.aliexpress.com/_xxxxx)
 * =====================================================================
 *
 * A versão anterior fazia um fetch com `redirect: 'follow'` e lia
 * `res.url`. Falhava em silêncio por dois motivos: requisição sem cara
 * de navegador costuma ser barrada, e quando o destino é uma página
 * HTML o `res.url` pode não conter o id.
 *
 * Agora seguimos os saltos à mão, olhando o cabeçalho Location de cada
 * um — é ali que o id aparece primeiro, antes de qualquer HTML. Se
 * ainda assim não achar, procuramos no corpo da página.
 */
const CABECALHOS_NAVEGADOR = {
  'User-Agent':
    'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
};

export async function resolverLinkCurto(url, saltos = 5) {
  let atual = url;

  for (let i = 0; i < saltos; i++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10_000);

    let res;
    try {
      res = await fetch(atual, {
        method: 'GET',
        redirect: 'manual', // queremos ver cada Location
        signal: controller.signal,
        headers: CABECALHOS_NAVEGADOR,
      });
    } catch (err) {
      logger.warn('Falha ao seguir link curto', { salto: i, erro: err.message });
      return null;
    } finally {
      clearTimeout(timer);
    }

    const destino = res.headers.get('location');

    if (destino) {
      // Location pode ser relativo.
      atual = new URL(destino, atual).toString();
      if (extrairProductId(atual).ok) return atual;
      continue;
    }

    // Sem redirecionamento: chegamos numa página. Procura o id nela.
    if (res.ok) {
      const html = await res.text().catch(() => '');
      const achado =
        html.match(/\/item\/(\d{8,20})\.html/) ??
        html.match(/["']productId["']\s*:\s*["']?(\d{8,20})/) ??
        html.match(/window\.runParams[\s\S]{0,2000}?["'](\d{13,16})["']/);
      if (achado) return `https://www.aliexpress.com/item/${achado[1]}.html`;
    }

    return null;
  }

  return null;
}

/**
 * @param {string} entrada link ou id
 * @returns {Promise<{ productId: string, rascunho: object, fonte: 'api'|'manual', aviso?: string }>}
 */
export async function importarPorLink(entrada) {
  let resultado = extrairProductId(entrada);

  // Link curto: segue o redirect e tenta de novo.
  if (!resultado.ok && resultado.linkCurto) {
    const destino = await resolverLinkCurto(entrada);
    if (destino) resultado = extrairProductId(destino);

    if (!resultado.ok) {
      // Instrução acionável em vez de explicação técnica: a saída
      // manual leva dez segundos e sempre funciona.
      const erro = new Error(
        'Não consegui abrir esse link curto — a AliExpress costuma bloquear ' +
          'acesso automático. Abra o link no navegador, espere redirecionar, ' +
          'e cole aqui a URL completa da barra de endereço.'
      );
      erro.status = 422;
      throw erro;
    }
  }

  if (!resultado.ok) {
    const erro = new Error(resultado.motivo);
    erro.status = 422;
    throw erro;
  }

  const { productId } = resultado;

  const rascunhoVazio = {
    titulo: '',
    descricao: '',
    imagens: [],
    aliexpress_product_id: productId,
    aliexpress_url: `https://www.aliexpress.com/item/${productId}.html`,
    estoque_br: false,
    preco_custo_centavos: null,
    preco_venda_centavos: null,
    variacoes: [],
  };

  if (!config.ALI_METHOD_PRODUCT_GET) {
    return {
      productId,
      rascunho: rascunhoVazio,
      fonte: 'manual',
      aviso: 'ALI_METHOD_PRODUCT_GET nao configurado; preencha os dados a mao.',
    };
  }

  try {
    const json = await callAliExpress(
      config.ALI_METHOD_PRODUCT_GET,
      {
        product_id: productId,
        ship_to_country: 'BR',
        target_currency: 'BRL',
        target_language: 'pt',
      },
      { tentativas: 2, dryRun: false } // leitura: sempre pode rodar de verdade
    );

    const dados = normalizarProduto(json, config.ALI_METHOD_PRODUCT_GET, productId);
    return { productId, rascunho: { ...rascunhoVazio, ...dados }, fonte: 'api' };
  } catch (err) {
    logger.warn('Importacao via API falhou; devolvendo rascunho manual', {
      productId,
      erro: err.message,
      code: err.code ?? err.subCode,
    });
    return {
      productId,
      rascunho: rascunhoVazio,
      fonte: 'manual',
      aviso: `A API nao retornou os dados (${err.message}). Preencha a mao.`,
    };
  }
}

/**
 * Extrai o que der da resposta. Os nomes de campo variam bastante entre
 * versoes, entao cada valor e procurado em varios caminhos possiveis e
 * o que nao aparecer fica vazio para voce completar.
 */
function normalizarProduto(json, metodo, productId) {
  const resposta = extrairResposta(json, metodo);
  const r = resposta?.result ?? resposta ?? {};

  const base = r.ae_item_base_info_dto ?? r.base_info ?? r;
  const midia = r.ae_multimedia_info_dto ?? r.multimedia_info ?? r;
  const skus = r.ae_item_sku_info_dtos?.ae_item_sku_info_d_t_o ?? r.sku_info_list ?? [];
  const envio = r.logistics_info_dto ?? r.package_info_dto ?? {};

  const imagensCru =
    midia.image_urls ?? midia.image_url_list ?? base.image_urls ?? '';
  const imagens = Array.isArray(imagensCru)
    ? imagensCru
    : String(imagensCru).split(/[;,]/).map((s) => s.trim()).filter(Boolean);

  const paisOrigem =
    envio.ship_to_country ?? envio.send_goods_country_code ?? r.ship_from_country ?? null;

  return {
    titulo: base.subject ?? base.title ?? base.product_title ?? '',
    // A Ali devolve a página de detalhe inteira em HTML. Exibir isso
    // cru mostraria <div> e <br/> ao cliente.
    descricao: limparHtml(base.detail ?? ''),
    imagens: imagens.slice(0, 10),
    // So marca TRUE com confirmacao explicita. Na duvida fica FALSE e
    // aparece no checklist de ativacao.
    estoque_br: paisOrigem === 'BR',
    preco_custo_centavos: extrairPrecoCentavos(base, skus),
    // Preço cheio, quando existe. Serve para avisar que o custo
    // importado pode ser oferta de primeira compra — que some no
    // segundo pedido e leva a margem junto.
    preco_cheio_centavos: extrairPrecoCheioCentavos(base, skus),
    aliexpress_url: `https://www.aliexpress.com/item/${productId}.html`,
    variacoes: desduplicarNomes(
      (Array.isArray(skus) ? skus : []).map((s, i) => ({
        nome: montarNomeVariacao(s, i),
        aliexpress_sku_id: s.sku_id ? String(s.sku_id) : null,
        aliexpress_sku_attr: s.sku_attr ?? s.id ?? null,
        preco_custo_centavos: extrairPrecoCentavos(s),
        imagem: s.sku_image ?? null,
        ordem: i,
      }))
    ),
  };
}

/**
 * Entidades HTML nomeadas que aparecem em texto em português.
 *
 * A versão anterior tratava só &nbsp; &amp; &lt; &gt; &quot; — o que
 * deixava "r&aacute;pidos" e "fun&ccedil;&otilde;es" na tela do
 * cliente. Em português acentuado, essas são justamente as que mais
 * aparecem.
 */
const ENTIDADES = {
  nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", '#39': "'",
  aacute: 'á', agrave: 'à', atilde: 'ã', acirc: 'â', auml: 'ä',
  eacute: 'é', egrave: 'è', ecirc: 'ê', euml: 'ë',
  iacute: 'í', icirc: 'î', iuml: 'ï',
  oacute: 'ó', otilde: 'õ', ocirc: 'ô', ouml: 'ö',
  uacute: 'ú', ucirc: 'û', uuml: 'ü',
  ccedil: 'ç', ntilde: 'ñ',
  Aacute: 'Á', Agrave: 'À', Atilde: 'Ã', Acirc: 'Â',
  Eacute: 'É', Ecirc: 'Ê',
  Iacute: 'Í', Oacute: 'Ó', Otilde: 'Õ', Ocirc: 'Ô',
  Uacute: 'Ú', Ccedil: 'Ç',
  ordf: 'ª', ordm: 'º', deg: '°', euro: '€', pound: '£', yen: '¥',
  laquo: '«', raquo: '»', hellip: '…', mdash: '—', ndash: '–',
  rsquo: '\u2019', lsquo: '\u2018', ldquo: '\u201C', rdquo: '\u201D',
  times: '×', middot: '·', bull: '•', reg: '®', copy: '©', trade: '™',
};

function decodificarEntidades(texto) {
  return String(texto)
    // Numéricas: &#233; e &#xE9;
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, num) => String.fromCodePoint(Number(num)))
    // Nomeadas conhecidas; as desconhecidas ficam como estão, porque
    // apagá-las esconderia que o texto veio quebrado.
    .replace(/&([a-z][a-z0-9]*);/gi, (inteiro, nome) => ENTIDADES[nome] ?? inteiro);
}

/** Tira tags e entidades, deixando só o texto legível. */
function limparHtml(html) {
  return decodificarEntidades(
    String(html ?? '')
      .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, '')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|li|tr|h[1-6])>/gi, '\n')
      .replace(/<[^>]+>/g, '')
  )
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, 1500);
}

/**
 * Preço sem desconto promocional.
 *
 * A AliExpress mostra "R$ 6,99 novo usuário" com o valor cheio riscado
 * ao lado. O importador pega o promocional, e é ele que vai para o seu
 * custo — mas ele vale uma compra. Da segunda em diante o custo é o
 * cheio, e a margem que você calculou não existe mais.
 */
function extrairPrecoCheioCentavos(obj = {}, skus = []) {
  const bruto =
    obj.sku_price ??
    obj.offer_price ??
    obj.original_price ??
    obj.target_original_price ??
    (Array.isArray(skus) && skus[0]?.sku_price) ??
    null;
  if (bruto == null) return null;
  const n = Number(String(bruto).replace(',', '.'));
  return Number.isFinite(n) ? Math.round(n * 100) : null;
}

function extrairPrecoCentavos(obj = {}, skus = []) {
  const bruto =
    obj.offer_sale_price ??
    obj.sku_price ??
    obj.offer_bulk_sale_price ??
    obj.target_sale_price ??
    (Array.isArray(skus) && skus[0]?.offer_sale_price) ??
    null;
  if (bruto == null) return null;
  const n = Number(String(bruto).replace(',', '.'));
  return Number.isFinite(n) ? Math.round(n * 100) : null;
}

/**
 * Nome da variação.
 *
 * Prioriza os rótulos embutidos no próprio `sku_attr`, que vêm depois
 * do `#` em cada segmento: "14:100018786#For 17 pro max;5:361386#Preto"
 * vira "For 17 pro max / Preto".
 *
 * Antes eu lia só `ae_sku_property_dtos`, e para alguns produtos ele
 * traz apenas cor e origem — duas variações de modelos diferentes
 * saíam com o MESMO nome ("Limpar / Brasil"). Como a tabela tem
 * UNIQUE (produto_id, nome), o cadastro inteiro falhava.
 */
function montarNomeVariacao(sku, i) {
  const doAttr = rotulosDoSkuAttr(sku.sku_attr ?? sku.id);
  if (doAttr) return doAttr;

  const props =
    sku.ae_sku_property_dtos?.ae_sku_property_d_t_o ?? sku.sku_property_list ?? [];
  const nome = (Array.isArray(props) ? props : [])
    .map((p) => p.sku_property_value ?? p.property_value_definition_name ?? p.value)
    .filter(Boolean)
    .join(' / ');
  return nome || `Opcao ${i + 1}`;
}

/** "14:1234#Azul;5:99#M" -> "Azul / M" */
function rotulosDoSkuAttr(attr) {
  if (!attr) return null;
  const rotulos = String(attr)
    .split(';')
    .map((seg) => seg.split('#')[1])
    .filter(Boolean)
    .map((s) => s.trim());
  return rotulos.length ? rotulos.join(' / ') : null;
}

/**
 * Rede de segurança: mesmo com bons rótulos, dois SKUs podem colidir.
 * Em vez de deixar o banco recusar o cadastro inteiro, desempatamos
 * aqui — nome repetido é irritante, cadastro que não salva é pior.
 */
function desduplicarNomes(variacoes) {
  const usados = new Map();
  return variacoes.map((v) => {
    const base = v.nome;
    const n = (usados.get(base) ?? 0) + 1;
    usados.set(base, n);
    return n === 1 ? v : { ...v, nome: `${base} (${n})` };
  });
}

export default { importarPorLink, resolverLinkCurto };
