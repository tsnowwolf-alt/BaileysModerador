import crypto from 'node:crypto';

/**
 * =====================================================================
 * Assinatura digital da AliExpress Open Platform (padrao TOP / Alibaba)
 * =====================================================================
 *
 * Existem DOIS algoritmos historicos. Escolher o errado gera o erro
 * "IncompleteSignature" ou "InvalidSignature" e nada mais.
 *
 * 1) HMAC-SHA256  -> PADRAO ATUAL do gateway https://api-sg.aliexpress.com/sync
 *      base = concat(chave + valor) das chaves ordenadas em ASCII
 *      sign = HMAC_SHA256(base, APP_SECRET) em HEX MAIUSCULO
 *      (o secret NAO envolve a string; ele e a chave do HMAC)
 *
 * 2) MD5 (legado) -> gateway antigo https://gw.api.taobao.com/router/rest
 *      base = APP_SECRET + concat(chave + valor) ordenado + APP_SECRET
 *      sign = MD5(base) em HEX MAIUSCULO
 *
 * Voce pediu MD5. Implementei os dois e deixei o padrao em sha256,
 * porque o gateway novo rejeita MD5. Troque via ALI_SIGN_METHOD se o
 * console do seu app indicar o contrario.
 *
 * Regras comuns aos dois:
 *  - o proprio parametro `sign` nunca entra na base
 *  - parametros com valor null/undefined/'' sao descartados
 *  - a ordenacao e por code point da CHAVE (ASCII), nao por locale
 *  - objetos/arrays devem ir como JSON string ANTES de assinar; a string
 *    assinada tem que ser byte-a-byte igual a string enviada no corpo
 */

/**
 * Monta a string base concatenando chave+valor em ordem ASCII.
 * @param {Record<string, any>} params
 * @returns {string}
 */
export function buildBaseString(params) {
  return Object.keys(params)
    .filter((k) => {
      if (k === 'sign') return false;
      const v = params[k];
      return v !== undefined && v !== null && v !== '';
    })
    // localeCompare NAO serve aqui: precisa ser ordem de code point.
    .sort()
    .map((k) => `${k}${stringify(params[k])}`)
    .join('');
}

function stringify(value) {
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  // Objetos ja devem chegar serializados. Se nao chegaram, serializa aqui —
  // mas o MESMO resultado precisa ir no corpo da requisicao.
  return JSON.stringify(value);
}

/**
 * Gera a assinatura.
 * @param {Record<string, any>} params  todos os parametros (sistema + negocio)
 * @param {string} appSecret
 * @param {'sha256'|'md5'} method
 * @returns {string} hex maiusculo
 */
export function generateSign(params, appSecret, method = 'sha256') {
  if (!appSecret) throw new Error('ALI_APP_SECRET ausente ao gerar assinatura');

  const base = buildBaseString(params);

  if (method === 'md5') {
    return crypto
      .createHash('md5')
      .update(appSecret + base + appSecret, 'utf8')
      .digest('hex')
      .toUpperCase();
  }

  if (method === 'sha256' || method === 'hmac-sha256') {
    return crypto
      .createHmac('sha256', appSecret)
      .update(base, 'utf8')
      .digest('hex')
      .toUpperCase();
  }

  throw new Error(`Metodo de assinatura nao suportado: ${method}`);
}

/**
 * Recebe os parametros de negocio, adiciona os parametros de sistema
 * exigidos pelo gateway e devolve o payload final ja assinado.
 *
 * @param {object} opts
 * @param {Record<string, any>} opts.businessParams
 * @param {string} opts.method       ex.: 'aliexpress.trade.buy.placeorder'
 * @param {string} opts.appKey
 * @param {string} opts.appSecret
 * @param {string} [opts.accessToken]
 * @param {'sha256'|'md5'} [opts.signMethod]
 * @returns {Record<string, string>} pronto p/ virar application/x-www-form-urlencoded
 */
export function buildSignedPayload({
  businessParams,
  method,
  appKey,
  appSecret,
  accessToken,
  signMethod = 'sha256',
}) {
  const payload = {
    app_key: appKey,
    method,
    // O gateway /sync espera epoch em MILISSEGUNDOS.
    // (O gateway legado router/rest espera 'yyyy-MM-dd HH:mm:ss' em GMT+8.)
    timestamp: String(Date.now()),
    sign_method: signMethod,
    format: 'json',
    v: '2.0',
    ...(accessToken ? { session: accessToken } : {}),
    ...normalizeBusinessParams(businessParams),
  };

  payload.sign = generateSign(payload, appSecret, signMethod);
  return payload;
}

/**
 * Garante que objetos aninhados virem string UMA unica vez, para que a
 * string assinada seja identica a string enviada.
 */
function normalizeBusinessParams(params = {}) {
  const out = {};
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null) continue;
    out[k] = typeof v === 'object' ? JSON.stringify(v) : String(v);
  }
  return out;
}

/**
 * Assinatura para os endpoints /rest/ (sistema: criar e renovar token).
 *
 * DIFERENÇA QUE CUSTA HORAS: aqui o caminho da API entra na base
 * assinada, antes dos parâmetros. No gateway /sync não entra. Usar a
 * função errada devolve o mesmo IncompleteSignature dos outros casos,
 * sem pista de qual das duas é.
 *
 * @param {string} apiPath ex.: '/auth/token/create'
 */
export function generateRestSign(apiPath, params, appSecret, method = 'sha256') {
  const base = apiPath + buildBaseString(params);
  if (method === 'md5') {
    return crypto
      .createHash('md5')
      .update(appSecret + base + appSecret, 'utf8')
      .digest('hex')
      .toUpperCase();
  }
  return crypto
    .createHmac('sha256', appSecret)
    .update(base, 'utf8')
    .digest('hex')
    .toUpperCase();
}

export default { generateSign, buildBaseString, buildSignedPayload, generateRestSign };
