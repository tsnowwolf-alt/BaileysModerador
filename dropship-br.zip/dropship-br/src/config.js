import 'dotenv/config';
import { z } from 'zod';
import { parseEscala } from './lib/escalonamento.js';

/**
 * Validacao de ambiente na inicializacao.
 * Prefiro o processo morrer no boot a descobrir um secret faltando
 * no meio de uma compra real.
 */
const schema = z.object({
  NODE_ENV: z.string().default('production'),
  PORT: z.coerce.number().default(3000),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),

  DATABASE_URL: z.string().min(1, 'DATABASE_URL e obrigatoria'),
  PGSSL: z.string().optional(),

  // ----- AliExpress -----
  ALI_APP_KEY: z.string().min(1, 'ALI_APP_KEY e obrigatoria'),
  ALI_APP_SECRET: z.string().min(1, 'ALI_APP_SECRET e obrigatoria'),
  // Deixou de ser obrigatoria: o token normal vem do banco, gerado
  // pelo painel. Esta variavel serve so de reserva.
  ALI_ACCESS_TOKEN: z.string().default(''),

  ALI_GATEWAY: z.string().url().default('https://api-sg.aliexpress.com/sync'),
  ALI_SIGN_METHOD: z.enum(['sha256', 'md5']).default('sha256'),
  ALI_METHOD_PLACE_ORDER: z.string().default('aliexpress.trade.buy.placeorder'),
  ALI_METHOD_ORDER_GET: z.string().default('aliexpress.trade.order.get'),
  // Vazio = importador nao tenta a API e devolve rascunho manual.
  ALI_METHOD_PRODUCT_GET: z.string().default('aliexpress.ds.product.get'),
  // Usado para confirmar de qual pais o produto despacha. Vazio = a
  // verificacao fica manual (a caixinha do painel).
  ALI_METHOD_FREIGHT: z.string().default('aliexpress.ds.freight.query'),
  ALI_DRY_RUN: z
    .string()
    .default('true')
    .transform((v) => v.toLowerCase() === 'true'),

  // Marcos de escalonamento do alerta, em minutos, separados por virgula.
  // Cada marco ultrapassado dispara um aviso mais urgente que o anterior.
  ALI_ALERTA_ESCALONAMENTO: z
    .string()
    .default('30,120,360')
    .transform((v) => parseEscala(v)),
  // Horas ate considerar que o pedido provavelmente expirou.
  ALI_PRAZO_PAGAMENTO_HORAS: z.coerce.number().default(20),

  // ----- Mercado Pago -----
  MP_ACCESS_TOKEN: z.string().optional(),
  MP_WEBHOOK_SECRET: z.string().optional(),
  MP_NOTIFICATION_URL: z.string().url().optional().or(z.literal('')),

  // ----- Admin / alertas -----
  // 16 caracteres nao e capricho: este token e a unica coisa entre a
  // internet e o painel que publica produtos e le dados de pedido.
  // Uma frase resolve e e facil de lembrar.
  ADMIN_TOKEN: z
    .string()
    .min(
      16,
      'ADMIN_TOKEN precisa de 16+ caracteres. Uma frase serve, ex.: garrafa-termica-loja-2026'
    ),
  TELEGRAM_BOT_TOKEN: z.string().optional(),
  TELEGRAM_CHAT_ID: z.string().optional(),
  ALERT_WEBHOOK_URL: z.string().url().optional().or(z.literal('')),

  // ----- Rastreio -----
  LINKETRACK_USER: z.string().optional(),
  LINKETRACK_TOKEN: z.string().optional(),

  TRACKING_JOB_BATCH_SIZE: z.coerce.number().default(25),
  TRACKING_JOB_INTERVAL_MINUTES: z.coerce.number().default(0),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  console.error('Configuracao invalida:');
  for (const issue of parsed.error.issues) {
    console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
  }
  process.exit(1);
}

export const config = parsed.data;

export const isProd = config.NODE_ENV === 'production';

// Avisos de configuracao incompleta — nao derrubam o boot, mas aparecem
// no log do Railway em vez de virarem surpresa em producao.
if (config.ALI_DRY_RUN) {
  console.warn(
    '[AVISO] ALI_DRY_RUN=true — pedidos serao montados e assinados, mas NAO enviados a AliExpress.'
  );
}
if (!config.MP_WEBHOOK_SECRET) {
  console.warn('[AVISO] MP_WEBHOOK_SECRET ausente — o webhook do Mercado Pago sera recusado.');
}
if (!config.TELEGRAM_BOT_TOKEN && !config.ALERT_WEBHOOK_URL) {
  console.warn(
    '[AVISO] Nenhum canal de alerta configurado. Pedido travado sem pagamento na Ali passara despercebido.'
  );
}

// O ultimo marco depois do prazo de expiracao seria um aviso que chega
// quando o pedido ja morreu.
const ultimoMarco = config.ALI_ALERTA_ESCALONAMENTO.at(-1) ?? 0;
if (ultimoMarco >= config.ALI_PRAZO_PAGAMENTO_HORAS * 60) {
  console.warn(
    `[AVISO] O ultimo marco de alerta (${ultimoMarco}min) cai depois do prazo estimado ` +
      `(${config.ALI_PRAZO_PAGAMENTO_HORAS}h). Reduza ALI_ALERTA_ESCALONAMENTO.`
  );
}

export default config;
