import pg from 'pg';
import config from './config.js';
import logger from './lib/logger.js';

const { Pool } = pg;

/**
 * O Postgres do Railway exige TLS. O certificado e interno, entao
 * rejectUnauthorized: false e o comportamento esperado aqui.
 */
const needsSSL =
  config.PGSSL === 'require' ||
  /railway|render|neon|supabase|amazonaws/.test(config.DATABASE_URL);

export const pool = new Pool({
  connectionString: config.DATABASE_URL,
  ssl: needsSSL ? { rejectUnauthorized: false } : false,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
});

pool.on('error', (err) => {
  logger.error('Erro inesperado no pool do Postgres', { err: err.message });
});

export function query(text, params) {
  return pool.query(text, params);
}

/**
 * Executa fn dentro de uma transacao, com rollback automatico em erro.
 * @param {(client: pg.PoolClient) => Promise<any>} fn
 */
export async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

export async function closePool() {
  await pool.end();
}

export default { pool, query, withTransaction, closePool };
