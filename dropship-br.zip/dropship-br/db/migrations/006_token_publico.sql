BEGIN;

-- =====================================================================
-- 006 — Token publico do pedido
--
-- A pagina de acompanhamento e o link que vai pro cliente, entao ela
-- precisa ser publica. Com id sequencial (/pedido/1, /pedido/2...)
-- qualquer pessoa percorreria os pedidos de todo mundo — nome parcial,
-- status e valor. Um token aleatorio corta essa enumeracao.
--
-- gen_random_uuid() e nativo no PostgreSQL 13+ (o Railway usa 16).
-- =====================================================================

ALTER TABLE pedidos
  ADD COLUMN IF NOT EXISTS token_publico UUID NOT NULL DEFAULT gen_random_uuid();

CREATE UNIQUE INDEX IF NOT EXISTS uq_pedidos_token ON pedidos (token_publico);

COMMENT ON COLUMN pedidos.token_publico IS
  'Identificador para links enviados ao cliente. Nunca use o id sequencial em URL publica.';

COMMIT;
