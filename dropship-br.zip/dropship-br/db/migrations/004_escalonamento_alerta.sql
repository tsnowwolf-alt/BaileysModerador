BEGIN;

-- Quantos avisos de "pague este pedido" ja foram enviados.
-- Guardar o NIVEL, e nao um booleano, e o que permite retomar de onde
-- parou depois de um deploy ou de um ciclo do cron que falhou.
ALTER TABLE pedidos
  ADD COLUMN IF NOT EXISTS nivel_alerta SMALLINT NOT NULL DEFAULT 0;

COMMENT ON COLUMN pedidos.nivel_alerta IS
  'Marcos de escalonamento ja disparados (ver ALI_ALERTA_ESCALONAMENTO).';

COMMIT;
