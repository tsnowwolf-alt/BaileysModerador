BEGIN;

-- ---------------------------------------------------------------------
-- Controle do pagamento DO LADO DA ALIEXPRESS
-- ---------------------------------------------------------------------
ALTER TABLE pedidos
  -- status cru devolvido pela Ali (PLACE_ORDER_SUCCESS, WAIT_SELLER_SEND_GOODS...)
  ADD COLUMN IF NOT EXISTS ali_order_status      TEXT,
  -- quando o placeorder criou o pedido la (inicio do prazo de pagamento)
  ADD COLUMN IF NOT EXISTS data_pedido_ali       TIMESTAMPTZ,
  -- quando detectamos que o pagamento na Ali foi confirmado
  ADD COLUMN IF NOT EXISTS data_pagamento_ali    TIMESTAMPTZ,
  -- evita alertar o mesmo pedido a cada ciclo do cron
  ADD COLUMN IF NOT EXISTS alerta_pagamento_em   TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS valor_ali_centavos    INTEGER;

-- ---------------------------------------------------------------------
-- Controle do pagamento DO LADO DO CLIENTE (Mercado Pago)
-- ---------------------------------------------------------------------
ALTER TABLE pedidos
  ADD COLUMN IF NOT EXISTS mp_payment_id         TEXT,
  ADD COLUMN IF NOT EXISTS mp_status             TEXT,
  ADD COLUMN IF NOT EXISTS mp_metodo             TEXT,   -- pix, credit_card...
  ADD COLUMN IF NOT EXISTS pix_qr_code           TEXT,   -- copia e cola
  ADD COLUMN IF NOT EXISTS pix_qr_base64         TEXT,
  ADD COLUMN IF NOT EXISTS pix_expira_em         TIMESTAMPTZ;

CREATE UNIQUE INDEX IF NOT EXISTS uq_pedidos_mp_payment
  ON pedidos (mp_payment_id)
  WHERE mp_payment_id IS NOT NULL;

-- Usado pelo cron para achar pedidos parados aguardando pagamento na Ali.
CREATE INDEX IF NOT EXISTS idx_pedidos_pagamento_ali
  ON pedidos (status_pedido, data_pedido_ali);

COMMENT ON COLUMN pedidos.ali_order_status IS
  'Status cru da AliExpress. PLACE_ORDER_SUCCESS = criado mas NAO pago.';

COMMIT;
