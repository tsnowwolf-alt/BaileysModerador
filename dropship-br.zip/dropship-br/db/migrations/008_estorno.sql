BEGIN;

-- =====================================================================
-- 008 — Estorno
--
-- Quando o placeorder falha, o cliente ja pagou e nao existe pedido
-- nenhum no fornecedor. Sao os unicos registros do sistema em que
-- alguem esta com dinheiro de terceiro sem contrapartida — e ate agora
-- so havia alerta no Telegram, sem tela nem trilha.
-- =====================================================================

ALTER TABLE pedidos
  ADD COLUMN IF NOT EXISTS mp_refund_id             TEXT,
  ADD COLUMN IF NOT EXISTS estornado_em             TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS valor_estornado_centavos INTEGER,
  ADD COLUMN IF NOT EXISTS motivo_cancelamento      TEXT;

-- Um pagamento so pode ser estornado uma vez.
CREATE UNIQUE INDEX IF NOT EXISTS uq_pedidos_refund
  ON pedidos (mp_refund_id)
  WHERE mp_refund_id IS NOT NULL;

-- Usado pela tela de problemas.
CREATE INDEX IF NOT EXISTS idx_pedidos_problema
  ON pedidos (status_pedido, data_pagamento)
  WHERE status_pedido IN ('erro_ali', 'cancelado_ali', 'pago_no_site');

COMMENT ON COLUMN pedidos.estornado_em IS
  'Preenchido apos o estorno confirmado no Mercado Pago. Impede estorno duplo.';

COMMIT;
