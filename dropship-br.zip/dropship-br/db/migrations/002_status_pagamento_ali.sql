-- @no-transaction
-- =====================================================================
-- 002 — Novos estados para o ciclo de pagamento na AliExpress
--
-- Este arquivo roda FORA de transacao (diretiva acima). Motivo:
-- ALTER TYPE ... ADD VALUE tem restricoes dentro de bloco transacional
-- e o valor novo nao pode ser usado na mesma transacao em que foi criado.
-- Cada statement e executado isoladamente pelo migrador.
-- =====================================================================

ALTER TYPE status_pedido_enum ADD VALUE IF NOT EXISTS 'aguardando_pagamento_ali';

ALTER TYPE status_pedido_enum ADD VALUE IF NOT EXISTS 'cancelado_ali';
