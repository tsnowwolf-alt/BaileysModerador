BEGIN;

-- =====================================================================
-- 005 — Catalogo
--
-- Ate aqui o sistema sabia processar um pedido, mas nao sabia o que
-- estava a venda. Sem estas tabelas nao existe vitrine: o frontend nao
-- teria de onde listar nada, e o preco viria do cliente (que e
-- exatamente o buraco que esta migracao fecha).
-- =====================================================================

CREATE TABLE IF NOT EXISTS produtos (
  id                     SERIAL PRIMARY KEY,

  -- URL amigavel: /produto/fone-bluetooth-tws
  slug                   TEXT UNIQUE NOT NULL,
  titulo                 TEXT NOT NULL,
  descricao              TEXT,

  -- Array de URLs de imagem, na ordem de exibicao.
  imagens                JSONB NOT NULL DEFAULT '[]'::jsonb,

  -- ----- Origem na AliExpress -----
  aliexpress_product_id  TEXT NOT NULL,
  aliexpress_url         TEXT,

  -- Confirmado que despacha de armazem no Brasil. Produto anunciado
  -- como nacional que sai da China vira 30 dias de espera e chargeback,
  -- entao isto fica explicito em vez de suposto.
  estoque_br             BOOLEAN NOT NULL DEFAULT FALSE,
  origem_verificada_em   TIMESTAMPTZ,

  -- ----- Preco padrao (variacao pode sobrescrever) -----
  preco_venda_centavos   INTEGER NOT NULL CHECK (preco_venda_centavos > 0),
  preco_custo_centavos   INTEGER CHECK (preco_custo_centavos >= 0),

  ativo                  BOOLEAN NOT NULL DEFAULT FALSE,

  data_criacao           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  data_atualizacao       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT slug_valido CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$')
);

CREATE INDEX IF NOT EXISTS idx_produtos_ativo ON produtos (ativo, data_criacao DESC);
CREATE INDEX IF NOT EXISTS idx_produtos_ali ON produtos (aliexpress_product_id);

-- ---------------------------------------------------------------------
-- Variacoes (SKUs)
--
-- Existem como tabela separada por um motivo concreto: o placeorder
-- precisa do `sku_attr`, e ele muda por cor/tamanho. Guardar so o
-- produto deixaria o pedido sem saber qual variante comprar.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS produto_variacoes (
  id                     SERIAL PRIMARY KEY,
  produto_id             INTEGER NOT NULL REFERENCES produtos(id) ON DELETE CASCADE,

  -- Como aparece pro cliente: "Preto / M"
  nome                   TEXT NOT NULL,

  aliexpress_sku_id      TEXT,
  -- Ex.: "14:350853#Preto;5:361386" — e este que vai na compra.
  aliexpress_sku_attr    TEXT,

  -- NULL = herda o preco do produto.
  preco_venda_centavos   INTEGER CHECK (preco_venda_centavos > 0),
  preco_custo_centavos   INTEGER CHECK (preco_custo_centavos >= 0),

  imagem                 TEXT,
  ativo                  BOOLEAN NOT NULL DEFAULT TRUE,
  ordem                  SMALLINT NOT NULL DEFAULT 0,

  data_criacao           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  data_atualizacao       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  UNIQUE (produto_id, nome)
);

CREATE INDEX IF NOT EXISTS idx_variacoes_produto
  ON produto_variacoes (produto_id, ativo, ordem);

-- ---------------------------------------------------------------------
-- Vinculo com pedidos
-- ---------------------------------------------------------------------
ALTER TABLE pedidos
  ADD COLUMN IF NOT EXISTS produto_id  INTEGER REFERENCES produtos(id),
  ADD COLUMN IF NOT EXISTS variacao_id INTEGER REFERENCES produto_variacoes(id);

CREATE INDEX IF NOT EXISTS idx_pedidos_produto ON pedidos (produto_id);

-- ---------------------------------------------------------------------
-- Triggers de data_atualizacao (a funcao ja existe da migracao 001)
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_produtos_updated ON produtos;
CREATE TRIGGER trg_produtos_updated
  BEFORE UPDATE ON produtos
  FOR EACH ROW EXECUTE FUNCTION set_data_atualizacao();

DROP TRIGGER IF EXISTS trg_variacoes_updated ON produto_variacoes;
CREATE TRIGGER trg_variacoes_updated
  BEFORE UPDATE ON produto_variacoes
  FOR EACH ROW EXECUTE FUNCTION set_data_atualizacao();

COMMENT ON COLUMN produtos.estoque_br IS
  'TRUE apenas apos confirmar send_goods_country_code = BR na API de frete.';
COMMENT ON COLUMN produto_variacoes.aliexpress_sku_attr IS
  'String de atributos exigida pelo placeorder. Sem ela a compra falha.';

COMMIT;
