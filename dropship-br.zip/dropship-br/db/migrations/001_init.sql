-- =====================================================================
-- 001_init.sql — Schema inicial
-- PostgreSQL 14+ (Railway)
-- =====================================================================

BEGIN;

-- ---------------------------------------------------------------------
-- Estados possiveis do pedido.
-- Uso de ENUM em vez de TEXT livre: o banco passa a rejeitar status
-- invalidos, o que evita pedidos "presos" por erro de digitacao no codigo.
-- ---------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'status_pedido_enum') THEN
    CREATE TYPE status_pedido_enum AS ENUM (
      'aguardando_pagamento',
      'pago_no_site',
      'processando_ali',   -- lock intermediario: evita compra duplicada
      'processado_ali',
      'enviado',
      'entregue',
      'erro_ali',
      'cancelado'
    );
  END IF;
END$$;

CREATE TABLE IF NOT EXISTS pedidos (
  id                    SERIAL PRIMARY KEY,

  -- Chave idempotente do seu checkout/gateway. Impede que o mesmo
  -- pagamento gere dois pedidos (retry de webhook e comum).
  referencia_externa    TEXT UNIQUE NOT NULL,

  -- ----- Cliente -----
  cliente_nome          TEXT        NOT NULL,
  cliente_cpf           CHAR(11)    NOT NULL,  -- somente digitos
  cliente_telefone      TEXT        NOT NULL,  -- somente digitos, com DDD
  cliente_email         TEXT,

  -- ----- Endereco -----
  endereco_rua          TEXT        NOT NULL,
  endereco_numero       TEXT        NOT NULL,
  endereco_complemento  TEXT,
  endereco_bairro       TEXT        NOT NULL,
  endereco_cidade       TEXT        NOT NULL,
  endereco_estado       CHAR(2)     NOT NULL,  -- UF
  endereco_cep          CHAR(8)     NOT NULL,  -- somente digitos

  -- ----- Produto / AliExpress -----
  aliexpress_product_id TEXT        NOT NULL,
  aliexpress_sku_id     TEXT,                  -- id numerico do SKU
  aliexpress_sku_attr   TEXT,                  -- ex.: "14:350853#Preto;5:361386"
  quantidade            INTEGER     NOT NULL DEFAULT 1 CHECK (quantidade > 0),
  logistics_service     TEXT,                  -- ex.: "CAINIAO_FULFILLMENT_STD"

  -- ----- Resultado da API -----
  aliexpress_order_id   TEXT,
  aliexpress_response   JSONB,                 -- payload cru p/ auditoria
  tentativas_ali        INTEGER     NOT NULL DEFAULT 0,
  ultimo_erro           TEXT,

  -- ----- Financeiro (opcional, mas util p/ conciliacao) -----
  valor_total_centavos  INTEGER     CHECK (valor_total_centavos >= 0),

  -- ----- Status e rastreio -----
  status_pedido         status_pedido_enum NOT NULL DEFAULT 'aguardando_pagamento',
  codigo_rastreio       TEXT,
  transportadora        TEXT,

  data_criacao          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  data_atualizacao      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  data_pagamento        TIMESTAMPTZ,
  data_envio            TIMESTAMPTZ,

  CONSTRAINT cep_valido  CHECK (endereco_cep  ~ '^[0-9]{8}$'),
  CONSTRAINT cpf_valido  CHECK (cliente_cpf   ~ '^[0-9]{11}$'),
  CONSTRAINT tel_valido  CHECK (cliente_telefone ~ '^[0-9]{10,11}$')
);

-- Um pedido so pode ter um order_id do Ali. Protege contra dupla compra.
CREATE UNIQUE INDEX IF NOT EXISTS uq_pedidos_ali_order_id
  ON pedidos (aliexpress_order_id)
  WHERE aliexpress_order_id IS NOT NULL;

-- Index usado pelo cron de rastreio.
CREATE INDEX IF NOT EXISTS idx_pedidos_status_data
  ON pedidos (status_pedido, data_atualizacao);

CREATE INDEX IF NOT EXISTS idx_pedidos_rastreio
  ON pedidos (codigo_rastreio)
  WHERE codigo_rastreio IS NOT NULL;

-- ---------------------------------------------------------------------
-- Log de eventos de webhook: idempotencia + trilha de auditoria.
-- Se o gateway reenviar o mesmo evento, o INSERT falha no UNIQUE e o
-- processamento e ignorado.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS webhook_eventos (
  id             BIGSERIAL PRIMARY KEY,
  evento_id      TEXT UNIQUE NOT NULL,
  origem         TEXT NOT NULL,
  payload        JSONB NOT NULL,
  processado_em  TIMESTAMPTZ,
  erro           TEXT,
  recebido_em    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------
-- Historico de mudancas de status (util p/ suporte ao cliente)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pedidos_historico (
  id           BIGSERIAL PRIMARY KEY,
  pedido_id    INTEGER NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  de_status    status_pedido_enum,
  para_status  status_pedido_enum NOT NULL,
  detalhe      TEXT,
  criado_em    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_historico_pedido ON pedidos_historico (pedido_id);

-- ---------------------------------------------------------------------
-- Triggers
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_data_atualizacao()
RETURNS TRIGGER AS $$
BEGIN
  NEW.data_atualizacao = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_pedidos_updated ON pedidos;
CREATE TRIGGER trg_pedidos_updated
  BEFORE UPDATE ON pedidos
  FOR EACH ROW EXECUTE FUNCTION set_data_atualizacao();

CREATE OR REPLACE FUNCTION log_mudanca_status()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status_pedido IS DISTINCT FROM OLD.status_pedido THEN
    INSERT INTO pedidos_historico (pedido_id, de_status, para_status, detalhe)
    VALUES (NEW.id, OLD.status_pedido, NEW.status_pedido, NEW.ultimo_erro);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_pedidos_historico ON pedidos;
CREATE TRIGGER trg_pedidos_historico
  AFTER UPDATE ON pedidos
  FOR EACH ROW EXECUTE FUNCTION log_mudanca_status();

COMMIT;
