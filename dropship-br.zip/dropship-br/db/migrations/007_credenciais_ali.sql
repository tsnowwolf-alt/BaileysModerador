BEGIN;

-- =====================================================================
-- 007 — Credenciais da AliExpress no banco
--
-- O access_token dura 30 dias e o refresh_token, 60. Guardar em
-- variavel de ambiente significaria o sistema parar de funcionar todo
-- mes ate alguem lembrar de colar um token novo — e o sintoma seria
-- pedido pago que nao chega ao fornecedor.
--
-- No banco, o cron consegue renovar sozinho antes de expirar.
-- =====================================================================

CREATE TABLE IF NOT EXISTS ali_credenciais (
  id                SMALLINT PRIMARY KEY DEFAULT 1,
  access_token      TEXT NOT NULL,
  refresh_token     TEXT,
  expira_em         TIMESTAMPTZ,
  refresh_expira_em TIMESTAMPTZ,
  conta             TEXT,
  atualizado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Linha unica: nao ha multiplas contas neste sistema.
  CONSTRAINT linha_unica CHECK (id = 1)
);

COMMENT ON TABLE ali_credenciais IS
  'Token da AliExpress. Renovado automaticamente pelo cron antes de expirar.';

COMMIT;
