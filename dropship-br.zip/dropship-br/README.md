# dropship-br

Backend de dropshipping para o mercado brasileiro, com integração à AliExpress Open Platform.
Node.js 20+ · Express · PostgreSQL · pronto para Railway.

Fluxo completo: cliente paga por Pix → sistema cria o pedido na AliExpress → você é avisado no celular para pagar o fornecedor → o cron acompanha até a entrega.

---

## ⚠️ Correções em relação à especificação original

### 1. O gateway não é `https://taobao.com`

O host de produção da AliExpress Open Platform é `https://api-sg.aliexpress.com/sync`. O `taobao.com` é o site de varejo chinês. O gateway legado da plataforma TOP era `gw.api.taobao.com/router/rest` — provavelmente a origem da confusão.

### 2. MD5 está obsoleto nesse gateway

| | base assinada | algoritmo |
|---|---|---|
| **sha256** (atual) | `concat(chave+valor)` ordenado | `HMAC-SHA256(base, secret)` |
| **md5** (legado) | `secret + concat(chave+valor) + secret` | `MD5(base)` |

Os dois estão em `src/aliexpress/sign.js`, com teste. Padrão `sha256`.

### 3. `placeorder` cria o pedido — não paga

Ele devolve `order_id` em estado `PLACE_ORDER_SUCCESS`, que significa **criado e não pago**. Vendedor nenhum despacha pedido não pago, e depois do prazo a Ali cancela sozinha.

Por isso o pedido vai para `aguardando_pagamento_ali`, **não** para `processado_ali`. Tratar como pago nesse ponto é o que produz *pedido fantasma*: banco verde, cliente esperando, nada despachado.

### 4. `sku_id` sozinho geralmente não basta

A API espera `sku_attr` (`14:350853#Preto;5:361386`). O schema guarda os dois campos.

---

## Sem gerente de conta? Use o diagnóstico

**Pelo painel:** aba **Sistema** → *Testar AliExpress*. Roda os mesmos testes e mostra o resultado na tela, com a sugestão de variáveis pronta para copiar. Leva até um minuto (são várias chamadas com pausa entre elas, para não estourar o limite de QPS da plataforma).

Na mesma aba há o *Conferir Mercado Pago*, que consulta a conta e os meios ativos sem criar cobrança nenhuma.

**Pelo terminal**, se você tiver um:

```bash
npm run diagnose
```

As duas saídas consomem `src/aliexpress/diagnostico.js` — mesma fonte, para não divergirem.

Ele provoca a API de propósito e traduz o código de erro, porque cada erro diz uma coisa diferente:

| Resultado | Significa |
|---|---|
| erro de **validação** ou "não encontrado" | assinatura, token e permissão OK — pode usar |
| `IncompleteSignature` / `InvalidSignature` | `ALI_SIGN_METHOD` ou `APP_SECRET` errado |
| `Invalid session` | `ALI_ACCESS_TOKEN` expirado — gere outro |
| `Insufficient isv permissions` | escopo não liberado — use outro método da lista |

Ele testa os nomes alternativos (`aliexpress.ds.order.create`, `aliexpress.ds.trade.order.get`, etc.) e diz quais responderam. Coloque os aprovados em `ALI_METHOD_*` — o painel marca ✓ quando o valor sugerido já é o configurado e ⚠ quando funciona mas está diferente.

Mandar um `order_id` falso é de propósito: se voltar "não encontrado", é porque a chamada passou por assinatura, token e permissão — a melhor notícia possível.

---

## Como o pagamento ao fornecedor funciona na prática

Não existe endpoint público de pagamento na maioria dos apps. Os plugins consolidados do mercado resolvem assim: colocam um botão que abre a página de pedidos pendentes da AliExpress para você finalizar. É o mesmo desenho aqui, com automação em volta:

1. Cliente paga o Pix → webhook do Mercado Pago valida a assinatura
2. Sistema reconsulta o pagamento na API do MP (o corpo do webhook nunca é fonte de verdade)
3. `placeorder` cria o pedido → status `aguardando_pagamento_ali`
4. **Alerta no Telegram com botão de pagamento a um toque**
5. Você paga (ou o auto-débito da sua conta paga)
6. O cron vê o status virar `WAIT_SELLER_SEND_GOODS` → `processado_ali`
7. Cron acha o `tracking_number` → `enviado`
8. Linketrack confirma a entrega → `entregue`

Se o auto-débito estiver ativo na sua conta, o passo 5 acontece sozinho e o alerta do passo 4 vira só uma confirmação que você ignora. Se não estiver, você paga na hora em vez de descobrir depois do prazo expirar. **O sistema funciona nos dois casos** — é por isso que não vale esperar resposta de ninguém para subir.

E o painel para conferir tudo de uma vez:

```bash
curl -H "x-admin-token: SEU_TOKEN" \
  https://SEU-APP.up.railway.app/api/admin/pagamentos-pendentes
```

Devolve cada pedido com `restam`, `urgente: true/false`, link direto e a comparação `alertas_enviados` × `alertas_devidos` — se divergirem, algum canal de alerta está falhando silenciosamente.

---

## 💸 Capital de giro — o problema que não é de código

**Pix cai na hora. Cartão parcelado liquida em D+30. A AliExpress cancela pedido não pago em ~20h.**

Você não consegue pagar o fornecedor com o dinheiro do cliente se vendeu no cartão — o dinheiro simplesmente não chegou ainda. Por isso o checkout aqui é Pix por padrão.

Se for aceitar cartão, precisa de uma das duas coisas: reserva própria para bancar o intervalo, ou antecipação de recebíveis contratada com o gateway. Sem isso, cada venda no cartão vira um pedido cancelado na Ali e um estorno para o cliente.

---

## Pedidos com problema

Aba **Problemas** no painel. Cada linha é alguém que pagou e não tem produto a caminho — `erro_ali`, `cancelado_ali`, ou pago e travado antes do repasse. O topo mostra o **valor retido** para isso não virar número abstrato, e o contador aparece na aba assim que você entra, sem precisar ir olhar.

Três ações por pedido, e a escolha depende do código do erro:

- **Corrigir dados** — para o caso mais comum, CPF que não bate com o nome. Corrige e reprocessa numa tacada. Bloqueado depois que existe pedido na AliExpress, porque mudar o endereço aqui daria a falsa impressão de que o envio mudou junto.
- **Reprocessar** — o cartão diz se vale a pena. Metade dos erros é permanente; reprocessar um deles só repete a falha.
- **Estornar** — devolve pelo Mercado Pago. Pede confirmação e motivo.

**Garantias do estorno:** um `UPDATE ... WHERE estornado_em IS NULL` trava antes de chamar o MP, e a chave de idempotência é derivada do pedido — dois cliques não viram dois estornos. Se o pedido já existe na AliExpress, o alerta avisa para cancelar lá também, porque estornar o cliente sem cancelar o fornecedor é prejuízo dobrado.

---

## 🛡️ Resistência a reinicializações

O Railway reinicia o processo a cada deploy e a cada mudança de variável. O caminho mais caro do sistema — cliente pagou, pedido precisa chegar ao fornecedor — não pode depender de o processo continuar vivo.

**O problema real:** o webhook responde 200 ao Mercado Pago e só então repassa o pedido à AliExpress, porque o gateway dá timeout em poucos segundos. Se o processo morrer nesse intervalo, o MP não reenvia (já demos 200) e o pedido some em silêncio.

**Três camadas, da mais rápida à mais completa:**

1. **Desligamento gracioso.** No SIGTERM, o servidor para de aceitar conexões, o `/health` passa a responder 503 para o Railway tirar tráfego dali, e esperamos até 10s pelo que está em andamento. Isso *encurta* a janela.

2. **Reconciliação no cron** (`src/jobs/reconciliacao.js`). Roda antes de tudo, a cada ciclo:
   - webhooks gravados sem `processado_em` há mais de 2 min → reprocessa
   - pedidos em `pago_no_site` sem `aliexpress_order_id` há mais de 5 min → repassa
   - cobranças pendentes há mais de 10 min → **pergunta ao Mercado Pago** se foram pagas

3. **A terceira varredura é a mais ampla:** ela não depende de webhook nenhum. Cobre notificação perdida, URL mal configurada e indisponibilidade do nosso lado — casos em que as outras duas nunca ficariam sabendo. Se ela recuperar algo, chega alerta no Telegram, porque significa que o webhook está falhando.

**Por que reprocessar é seguro:** o `UPDATE ... WHERE status_pedido = 'pago_no_site'` só avança a linha uma vez. Reprocessar dez vezes compra uma vez só. Sem essa garantia, a rede de segurança viraria a fonte do problema.

O webhook e a reconciliação usam **a mesma função** de processamento. Duas cópias divergiriam, e a menos exercitada — a de recuperação — seria justamente a menos testada.

No navegador, falha de rede repete a requisição uma vez após 2s, que normalmente é o suficiente para o deploy terminar.

---

## Segurança do webhook

`/webhook/mercadopago` dispara uma compra com dinheiro real. Duas defesas independentes:

1. **Assinatura `x-signature`** do MP: HMAC-SHA256 sobre `id:<data.id>;request-id:<x-request-id>;ts:<ts>;`, com `data.id` em minúsculas e campos ausentes removidos do manifest (não deixados vazios). Testado em `tests/pagamento.test.js`.
2. **Reconsulta na API do MP** antes de agir. Mesmo que alguém forje um webhook dizendo "aprovado", perguntamos ao Mercado Pago e ele responde a verdade.

Há ainda conferência de valor (pagamento a menor não libera pedido) e idempotência por evento.

A trava contra compra duplicada é o `UPDATE ... WHERE status_pedido = 'pago_no_site'` em `src/services/pedidos.js`. Dois webhooks simultâneos: um ganha a corrida, o outro recebe `rowCount = 0`. **Não troque por SELECT-depois-UPDATE** — a janela entre os dois já é suficiente para comprar o mesmo item duas vezes.

---

## Deploy no Railway

```bash
git init && git add . && git commit -m "init"
git remote add origin git@github.com:SEU_USUARIO/dropship-br.git
git push -u origin main
```

1. **New Project → Deploy from GitHub repo**
2. **+ New → Database → PostgreSQL**
3. Em **Variables**, cole as chaves do `.env.example`
4. As migrações rodam no boot
5. Confira `GET /health`

### Cron

**+ New → Cron Job**, mesmo repo:
- Schedule: `*/15 * * * *`
- Start command: `npm run job:sync`

Quinze minutos é um bom intervalo: rápido o bastante para você reagir ao pedido não pago dentro do prazo, sem estourar o limite de QPS da Open Platform.

### Alertas escalonados no celular

Sem isso, pedido travado passa despercebido. Dois minutos para configurar: fale com o [@BotFather](https://t.me/botfather) → `/newbot` → pegue o token → mande uma mensagem pro seu bot → abra `api.telegram.org/bot<TOKEN>/getUpdates` → pegue o `chat_id`.

Cada alerta vem com dois botões inline: **💰 Pagar este pedido** (abre direto a tela daquele pedido) e **📋 Ver todos os pendentes**. Nada de copiar URL.

Um aviso só, disparado uma vez, é fácil de perder — chega enquanto você dirige, você pensa "pago depois", e o pedido morre. Por isso o aviso volta com intensidade crescente:

| Parado há | Tom | Notificação |
|---|---|---|
| criação | 💳 confirmação | silenciosa |
| 30min | 💳 normal | silenciosa |
| 2h | ⚠️ atenção | com som |
| 6h | 🚨 último aviso | com som |

Ajuste em `ALI_ALERTA_ESCALONAMENTO=30,120,360`. O sistema avisa no boot se o último marco cair depois do prazo de expiração — um aviso que chega com o pedido já morto não serve para nada.

O nível já enviado fica gravado em `nivel_alerta`, então um deploy ou um ciclo do cron que falhou não faz o escalonamento recomeçar do zero nem repetir o mesmo aviso.

---

## Endpoints

| Método | Rota | Descrição |
|---|---|---|
## A loja

O frontend é HTML/CSS/JS puro servido pelo próprio Express. Sem build, sem segundo serviço no Railway, sem CORS — o mesmo deploy que sobe a API sobe a loja.

| Página | Rota | O que faz |
|---|---|---|
| Vitrine | `/` | Lista os produtos ativos |
| Produto | `/produto.html?p=slug` | Fotos, variações, botão de compra |
| Checkout | `/checkout.html?v=id` | Dados, endereço, gera o Pix |
| Pedido | `/pedido.html?t=token` | Pix, acompanhamento e rastreio |
| **Painel** | `/admin.html` | Cadastrar produto e ver o que falta pagar |

**Design.** A direção é *etiqueta de despacho* — o mundo material da encomenda brasileira. Amarelo postal sobre tinta escura, códigos e preços em monoespaçada com algarismos tabulares, botões que "carimbam" ao serem pressionados. O elemento de assinatura é a etiqueta na página do pedido: borda picotada de verdade, código de rastreio carimbado em amarelo. Tudo em volta fica quieto para ela aparecer.

A abertura da home é a tese do negócio, não uma saudação: *"Já está no Brasil."* É o que separa esta loja de um dropshipping comum, e é o mesmo dado que o `estoque_br` guarda no banco.

**Detalhes que mudam a conversão no celular:**

- **CEP preenche o endereço** via ViaCEP — cinco campos a menos para digitar. Se o serviço cair, os campos continuam editáveis à mão.
- **Máscaras** de CPF, CEP e telefone enquanto se digita.
- **CPF validado por módulo 11** no navegador, para o erro aparecer antes de preencher o resto. O servidor valida de novo, porque validação de navegador não é barreira nenhuma.
- **Botão de compra fixo na base** da tela, onde o polegar alcança.
- **A página do Pix se atualiza sozinha** a cada 5s — o cliente não precisa recarregar depois de pagar.
- **Erro do servidor volta para o campo certo**, não para uma caixa genérica no topo.

**Acessibilidade e desempenho:** foco visível no teclado, `prefers-reduced-motion` respeitado, imagens com `loading="lazy"`.

**Cache:** tudo em `no-cache` com ETag. Isso não quer dizer "não guarde" — quer dizer "confirme antes de usar o que guardou". O navegador manda um pedido curto e recebe `304` quando nada mudou, então não há redownload; e quando o arquivo muda, ele pega a versão nova na hora.

A versão anterior usava `max-age=3600` em CSS e JS, e isso criava um modo de falha desagradável: depois de um deploy, o navegador rodava o HTML novo com o JavaScript velho por até uma hora. Bug já corrigido continuava aparecendo, sem nenhuma pista de que a causa era o cache.

**Para conferir o que está no ar:** `GET /health` devolve o campo `versao`, lido do `package.json`. Se não bater com o que você subiu, o deploy não terminou — ou você está vendo cache.

O painel confere isso sozinho: compara a versão do JavaScript carregado com a que o servidor reporta e mostra um aviso quando divergem. Sem essa checagem, navegador velho contra servidor novo produz erros que não têm relação nenhuma com a causa real — já aconteceu duas vezes neste projeto.

Ao subir a `version` no `package.json`, suba também `VERSAO_JS` em `public/js/loja.js`. Há um teste que falha se esquecer.

**Quando o deploy falha, o Railway mantém a versão anterior no ar.** Então um deploy vermelho não é só "a versão nova não subiu" — é "a versão velha continua atendendo". Se um bug corrigido reaparece logo depois de um deploy falho, é quase sempre isso.

**A marca.** Um **O** de *opa* e uma caixa lacrada no mesmo desenho. A fita ultrapassa a silhueta de propósito — fita de verdade sobra da caixa, e é essa sobra que impede o símbolo de virar um círculo com barra qualquer.

O miolo é vazado, não branco: assim funciona sobre qualquer fundo. Foi um erro que só apareceu ao testar sobre o cabeçalho escuro.

| Arquivo | Uso |
|---|---|
| `img/logo-icone.svg` | símbolo, fundo claro |
| `img/logo-icone-claro.svg` | símbolo, fundo escuro |
| `img/logo-completo.svg` | símbolo + nome |
| `img/favicon.svg` | aba do navegador e ícone de app |

O ícone do cabeçalho é SVG inline, não `<img>` — assim escala junto com a fonte e não pisca no carregamento. A página `/marca.html` mostra as variantes, os tamanhos testados e as regras de uso.

Para trocar o nome, procure por `opastore` nos arquivos de `public/`.

---

## 🔑 Link do pedido usa token, não ID

A página de acompanhamento é o link que vai pro cliente, então precisa ser pública. Com ID sequencial (`/pedido/1`, `/pedido/2`...) qualquer pessoa percorreria os pedidos de todo mundo — nome parcial, cidade, status e valor.

Cada pedido tem um `token_publico` (UUID). O ID sequencial nunca aparece em URL pública.

---

**Públicos** (o frontend consome):

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/health` | Healthcheck |
| `GET` | `/api/catalogo` | Vitrine — produtos ativos |
| `GET` | `/api/catalogo/:slug` | Página do produto + variações |
| `GET` | `/api/catalogo/variacao/:id` | Resumo de uma variação (checkout) |
| `POST` | `/api/pedidos` | Cria pedido **e devolve o Pix pronto** |
| `GET` | `/api/rastreio/:token` | Status + histórico Correios |
| `POST` | `/webhook/mercadopago` | Webhook de pagamento |

**Admin** (header `x-admin-token`)

O `ADMIN_TOKEN` precisa de **16+ caracteres** — o `config.js` recusa menos que isso e o processo não sobe. Se o Railway acusar falha de healthcheck logo após você mexer nas variáveis, é quase sempre isso: o container morre no boot e nunca chega a responder. O motivo real aparece nos logs do deploy, não na tela de healthcheck.

Uma frase satisfaz a regra e é fácil de lembrar: `garrafa-termica-loja-2026`.

As rotas de admin têm limite de 10 tentativas erradas por IP a cada 15 minutos (acerto não gasta cota) e comparação em tempo constante — o `!==` do JavaScript para no primeiro caractere diferente, e essa diferença de tempo vaza o prefixo correto.



| Método | Rota | Descrição |
|---|---|---|
| `POST` | `/api/admin/produtos/importar` | Cola o link da Ali → rascunho |
| `POST` | `/api/admin/produtos` | Cria produto + variações |
| `GET` | `/api/admin/produtos` | Lista tudo, com margem |
| `PATCH` | `/api/admin/produtos/:id` | Edição parcial |
| `POST` | `/api/admin/produtos/:id/ativar` | Publica (com checklist) |
| `POST` | `/api/admin/produtos/:id/variacoes` | Adiciona variação |
| `GET` | `/api/admin/pagamentos-pendentes` | O que falta pagar na Ali |
| `POST` | `/api/admin/sync` | Força um ciclo do cron |
| `GET` | `/api/admin/pedidos/:id` | Pedido completo |
| `POST` | `/webhook/reprocessar/:id` | Retry de pedido em `erro_ali` |

---

## 🔒 O preço vem do banco, nunca do cliente

A primeira versão do checkout aceitava `valor_total_centavos` no corpo da requisição. Isso significava que qualquer pessoa com o endpoint podia pedir um produto de R$ 200 por R$ 0,01 — o Pix sairia por um centavo e o sistema compraria o produto de verdade na AliExpress com o seu dinheiro.

Agora o cliente manda só `variacao_id` e `quantidade`. Preço, `product_id` e `sku_attr` saem do banco. **Nada que venha do navegador influencia quanto é cobrado.**

Há também um bloqueio de margem invertida: se o preço de venda ficar menor ou igual ao custo, a venda é recusada em vez de dar prejuízo silencioso a cada pedido.

---

## Cadastrando um produto

**Pelo painel** (o caminho normal): abra `https://SEU-APP.up.railway.app/admin.html`, entre com o `ADMIN_TOKEN`, toque em **Cadastrar produto**, cole o link da AliExpress e toque em **Buscar dados**.

O painel preenche o que a API devolver e deixa você editar tudo. A margem aparece enquanto você digita o preço — é a informação que decide a venda, então não fica escondida atrás de um botão salvar. Se a importação falhar, os campos continuam editáveis à mão e o cadastro segue.

A aba **A pagar** lista os pedidos criados na Ali que ainda não foram quitados, com link direto e marcação de urgência. É a mesma informação do alerta no Telegram, em formato de tela.

O token fica salvo no navegador para não pedir a cada visita. Use **Sair** para apagá-lo — em celular compartilhado, sempre.

**Pela API** (se preferir automatizar):

```bash
TOKEN="seu_admin_token"
API="https://SEU-APP.up.railway.app"

# 1. Cola o link — devolve rascunho, não salva nada
curl -X POST $API/api/admin/produtos/importar \
  -H "x-admin-token: $TOKEN" -H 'Content-Type: application/json' \
  -d '{"url":"https://pt.aliexpress.com/item/1005004043442825.html"}'

# 2. Revisa, define SEU preço de venda, e cria
curl -X POST $API/api/admin/produtos \
  -H "x-admin-token: $TOKEN" -H 'Content-Type: application/json' \
  -d '{
    "titulo": "Fone Bluetooth TWS",
    "imagens": ["https://ae01.alicdn.com/kf/exemplo.jpg"],
    "aliexpress_product_id": "1005004043442825",
    "estoque_br": true,
    "preco_custo_centavos": 3500,
    "preco_venda_centavos": 8990,
    "variacoes": [
      {"nome":"Preto","aliexpress_sku_attr":"14:193#Preto","preco_custo_centavos":3500}
    ]
  }'

# 3. Publica — passa pelo checklist antes
curl -X POST $API/api/admin/produtos/1/ativar -H "x-admin-token: $TOKEN"
```

O importador **nunca quebra**: se a API não responder, se o método não estiver liberado no seu app ou se o formato mudar, ele devolve um rascunho vazio com o `product_id` preenchido e você completa à mão. Rode `npm run diagnose` para descobrir se `ALI_METHOD_PRODUCT_GET` funciona na sua conta — se nenhum passar, deixe a variável vazia.

O checklist de ativação recusa produto sem SKU (a compra falharia **depois** do cliente pagar), sem imagem, sem custo informado, com margem invertida, ou com origem BR não confirmada. Use `{"forcar": true}` para publicar assumindo as pendências.

### Criar pedido + Pix

```bash
curl -X POST https://SEU-APP.up.railway.app/api/pedidos \
  -H 'Content-Type: application/json' \
  -d '{
    "variacao_id": 1,
    "quantidade": 1,
    "cliente_nome": "Maria Silva",
    "cliente_cpf": "529.982.247-25",
    "cliente_telefone": "(11) 99999-8888",
    "endereco_rua": "Avenida Paulista",
    "endereco_numero": "1578",
    "endereco_bairro": "Bela Vista",
    "endereco_cidade": "Sao Paulo",
    "endereco_estado": "SP",
    "endereco_cep": "01310-100"
  }'
```

Repare no que **não** está aqui: preço, `product_id` e `sku_attr`. Tudo isso vem do banco a partir do `variacao_id`. A resposta traz `pix.qr_code` (copia e cola) e `pix.qr_code_base64` (imagem).

---

## Fluxo de status

```
aguardando_pagamento      cliente ainda não pagou o Pix
   ↓ webhook MP aprovado + reconsulta na API
pago_no_site
   ↓ lock atômico
processando_ali
   ↓ placeorder OK              ↓ falha
aguardando_pagamento_ali     erro_ali → retry manual
   │  ⚠️ criado na Ali, NÃO pago. Alerta no Telegram.
   ↓ cron vê WAIT_SELLER_SEND_GOODS    ↓ prazo estourou
processado_ali                      cancelado_ali
   ↓ cron acha tracking_number
enviado
   ↓ Linketrack indica entrega
entregue
```

---

## Detalhes brasileiros que quebram a integração

- **`province` precisa do nome por extenso.** "SP" é rejeitado; "Sao Paulo" passa.
- **CPF é obrigatório** (alfândega/NF-e). Validado por módulo 11 antes de qualquer chamada. Se o campo `cpf` der erro, ative `cpfNoAddress2` — é o fallback de concatenar no fim do endereço.
- **Sem acentos.** Alguns validadores da Alibaba rejeitam não-ASCII.
- **Fornecedor nacional raramente usa Correios.** J&T, Loggi e Sislogica são mais comuns e a Linketrack não rastreia nenhuma. O código detecta o padrão `LB123456789BR` e devolve `disponivel: false` com link externo quando não bate, em vez de fingir que funcionou.
- **Origem BR é verificada, não suposta.** No editor de produto há o botão **Verificar origem pela AliExpress**: ele consulta a API de frete e marca `estoque_br` conforme a resposta. Só afirma origem nacional quando **todas** as opções saem do Brasil — origem mista vira FALSE, porque uma opção internacional no meio significa que o cliente pode cair nela. Sem informação de país, também FALSE: marcar TRUE por otimismo transforma a tese da loja numa promessa que a operação não cumpre.

---

## Testes

**`npm test` roda antes de qualquer deploy.** Um dos testes lê o código e confere se todo import relativo resolve — arquivo existe, e o nome importado é realmente exportado. Isso existe porque `node --check` valida a sintaxe de cada arquivo isoladamente e **não** confere imports: um arquivo perfeito que importa algo inexistente passa ileso e derruba o processo no boot, com o Railway reportando apenas "healthcheck failure".

```bash
npm test   # 69 testes
```

Cobrem: as duas variantes de assinatura da Ali, ordenação ASCII da base, assinatura do webhook do MP (incluindo replay, adulteração e segredo errado), CPF por módulo 11, classificação de status — com um teste garantindo que nenhum status `nao_pago` vaze como pago — o escalonamento (incluindo um teste de monotonicidade: o nível de alerta nunca pode descer com o passar do tempo), e o parser de link da AliExpress — que cobre domínios regionais, links curtos, `/i/` e id colado direto, com um teste garantindo que todo slug gerado passa na constraint do banco — e o JS do navegador: máscaras, CPF (o mesmo caso do servidor, para as duas validações não divergirem) e o merge de opções do `fetch`.

Esse último tem uma história: o spread de `opcoes` vinha depois de `headers`, então qualquer chamador que passasse um header próprio apagava o `Content-Type`. O corpo saía como texto puro, o `express.json()` ignorava, e o servidor recebia `{}` — reclamando que todos os campos faltavam mesmo estando preenchidos. Quebrava todo POST do painel. Agora tem teste.

---

## Estrutura

```
src/
├── server.js                 # Express + healthcheck + shutdown
├── config.js                 # env validado com zod (falha no boot)
├── db.js                     # pool pg + transações
├── aliexpress/
│   ├── sign.js               # ★ assinatura HMAC-SHA256 / MD5
│   ├── status.js             # ★ classificação de status (puro)
│   ├── client.js             # gateway, retry com backoff, erros
│   ├── produtos.js           # importação por link (com fallback)
│   └── orders.js             # mapeamento BR→Ali, placeorder, order.get
├── routes/
│   ├── webhook.js            # ★ assinatura MP + reconsulta + repasse
│   ├── pedidos.js            # ★ checkout (preço vem do banco)
│   ├── catalogo.js           # vitrine pública
│   ├── rastreio.js           # endpoint público
│   └── admin.js              # produtos + pagamentos pendentes
├── services/
│   ├── pedidos.js            # ★ lock atômico anti-duplicação
│   ├── produtos.js           # ★ catálogo e preço efetivo
│   ├── mercadopago.js        # Pix, consulta, assinatura
│   └── linketrack.js         # Correios com degradação suave
├── jobs/syncOrders.js        # ★ cron: pagamento → postagem → entrega
└── lib/
    ├── mpSignature.js        # ★ assinatura do MP (puro, testável)
    ├── escalonamento.js      # ★ níveis de alerta (puro, testável)
    ├── aliUrl.js             # ★ parser de link + slug (puro, testável)
    ├── brasil.js             # CPF, CEP, UF, telefone
    └── alertas.js            # Telegram (botões inline) / Discord / Slack
public/                       # a loja (HTML/CSS/JS puro, sem build)
├── index.html                # vitrine
├── produto.html              # página do produto
├── checkout.html             # dados + endereço + Pix
├── pedido.html               # ★ etiqueta, Pix e rastreio
├── admin.html                # ★ painel: produtos e pagamentos
├── css/loja.css              # tokens de design e componentes
├── css/admin.css             # extensões do painel
└── js/loja.js                # API, máscaras, CPF, ViaCEP
scripts/
├── migrate.js                # migrador (suporta @no-transaction)
└── diagnose.js               # ★ descobre permissões do seu app
db/migrations/
├── 001_init.sql
├── 002_status_pagamento_ali.sql
├── 003_pagamento_colunas.sql
├── 004_escalonamento_alerta.sql
├── 005_catalogo.sql
└── 006_token_publico.sql
```

---

## Checklist antes do primeiro pedido real

- [ ] `npm test` passando
- [ ] `npm run diagnose` sem erro de assinatura nem de token
- [ ] Métodos aprovados copiados para `ALI_METHOD_*`
- [ ] Telegram configurado, com botão de pagamento funcionando (`POST /api/admin/sync`)
- [ ] `/health` respondendo `ok: true`
- [ ] Um pedido completo em `ALI_DRY_RUN=true`, com o `logistics_address` do log revisado
- [ ] Webhook do MP testado com assinatura errada → deve dar 401
- [ ] Ao menos um produto cadastrado e ativo, sem pendências no checklist
- [ ] Uma compra de teste completa pela loja, até a tela do Pix
- [ ] `ADMIN_TOKEN` guardado em lugar seguro (é o acesso ao painel)
- [ ] Reserva de caixa para bancar o intervalo entre pagar o fornecedor e receber
- [ ] `.env` **fora** do Git
- [ ] Um pedido barato de ponta a ponta com `ALI_DRY_RUN=false`
