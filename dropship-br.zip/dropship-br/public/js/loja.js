/* =====================================================================
   loja.js — utilitários compartilhados pelas páginas
   ===================================================================== */

/**
 * Versão deste arquivo. Precisa acompanhar a `version` do package.json.
 *
 * Existe porque já perdemos duas rodadas de depuração com o navegador
 * rodando JavaScript velho contra um servidor novo — e o sintoma era um
 * erro que não tinha nada a ver com a causa. O painel compara este valor
 * com o que /health devolve e avisa quando divergem.
 */
export const VERSAO_JS = '1.10.0';

/* ---------------------------------------------------------------------
   API
   ------------------------------------------------------------------ */

/**
 * Monta as opções do fetch.
 *
 * A ORDEM DO SPREAD IMPORTA. Se `...opcoes` vier depois de `headers`,
 * um chamador que passe qualquer header próprio substitui o objeto
 * inteiro e derruba o Content-Type — a requisição sai como texto puro,
 * o express.json() ignora o corpo e o servidor recebe {}.
 *
 * Está numa função separada porque foi exatamente esse o bug, e agora
 * tem teste.
 */
export function montarOpcoes(opcoes = {}) {
  return {
    ...opcoes,
    headers: { 'Content-Type': 'application/json', ...(opcoes.headers ?? {}) },
  };
}

export async function api(caminho, opcoes = {}, tentativa = 1) {
  let res;
  try {
    res = await fetch(caminho, montarOpcoes(opcoes));
  } catch (falha) {
    /* Deploy no Railway derruba as conexões em andamento. Uma segunda
       tentativa depois de 2s costuma pegar o servidor já de pé — e
       poupa o usuário de descobrir sozinho que era só esperar.
       Só repetimos requisições de leitura e criação idempotente; um
       POST repetido é seguro aqui porque o backend deduplica por
       referencia_externa e por evento. */
    if (tentativa === 1) {
      await new Promise((r) => setTimeout(r, 2000));
      return api(caminho, opcoes, 2);
    }
    // "Failed to fetch" é o que o navegador diz quando a conexão cai,
    // ou quando o servidor reinicia no meio da requisição — o que
    // acontece toda vez que uma variável muda no Railway. A mensagem
    // crua não ajuda ninguém a decidir o que fazer.
    const erro = new Error(
      'Não consegui falar com o servidor. Pode ser a conexão, ou um deploy em andamento. Tente de novo em alguns segundos.'
    );
    erro.rede = true;
    erro.causa = falha.message;
    throw erro;
  }

  let corpo = null;
  try {
    corpo = await res.json();
  } catch {
    /* resposta sem JSON */
  }

  if (!res.ok) {
    const erro = new Error(corpo?.erro ?? `Falha na requisição (${res.status})`);
    erro.status = res.status;
    erro.detalhes = corpo?.detalhes ?? [];
    // O corpo inteiro fica acessível: algumas rotas devolvem campos
    // próprios (como `pendencias`) que se perderiam se só lêssemos
    // `erro` e `detalhes`.
    erro.corpo = corpo ?? {};
    throw erro;
  }

  return corpo;
}

// O guard permite importar este módulo no Node para os testes; no
// navegador o comportamento é o mesmo.
export const params = new URLSearchParams(
  typeof location !== 'undefined' ? location.search : ''
);

export const reais = (centavos) =>
  centavos == null
    ? '—'
    : (centavos / 100).toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL',
      });

/* ---------------------------------------------------------------------
   Máscaras
   Aplicadas no `input` para o campo se formatar enquanto se digita.
   ------------------------------------------------------------------ */

const digitos = (v) => String(v ?? '').replace(/\D/g, '');

export const mascaras = {
  cpf: (v) =>
    digitos(v)
      .slice(0, 11)
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2'),

  cep: (v) => digitos(v).slice(0, 8).replace(/(\d{5})(\d)/, '$1-$2'),

  telefone: (v) => {
    const d = digitos(v).slice(0, 11);
    if (d.length <= 10) {
      return d.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{4})(\d)/, '$1-$2');
    }
    return d.replace(/(\d{2})(\d)/, '($1) $2').replace(/(\d{5})(\d)/, '$1-$2');
  },
};

export function aplicarMascara(input, tipo) {
  const formatar = mascaras[tipo];
  input.addEventListener('input', () => {
    const posFinal = input.selectionStart === input.value.length;
    input.value = formatar(input.value);
    if (posFinal) input.setSelectionRange(input.value.length, input.value.length);
  });
}

/* ---------------------------------------------------------------------
   Validação de CPF

   Espelha a validação do servidor de propósito. Aqui é para o cliente
   descobrir o erro de digitação antes de preencher o resto do
   formulário; o servidor valida de novo porque validação de navegador
   não é barreira nenhuma — qualquer um a contorna.
   ------------------------------------------------------------------ */

export function cpfValido(valor) {
  const cpf = digitos(valor);
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;

  for (const [tamanho, posicao] of [
    [9, 10],
    [10, 11],
  ]) {
    let soma = 0;
    for (let i = 0; i < tamanho; i++) soma += Number(cpf[i]) * (posicao - i);
    let dv = (soma * 10) % 11;
    if (dv === 10) dv = 0;
    if (dv !== Number(cpf[tamanho])) return false;
  }
  return true;
}

export const telefoneValido = (v) => [10, 11].includes(digitos(v).length);
export const cepValido = (v) => digitos(v).length === 8;

/* ---------------------------------------------------------------------
   ViaCEP

   Preencher endereço a partir do CEP tira cinco campos do caminho do
   cliente. Num checkout de celular, cada campo a menos é venda a mais.
   Se o serviço cair, os campos continuam editáveis à mão.
   ------------------------------------------------------------------ */

export async function buscarCEP(cep) {
  const limpo = digitos(cep);
  if (limpo.length !== 8) return null;

  const controle = new AbortController();
  const prazo = setTimeout(() => controle.abort(), 8000);

  try {
    const res = await fetch(`https://viacep.com.br/ws/${limpo}/json/`, {
      signal: controle.signal,
    });
    if (!res.ok) return null;
    const dados = await res.json();
    if (dados.erro) return null;

    return {
      rua: dados.logradouro ?? '',
      bairro: dados.bairro ?? '',
      cidade: dados.localidade ?? '',
      estado: dados.uf ?? '',
    };
  } catch {
    return null; // silencioso: o cliente digita à mão
  } finally {
    clearTimeout(prazo);
  }
}

/* ---------------------------------------------------------------------
   Erros de campo
   ------------------------------------------------------------------ */

export function marcarErro(input, mensagem) {
  input.setAttribute('aria-invalid', 'true');
  let alvo = input.parentElement.querySelector('.campo__erro');
  if (!alvo) {
    alvo = document.createElement('span');
    alvo.className = 'campo__erro';
    input.parentElement.appendChild(alvo);
  }
  alvo.textContent = mensagem;
}

export function limparErro(input) {
  input.removeAttribute('aria-invalid');
  input.parentElement.querySelector('.campo__erro')?.remove();
}

export function mostrarAviso(seletor, mensagem, tipo = 'erro') {
  const caixa = document.querySelector(seletor);
  if (!caixa) return;
  caixa.className = `aviso aviso--${tipo}`;
  caixa.textContent = mensagem;
  caixa.classList.remove('oculto');
}

export function escapar(texto) {
  const d = document.createElement('div');
  d.textContent = String(texto ?? '');
  return d.innerHTML;
}
